import { Injectable } from '@angular/core';

@Injectable()
export class JobsServiceService {

  careers = [
    {
      "Reference": "BDA_01",
      "Title": "Business Development Associate",
      "Job_Type": "Full time/Part Time",
      "Description": "We are looking for an outgoing and active member to join the business development team. Reporting directly to the Chief Executive Officer, the successful candidate will play an essential role in identifying and seizing opportunities to grow the business.",
      "Open_pos": 2,
      "Description_prev": "",
      "Title_prev": "",
      "Responsibilities": [
        "Lead and provide necessary support for ongoing market research activities",
        "Monitor competition by gathering current marketplace information on pricing, new products, new and existing competitors, marketing activities and customer solutions",
        "Provide bi-weekly progress report",
        "Assist in general office activities as deemed necessary",
        "Participating in activities needed to support the management functions of the team",
        "Adhoc duties relevant to the position will be assigned",
        "Local travel may be necessary"
      ],
      "Requirements": [
        "Masters/Bachelors degree in Business or any management field",
        "Language fluency in English, written and verbal required",
        "Proficient in Windows and MS Office Suite - Word, Excel, PowerPoint",
        "Self Initiated, fast learner with a positive attitude",
        "Organized, detail oriented and willingness to follow instructions",
        "Strong entrepreneurial spirit and attitude"
      ],
      "HTA": "If you have any of these qualities and want to learn, what it takes to be a part of a new exciting start-up, then apply with the subject line RE: Business Development Associate and email your resume to hr@farmkart.com"
    },
    {
      "Reference": "DS_01",
      "Title": "Data Scientist",
      "Job_Type": "Full time/Part Time",
      "Description": "Reporting to the Head of Data Analytics, the Data Scientist will work extensively with data to draw out insights relevant to the business. The Data Scientist will perform ad-hoc analysis on data, see if the trends are worth pursuing and present the results to the business executives. Additionally, the Data Scientist will work closely with the Software team to integrate predictive models to generate product recommendations on our digital platform. Lastly, the Data Scientist will perform hypothesis testing to verify the success of various product features.",
      "Open_pos": 1,
      "Description_prev": "",
      "Title_prev": "",
      "Responsibilities": [
        "Implement Machine Learning algorithms using structured and unstructured data",
        "Build end-to-end data pipeline for various data science projects",
        "Analyze existing operating metrics and identify trends, perform comparisons, and highlight improvement opportunities",
        "Extract data from relevant sources/databases, perform cleansing, develop algorithms, present the results to both technical and business audience",
        "Develop forecasts from time-series data; recommendation engines from customer data, A/B testing on different product features, etc",
        "Find relevant data sets on their own to proactively prove or disprove various hypotheses relating to ongoing business",
        "Develop and maintain analytical models to support various ad hoc planning projects/initiatives",
        "Maintain the predictive model and phase out when the model needs to be phased out"
      ],
      "Requirements": [
        "Minimum of Bachelor's degree in Electronics/Computer/Software Engineering from a reputed university and 3-5 years of industry experience in related areas",
        "Strong mathematical and statistical background",
        "Expertise in either Python or R machine learning libraries",
        "Evidence of initiative in coming up with projects and executing them successfully",
        "Strong verbal and written communication in English",
        "Attention to detail and ability to prioritize among various concurrent projects",
        "Ability to simplify complex tasks and drive efficiencies",
        "Ability to translate ambiguous business requirements and quantify them"
      ],
      "HTA": "If you have any of these qualities and want to learn, what it takes to be a part of a new exciting start-up, then apply with the subject line RE: Data Scientist and email your resume to hr@farmkart.com"

    },
    {
      "Reference": "BDA_02",
      "Title": "Business Development Associate - Intern",
      "Job_Type": "Internship Full Time/Part Time",
      "Description": "We are looking for a few enthusiastic interns to join our business development team this summer. During this internship, you will have the opportunity to try your hand at different roles in the company such as marketing, administration, operation, business development and more. We are looking for ambitious individuals who are not afraid to take on challenges and work in a fast-paced start-up environment.",
      "Open_pos": 2,
      "Description_prev": "",
      "Title_prev": "",
      "Responsibilities": [
        "Assist business development team in day to day activities",
        "Assist in market research activities in data collection and analysis",
        "Updating marketing and business development materials",
        "Assist in creating monthly reports",
      ],
      "Requirements": [
        "First year masters student in Business or any management field",
        "Final year undergraduate candidate in business and management studies",
        "Strong desire to learn along with professional drive",
        "A passion for the technology start-up space",
        "Proficient in Windows and MS Office Suite - Word, Excel, PowerPoint"
      ],
      "HTA": "If you have any of these qualities and want to learn, what it takes to be a part of a new exciting start-up, then apply with the subject line RE: Business Operations and email your resume to hr@farmkart.com"
    }
  ];

  constructor() {
    for(var i = 0; i < this.careers.length; i++){
      this.careers[i].Title_prev = this.careers[i].Title;

      if (this.careers[i].Description.length > 96){
        this.careers[i].Description_prev = this.careers[i].Description.substring(0,92) + "...";
      }else{
        this.careers[i].Description_prev = this.careers[i].Description;
      }
    }
  }

}
