import { Injectable } from '@angular/core';

@Injectable()
export class PipeService {

  newsroom_fragment = "";

  constructor() { }

}
