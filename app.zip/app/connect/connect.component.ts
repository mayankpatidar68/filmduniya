import { ElementRef, Component, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { JobsServiceService } from '../jobs-service.service';

@Component({
  selector: 'app-connect',
  templateUrl: './connect.component.html',
  styleUrls: ['./connect.component.css'],
  host: {'(window:scroll)': 'change_poster_appearance($event)'}
})
export class ConnectComponent implements OnInit {

  careers = [];
  careers_index = 0;
  related = [];

  constructor(private element: ElementRef, private router: Router, private jobs: JobsServiceService) {
    this.careers = this.jobs.careers;
    window.scrollTo(0,0);
  }

  ngOnInit() {
    window.scrollTo(0,0);
  }

  change_poster_appearance(event){
    var container = this.element.nativeElement.querySelector('#overlay_top');
    var text = this.element.nativeElement.querySelector('#text_top');
    var img = this.element.nativeElement.querySelector('.banner_image');

    var min = .45;
    var max = .75;

    var min_scale = 1;
    var max_scale = 1.25;

    var mult = currentYPosition()/460;

    if (currentYPosition() <= 460){
      var val = ((max - min)*mult) + min;
      container.style.background = "rgba(0,0,0," + val + ")";
      var val = 1 - mult;
      text.style.opacity = val;
      var val = ((max_scale - min_scale)*mult) + min_scale;
      img.style.transform = "scale(" + val + "," + val + ")";
    }
  }


}


function currentYPosition() {
    // Firefox, Chrome, Opera, Safari
    if (self.pageYOffset) return self.pageYOffset;
    // Internet Explorer 6 - standards mode
    if (document.documentElement && document.documentElement.scrollTop)
        return document.documentElement.scrollTop;
    // Internet Explorer 6, 7 and 8
    if (document.body.scrollTop) return document.body.scrollTop;
    return 0;
}
