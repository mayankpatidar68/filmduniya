import { ElementRef, Component, OnInit } from '@angular/core';
import { Http, Response } from '@angular/http';

@Component({
  selector: 'app-contact-us',
  templateUrl: './contact-us.component.html',
  styleUrls: ['./contact-us.component.css'],
  host: {'(window:scroll)': 'change_poster_appearance($event)'}
})
export class ContactUsComponent implements OnInit {

  lat1: number = 22.037834;
  lng1: number = 74.892794;

  lat2: number = 22.652794;
  lng2: number = 75.818920;

  lat3: number = (this.lat1 + this.lat2)/2;
  lng3: number = (this.lng1 + this.lng2)/2;

  address = "1, Saket Residency Barwani, Madhya Pradesh 451551, India";
  phone = "+91 94250-87517<br>+91 90099-87517";

  constructor(private element: ElementRef, private http:Http) {
    window.scrollTo(0,0);
  }

  ngOnInit() {
    window.scrollTo(0,0);
    this.send_to_php();
  }

  change_poster_appearance(event){
    var container = this.element.nativeElement.querySelector('#overlay_top');
    var img = this.element.nativeElement.querySelector('#poster_1');

    var min = .45;
    var max = .75;

    var min_scale = 1;
    var max_scale = 1.25;

    var mult = currentYPosition()/320;

    if (currentYPosition() <= 320){
      img.style.display = "block";
      container.style.display = "block";
      var val = ((max - min)*mult) + min;
      container.style.background = "rgba(0,0,0," + val + ")";
      var val = ((max_scale - min_scale)*mult) + min_scale;
      img.style.transform = "scale(" + val + "," + val + ")";
    }else{
      img.style.display = "none";
      container.style.display = "none";
    }
  }

  send_to_php(){
    this.http.get('http://www.farmkart.com/email_sender.php')
        		.subscribe(res => this.got_data(res.json));
  }

  got_data(data){
    console.log(data);
  }

}


function currentYPosition() {
    // Firefox, Chrome, Opera, Safari
    if (self.pageYOffset) return self.pageYOffset;
    // Internet Explorer 6 - standards mode
    if (document.documentElement && document.documentElement.scrollTop)
        return document.documentElement.scrollTop;
    // Internet Explorer 6, 7 and 8
    if (document.body.scrollTop) return document.body.scrollTop;
    return 0;
}
