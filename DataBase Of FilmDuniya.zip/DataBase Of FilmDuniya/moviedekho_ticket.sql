CREATE DATABASE  IF NOT EXISTS `moviedekho` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `moviedekho`;
-- MySQL dump 10.13  Distrib 5.5.16, for Win32 (x86)
--
-- Host: localhost    Database: moviedekho
-- ------------------------------------------------------
-- Server version	5.1.25-rc-community

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ticket`
--

DROP TABLE IF EXISTS `ticket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ticket` (
  `TICKETID` int(11) NOT NULL AUTO_INCREMENT,
  `STATUS` varchar(255) DEFAULT NULL,
  `bookingId` int(11) DEFAULT NULL,
  `seatId` int(11) DEFAULT NULL,
  PRIMARY KEY (`TICKETID`),
  KEY `FK937B5F0CAD0A11EC` (`seatId`),
  KEY `FK937B5F0C60E70426` (`bookingId`),
  CONSTRAINT `FK937B5F0C60E70426` FOREIGN KEY (`bookingId`) REFERENCES `booking` (`BOOKINGID`),
  CONSTRAINT `FK937B5F0CAD0A11EC` FOREIGN KEY (`seatId`) REFERENCES `seat` (`SEATID`)
) ENGINE=InnoDB AUTO_INCREMENT=865 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket`
--

LOCK TABLES `ticket` WRITE;
/*!40000 ALTER TABLE `ticket` DISABLE KEYS */;
INSERT INTO `ticket` VALUES (649,'Cancelled',267,1),(650,'Active',267,2),(651,'Active',267,3),(710,'Active',287,1),(711,'Active',287,2),(712,'Cancelled',287,6),(745,'Cancelled',301,11),(746,'Active',301,21),(747,'Active',301,31),(748,'Active',302,12),(749,'Active',302,22),(750,'Cancelled',303,151),(751,'Active',303,161),(770,'Active',310,309),(771,'Active',310,310),(772,'Active',311,302),(773,'Active',311,303),(774,'Active',312,304),(775,'Active',312,305),(810,'Active',313,13),(811,'Active',313,14),(812,'Active',313,15),(813,'Cancelled',314,306),(814,'Active',314,307),(815,'Active',314,308),(816,'Cancelled',315,6),(817,'Active',315,7),(828,'Active',316,154),(829,'Active',316,155),(838,'Cancelled',317,153),(839,'Active',318,152),(840,'Active',318,153),(841,'Active',319,301),(842,'Active',320,8),(843,'Active',321,151),(844,'Active',321,162),(847,'Active',322,313),(848,'Cancelled',322,314),(849,'Active',323,106),(850,'Active',323,107),(853,'Active',324,306),(854,'Active',324,316),(855,'Active',325,34),(856,'Active',326,352),(857,'Active',327,44),(858,'Active',327,45),(859,'Cancelled',327,55),(860,'Cancelled',327,46),(861,'Active',327,56),(862,'Active',328,48),(863,'Active',328,58),(864,'Active',328,68);
/*!40000 ALTER TABLE `ticket` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-06-26 11:24:32
