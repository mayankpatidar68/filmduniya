CREATE DATABASE  IF NOT EXISTS `moviedekho` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `moviedekho`;
-- MySQL dump 10.13  Distrib 5.5.16, for Win32 (x86)
--
-- Host: localhost    Database: moviedekho
-- ------------------------------------------------------
-- Server version	5.1.25-rc-community

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `USERID` int(11) NOT NULL AUTO_INCREMENT,
  `CONTACTNUMBER` varchar(15) DEFAULT NULL,
  `EMAILID` varchar(45) DEFAULT NULL,
  `ENABLED` int(11) DEFAULT '1',
  `FIRSTNAME` varchar(20) DEFAULT NULL,
  `LASTNAME` varchar(25) DEFAULT NULL,
  `PASSWORD` varchar(30) DEFAULT NULL,
  `CONFIRMPASSWORD` varchar(30) DEFAULT NULL,
  `roleId` int(11) NOT NULL DEFAULT '2',
  PRIMARY KEY (`USERID`),
  UNIQUE KEY `EMAILID_UNIQUE` (`EMAILID`),
  KEY `FK27E3CB47B2C1A7` (`roleId`)
) ENGINE=InnoDB AUTO_INCREMENT=198 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'9893989368','mayankpith@gmail.com',1,'Mayank','Patidar','9893989368','9893989368',1),(2,'9993965444','jayeshptd@gmail.com',1,'Jayesh','Patidar','9993965444','9993965444',2),(8,'9993585601','anuragptd@gmail.com',1,'Anurag','Patidar','anurag123','anurag123',2),(67,'9993986422','sourabh.yaduvanshi@impetus.co.in',1,'sourabh','yaduvanshi','123456','123456',2),(70,'9893989368','mayank.patidar@impetus.co.in',1,'mayank','Patidar','M@yank123','M@yank123',2),(160,'dddd','ashwin.sahu@impetus.co.in',1,'ashwin','ashwin','ashwin','ashwin',2),(197,'8547596584','hgjgh@gmail.com',1,'ghjhj','hgjhgj','456123','456123',2);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-06-26 11:24:30
