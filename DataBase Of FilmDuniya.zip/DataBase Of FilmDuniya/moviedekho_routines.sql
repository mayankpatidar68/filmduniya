CREATE DATABASE  IF NOT EXISTS `moviedekho` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `moviedekho`;
-- MySQL dump 10.13  Distrib 5.5.16, for Win32 (x86)
--
-- Host: localhost    Database: moviedekho
-- ------------------------------------------------------
-- Server version	5.1.25-rc-community

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping routines for database 'moviedekho'
--
/*!50003 DROP PROCEDURE IF EXISTS `AddShows` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`localhost`*/ /*!50003 PROCEDURE `AddShows`()
BEGIN

INSERT INTO shows(`AVAILABLESEATS,DURATION,ENDTIME,FARE,SHOWDATE,STARTTIME,STATUS,movieId,theatreId`)
SELECT  `AVAILABLESEATS,DURATION,ENDTIME,FARE,SHOWDATE,STARTTIME,STATUS,movieId,theatreId` FROM temp; 
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `show_InserUpdateDelete` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`localhost`*/ /*!50003 PROCEDURE `show_InserUpdateDelete`(IN update_type varchar(20),
IN varAvailableSeats int,
IN varDuration varchar(255),
IN varEndtime Time,
IN varFare int,
IN varShowDate varchar(40),
IN varStarttime Time,
IN varStatus varchar(255),
IN varMovieId int,
IN varTheaterId int)
BEGIN

                IF(update_type = 'INSERT') THEN
                                INSERT INTO `moviedekho`.`shows`
                                (`AVAILABLESEATS`,`DURATION`,`ENDTIME`,`FARE`,`SHOWDATE`,`STARTTIME`,`STATUS`,`movieId`,`theatreId`)                
                                VALUES(varAvailableSeats,varDuration,varEndtime, varFare, varShowDate, varStarttime,varStatus, varMovieId, varTheaterId);
                ELSEIF(update_type = 'UPDATE') THEN
                                UPDATE `moviedekho`.`shows`
                                                SET
                                                                                                                                                                                                `availableSeats`=varAvailableSeats,
                                                                                                                                                                                                `duration` = varDuration,
                                                `endTime` = varEndtime,
                                                `fare` = varFare,
                                                `showDate` = varShowDate,
                                                `startTime` = varStarttime,
                                                                                                                                                                                                `status` = varStatus,
                                                `movieId` = varMovieId,
                                                `theatreId` = varTheaterId
                                                WHERE `showDate` = varShowDate And `startTime` = varStarttime AND `theatreId` = varTheaterId;
                ELSEIF(update_type = 'DELETE') THEN
                                DELETE FROM `moviedekho`.`shows`
                                WHERE `showDate` = varShowDate And `startTime` = varStarttime AND `theatreId` = varTheaterId;
                END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-06-26 11:24:35
