function validationUserRegister() {
            var phoneno = /^\d{10}$/;
           var x = document.getElementById("firstName").value;
            var check = /^([a-zA-Z0-9_\.\-])+\@([a-zA-Z]{5,7})+\.([a-zA-Z]{2,3})$/;
            var check1 = /^([a-zA-Z0-9_\.\-])+\@([a-zA-Z]{5,7})+\.([a-zA-Z]{2,3})+\.([a-zA-Z]{2,3})$/;
            var pattern = /^([a-zA-Z\s]{3,20})+$/;
       if (x == null || x == "") {
                  alert("First name is required ");
                  return false;
            }else if(!x.match(pattern))
                  {
                  alert("Name should be min 3 letters and contains alphabets");
            return false ;
                  }
            x = document.getElementById("lastName").value;
            if (x == null || x == "") {
                  alert("last name must be filled ");
                  return false;
            }else if(!x.match(pattern))
                  {
                  alert("Name should be min 3 letters and contains alphabets");
            return false ;
                  }
            x = document.getElementById("emailId").value;
            if (x == null || x == "") {
                  alert("Email Id is mandatory ");
                  return false;
            }
            else if (x.match(check) || x.match(check1)) {
                  
            	x = document.getElementById("contactNumber").value;
                if (x == null || x == "") {
                      alert("Contact No. is mandatory ");
                      return false;
                }  else if (!x.match(phoneno)) {
                      alert("Incorrect Contact No");
                      return false;
                } 
                x = document.getElementById("password").value;
                y = document.getElementById("confirmPassword").value;
                if (x == null || x == "") {
                      alert("password should not be left blank ");
                      return false;
                } else if( x !=  y){
               alert("password does not match");
               return false;
                }
                
                saveUser();
            }
            else{
                  alert("Please Enter Valid email id");
            return false;
            }
            
      }

        



function validationUserUpdate() {
	var phoneno1 = /^\d{10}$/;
	var x = document.getElementById("firstName").value;
	var check = /^([a-zA-Z0-9_\.\-])+\@([a-zA-Z]{5,7})+\.([a-zA-Z]{2,3})$/;
	var check1 = /^([a-zA-Z0-9_\.\-])+\@([a-zA-Z]{5,7})+\.([a-zA-Z]{2,3})+\.([a-zA-Z]{2,3})$/;
	var pattern = /^([a-zA-Z\s]{3,20})+$/;
    		if (x == null || x == "") {
		alert("First name is required ");
		return false;
	}else if(!x.match(pattern))
		{
		alert("Name should be min 3 letters and contains alphabets");
        return false ;
		}
	x = document.getElementById("lastName").value;
	if (x == null || x == "") {
		alert("last name must be filled ");
		return false;
	}else if(!x.match(pattern))
		{
		alert("Name should be min 3 letters and contains alphabets");
        return false ;
		}
	x = document.getElementById("emailId").value;
	if (x == null || x == "") {
		alert("Email Id is mandatory ");
		return false;
	}
	else if (x.match(check) || x.match(check1)) {
		return true;
	}
	else
		{
		alert("Please Enter Valid email id");
		return false;
		}
	x = document.getElementById("contactNumber").value;
	if (x == null || x == "") {
		alert("Contact No. is mandatory ");
		return false;
	}  else if (!x.match(phoneno1)) {
		alert("Incorrect Contact No");
		return false;
	} 
	updateProfile();
}

function validationAddMovie() {
	var Duration = /^\d{1}$/;
	var x = document.getElementById("movieName").value;
	var pattern = /^([a-zA-Z\s]{2,20})+$/;
    		if (x == null || x == "") {
		alert("Movie name is required ");
		return false;
	}else if(!x.match(pattern))
		{
		alert("Movie Name should be min 2 letters and contains alphabets");
        return false ;
		}
	x = document.getElementById("description").value;
	if (x == null || x == "") {
		alert("Description must be filled ");
		return false;
	}
	x = document.getElementById("releaseDate").value;
	if (x == null || x == "") {
		alert("Release Date is mandatory ");
		return false;
	}
	x = document.getElementById("duration").value;
	if (x == null || x == "") {
		alert("Duration is mandatory ");
		return false;
	}  else if (!x.match(Duration)) {
		alert("Duration should be of 1 letters and contains numbers");
		return false;
	}
	x = document.getElementById("status").value;
	if (x == null || x == "") {
		alert("Status is mandatory ");
		return false;
	}
	saveMovie();
}

function validationAddTheatre() {
	var Numeric = /^\d{2}$/;
	var x = document.getElementById("theatreName").value;
	var pattern = /^([a-zA-Z\s]{2,20})+$/;
    		if (x == null || x == "") {
		alert("Theatre name is required ");
		return false;
	}
    		else if(!x.match(pattern))
		{
		alert("Theatre Name should be min 2 letters and contains alphabets");
        return false ;
		}
	x = document.getElementById("noOfRows").value;
	if (x == null || x == "") {
		alert("No Of Rows must be filled ");
		return false;
	}
	else if (!x.match(Numeric)) {
		alert("Rows should between 1-10  and contains numbers");
		return false;
		}
	x = document.getElementById("noOfColumns").value;
	if (x == null || x == "") {
		alert("No Of Columns must be filled ");
		return false;
		}
	  else if (!x.match(Numeric)) {
			alert("Rows should between 1-15 and contains numbers");
			return false;
			}
	x = document.getElementById("status").value;
	if (x == null || x == "") {
		alert("Status is mandatory ");
		return false;
	}
	x = document.getElementById("cityId").value;
	if (x == 0 || x == "") {
		alert("Please select city");
		return false;
	}
	saveTheatre();
}

	
	
function validationAddCity() {
	var x = document.getElementById("cityName").value;
	var pattern = /^([a-zA-Z\s]{2,20})+$/;
    		if (x == null || x == "") {
		alert("City name is required ");
		return false;
	}else if(!x.match(pattern))
		{
		alert("City Name should be min 2 letters and contains alphabets");
        return false ;
		}
    		saveCity();
    		
}

function validationUpdateMovie() {
	var x = document.getElementById("movieName").value;
	var pattern = /^([a-zA-Z\s]{2,20})+$/;
    		if (x == null || x == "") {
		alert("Movie name is required ");
		return false;
	}else if(!x.match(pattern))
		{
		alert("Movie Name should be min 2 letters and contains alphabets");
        return false ;
		}
	x = document.getElementById("description").value;
	if (x == null || x == "") {
		alert("Description must be filled ");
		return false;
	}
	x = document.getElementById("releaseDate").value;
	if (x == null || x == "") {
		alert("Release Date is mandatory ");
		return false;
	}
	x = document.getElementById("duration").value;
	if (x == null || x == "") {
		alert("Duration is mandatory ");
		return false;
	}
	saveMovie();
}

function searchValidation() {
	var x = document.getElementById("cityDropDown").value;
    		if (x == 0 || x == "") {
		alert("Please select City ");
		return false;
	}
	x = document.getElementById("theatreDropDown").value;
	if (x == 0 || x == "") {
		alert("Please select theatre");
		return false;
	}
	x = document.getElementById("movieDropDown").value;
	if (x == 0 || x == "") {
		alert("Please select movie");
		return false;
	}
	x = document.getElementById("numberOfSeats").value;
	if (x == null || x == "") {
		alert("Number of seats is mandatory ");
		return false;
	}
	x = document.getElementById("showDate").value;
	if (x == null || x == "") {
		alert("Show Date is mandatory ");
		return false;
	}
	 search();
}

function loginPageValidation() {
	var check = /^([a-zA-Z0-9_\.\-])+\@([a-zA-Z]{5,7})+\.([a-zA-Z]{2,3})$/;
	var check1 = /^([a-zA-Z0-9_\.\-])+\@([a-zA-Z]{5,7})+\.([a-zA-Z]{2,3})+\.([a-zA-Z]{2,3})$/;
	var x=document.getElementById("login").value;
	if (x==null || x=="")
    {
     alert("User Name Required");
     return false;
    }else if (x.match(check) || x.match(check1)) 
    {
    	var y=document.getElementById("password").value;
    	if (y==null || y=="")
        {
         alert("Password Required");
         return false;
        }return true;
	}
    else
    	{
    	alert("Invalid email Id format.");
		return false;
    	}
	
}


function generateReportValidation() {
	var x = document.getElementById("movieDropDown").value;
	if (x == 0 || x == "") {
		alert("Please select Movie");
		return false;
	}
	x = document.getElementById("showDate").value;
	if (x == null || x == "") {
		alert("Please select Show Date");
		return false;
	}
}



function fileuploadValidation(){
	
	var x = document.getElementById("upload").value;
	if (x == 0 || x == "") {
		alert("Please select File");
		return false;
	}
	
}

function validationPaymentGateway() {
 	var Crdno = /^\d{16}$/;
 	var Cvvno = /^\d{4}$/;
	var x = document.getElementById("cardNumber").value;
	var pattern = /^([a-zA-Z\s]{3,20})+$/;
  		if (x == null || x == "") {
		alert("card number is required ");
		return false;
	}else if(!x.match(Crdno))
		{
		alert("please enter valid 16 digit Card Number ");
      return false ;
		}
	x = document.getElementById("nameOnCard").value;
	if (x == null || x == "") {
		alert("name must be filled ");
		return false;
	}else if(!x.match(pattern))
		{
		alert("Name should be min 3 letters and contains alphabets");
      return false ;
		}
	x = document.getElementById("cardType").value;
	if (x == null || x == "") {
		alert("card type is mandatory ");
		return false;
	}
	x = document.getElementById("expiryMonth").value;
	if (x == null || x == "") {
		alert("month must be filled ");
		return false;
	}
	x = document.getElementById("expiryYear").value;
	if (x == null || x == "") {
		alert("year must be filled");
		return false;
	}
	x = document.getElementById("cvvNumber").value;
	if (x == null || x == "") {
		alert("Cvv No. is mandatory ");
		return false;
	}  else if (!x.match(Cvvno)) {
		alert("Please Enter valid  4 digit CVV numbers");
		return false;
	} 
	
	
}

function forgotPasswordValidation() {
	var check = /^([a-zA-Z0-9_\.\-])+\@([a-zA-Z]{5,7})+\.([a-zA-Z]{2,3})$/;
	var check1 = /^([a-zA-Z0-9_\.\-])+\@([a-zA-Z]{5,7})+\.([a-zA-Z]{2,3})+\.([a-zA-Z]{2,3})$/;
	var x=document.getElementById("login").value;
	if (x==null || x=="")
    {
     alert("User EmailId Required");
     return false;
    }else if (x.match(check) || x.match(check1)) 
    {
    	 sendMail();
	}
    else
    	{
    	alert("Invalid email Id format.");
		return false;
    	}
	
}
