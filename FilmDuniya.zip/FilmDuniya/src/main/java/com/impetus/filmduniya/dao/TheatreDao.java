package com.impetus.filmduniya.dao;

import java.util.List;

import com.impetus.filmduniya.dto.Theatre;


/**
 * Data Access interface for theatre table in database.
 * 
 * @author mayank.patidar
 */
public interface TheatreDao {

   
    /**
     * Gets the all theatres by city id.
     *
     * @param cityId the city id
     * @return the all theatres by city id
     */
    List<Theatre> getAllTheatresByCityId(int cityId);

    
    /**
     * Gets the all theatres.
     *
     * @return the all theatres
     */
    List<Theatre> getAllTheatres();

    
    /**
     * Delete.
     *
     * @param theatreId the theatre id
     */
    void delete(int theatreId);

    
    /**
     * Adds the theatre.
     *
     * @param theatre the theatre
     */
    void addTheatre(Theatre theatre);

}
