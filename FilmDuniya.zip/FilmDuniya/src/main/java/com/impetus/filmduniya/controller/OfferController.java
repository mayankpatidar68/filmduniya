package com.impetus.filmduniya.controller;

import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityExistsException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import com.impetus.filmduniya.dto.Offer;
import com.impetus.filmduniya.exception.DAOException;
import com.impetus.filmduniya.service.OfferService;
import com.impetus.filmduniya.vo.FileUploadForm;
import com.impetus.filmduniya.vo.FileUploadValidator;



/**
 * The Class OfferController.
 *
 * @author mayank.patidar
 */
@Controller
public class OfferController {

    /** logs the details of class. */
    private static Logger logger = LoggerFactory
            .getLogger(BookingController.class);
    
    /** The seat service. */
    @Autowired
    private OfferService offerService;
    
    /** The offer map. */
    private Map<String, Offer> offerMap = new HashMap<String, Offer>();
    
    /** The file validator. */
    @Autowired
    private FileUploadValidator fileValidator;
    
    
    /**
     * Handles the request to view Offer Management Page.
     * 
     * @return the JSP page of Offer Management
     */
    @RequestMapping(value = "/manageOffer", method = RequestMethod.GET)
    public String addingOffer() {
        logger.info("Request to show offer upload page");
        return "uploadOffer";
    }
    
    /**
     * Display offer form.
     * 
     * @return the string
     */
    @RequestMapping(value = "/offerUpload", method = RequestMethod.GET)
    public String displayOfferForm() {
        return "offers";
    }
    
    /**
     * Handles the request to check offerCode.
     * 
     * @param showId
     *            the show id
     * @return discount to be given depending on offercode
     */
    @RequestMapping(value = "/offer", method = RequestMethod.GET)
    @ResponseBody
    public List<Offer> getOffer(int showId) {

        logger.info("Request to check and attach offer");
        return offerService.getOfferForShow(showId);

    }

    /**
     * Check offer.
     * 
     * @param dealCode
     *            the deal code
     * @param showId
     *            the show id
     * @return the offer
     */
    @RequestMapping(value = "/checkOffer", method = RequestMethod.GET)
    @ResponseBody
    public Offer checkOffer(String dealCode, int showId) {

        logger.info("Checking offer if applicable");
        return offerService.checkOffer(dealCode, showId);
    }
    
    /**
     * Upload xmlfile.
     *
     * @param uploadOffer            the upload offer
     * @param result            the result
     * @param map            the map
     * @return the string
     * @throws IOException Signals that an I/O exception has occurred.
     */
    @RequestMapping(value = "/offerUpload", method = RequestMethod.POST)
    public String uploadXMLfile(
            @ModelAttribute("uploadOffer") FileUploadForm uploadOffer,
            BindingResult result, Model map)throws IOException {

        MultipartFile file = uploadOffer.getFile();
        fileValidator.validateOffers(uploadOffer, result);
        String fileName = file.getOriginalFilename();
        if (result.hasErrors()) {
            return "SearchMovie";
        }

        InputStream inputStream = null;

        try {
            inputStream = file.getInputStream();

            DocumentBuilderFactory dbFactory = DocumentBuilderFactory
                    .newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(inputStream);
            NodeList nList = doc.getElementsByTagName("offer");
            for (int temp = 0; temp < nList.getLength(); ++temp) {

                Node nNode = nList.item(temp);

                if (nNode.getNodeType() == Node.ELEMENT_NODE) {

                    Element eElement = (Element) nNode;

                    SimpleDateFormat formatter = new SimpleDateFormat(
                            "yyyy-MM-dd");

                    Offer offer = new Offer();

                    Integer intDiscount = Integer.parseInt(eElement
                            .getElementsByTagName("discount").item(0)
                            .getTextContent());
                    offer.setDiscount(intDiscount);

                    String strDesc = eElement
                            .getElementsByTagName("description").item(0)
                            .getTextContent();
                    offer.setDescription(strDesc);

                    java.util.Date endDate = formatter.parse(eElement
                            .getElementsByTagName("enddate").item(0)
                            .getTextContent());
                    offer.setEndDate(endDate);

                    java.util.Date startDate = formatter.parse(eElement
                            .getElementsByTagName("startdate").item(0)
                            .getTextContent());
                    offer.setStartDate(startDate);

                    String offerCode = eElement
                            .getElementsByTagName("offerCode").item(0)
                            .getTextContent();
                    offer.setOfferCode(offerCode);

                    String type = eElement.getElementsByTagName("type").item(0)
                            .getTextContent();
                    offer.setType(type);
                    offerMap.put("offer", offer);

                    offerService.addOffer(offer);

                }
            }
        } catch (Exception e) {

            logger.debug("exception {}",e);
        }

        map.addAttribute("name", fileName);
        return "showFile";

    }
    
    /**
     * Handle exception.
     * 
     * @param e
     *            the e
     * @return the model and view
     */
    @ExceptionHandler(DAOException.class)
    public ModelAndView handleException(DAOException e) {
        ModelAndView modelAndView12 = new ModelAndView();
        modelAndView12.setViewName("error");
        modelAndView12.addObject("error_message","Something went wrong, Server not Available");
        return modelAndView12;
    }

    /**
     * Handle exception.
     * 
     * @param e
     *            the e
     * @return the model and view
     */
    @ExceptionHandler(Exception.class)
    public ModelAndView handleException(Exception e) {
        ModelAndView modelAndView13 = new ModelAndView();
        modelAndView13.setViewName("error");
        modelAndView13.addObject("error_message",
                "Something went wrong, Server not Available");
        return modelAndView13;
    }

    /**
     * Handle entity exception.
     * 
     * @param e
     *            the e
     * @return the model and view
     */
    @ExceptionHandler(EntityExistsException.class)
    public ModelAndView handleEntityException(EntityExistsException e) { 
        ModelAndView modelAndView14 = new ModelAndView();
        modelAndView14.setViewName("error");
        modelAndView14.addObject("error_message", "Something went wrong, Server not Available");
        return modelAndView14;
    }
}
