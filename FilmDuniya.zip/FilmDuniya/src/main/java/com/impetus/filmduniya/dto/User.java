package com.impetus.filmduniya.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.Table;


/**
 * @author mayank.patidar
 *
 */
/**
 * The Class User.
 */
@Entity
@Table(name = "USER")
public class User implements Serializable {

    /** The user id. */
    @Id
    @Column(name = "USERID")
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int userId;

    /** The email id. */
    @Column(name = "EMAILID")
    private String emailId;

    /** The first name. */
    @Column(name = "FIRSTNAME")
    private String firstName;

    /** The last name. */
    @Column(name = "LASTNAME")
    private String lastName;

    /** The contact number. */
    @Column(name = "CONTACTNUMBER")
    private String contactNumber;

    /** The password. */
    @Column(name = "PASSWORD")
    private String password;

    /** The confirm password. */
    @Column(name = "CONFIRMPASSWORD")
    private String confirmPassword;

    /**
     * Gets the user id.
     * 
     * @return the user id
     */
    public int getUserId() {
        return userId;
    }

    /**
     * Sets the user id.
     * 
     * @param userId
     *            the new user id
     */
    public void setUserId(int userId) {
        this.userId = userId;
    }

    /**
     * Gets the email id.
     * 
     * @return the email id
     */
    public String getEmailId() {
        return emailId;
    }

    /**
     * Sets the email id.
     * 
     * @param emailId
     *            the new email id
     */
    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    /**
     * Gets the first name.
     * 
     * @return the first name
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * Sets the first name.
     * 
     * @param firstName
     *            the new first name
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * Gets the last name.
     * 
     * @return the last name
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * Sets the last name.
     * 
     * @param lastName
     *            the new last name
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * Gets the contact number.
     * 
     * @return the contact number
     */
    public String getContactNumber() {
        return contactNumber;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "User [userId=" + userId + ", emailId=" + emailId
                + ", firstName=" + firstName + ", lastName=" + lastName
                + ", contactNumber=" + contactNumber + ", password=" + password
                + ", ]";
    }

    /**
     * Sets the contact number.
     * 
     * @param contactNumber
     *            the new contact number
     */
    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    /**
     * Gets the password.
     * 
     * @return the password
     */
    public String getPassword() {
        return password;
    }

    /**
     * Sets the password.
     * 
     * @param password
     *            the new password
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * Gets the confirm password.
     * 
     * @return the confirm password
     */
    public String getConfirmPassword() {
        return confirmPassword;
    }

    /**
     * Sets the confirm password.
     * 
     * @param confirmPassword
     *            the new confirm password
     */
    public void setConfirmPassword(String confirmPassword) {
        this.confirmPassword = confirmPassword;
    }

    /**
     * Gets the enabled.
     * 
     * @return the enabled
     */

}
