package com.impetus.filmduniya.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * @author mayank.patidar
 *
 */
/**
 * The Class Roles.
 */
@Entity
@Table(name = "ROLES")
public class Roles {

    /** The role id. */
    @Id
    @Column(name = "ROLEID")
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int roleId;

    /** The role. */
    @Column(name = "ROLE")
    private String role;

    /**
     * Gets the role id.
     * 
     * @return the role id
     */
    public int getRoleId() {
        return roleId;
    }

    /**
     * Sets the role id.
     * 
     * @param roleId
     *            the new role id
     */
    public void setRoleId(int roleId) {
        this.roleId = roleId;
    }

    /**
     * Gets the role.
     * 
     * @return the role
     */
    public String getRole() {
        return role;
    }

    /**
     * Sets the role.
     * 
     * @param role
     *            the new role
     */
    public void setRole(String role) {
        this.role = role;
    }

}
