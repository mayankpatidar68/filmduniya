package com.impetus.filmduniya.dao;

import java.util.Date;
import java.util.List;

import com.impetus.filmduniya.dto.Booking;

/**
 * The Interface BookingDao.
 * 
 * @author mayank.patidar
 */
public interface BookingDao {

    /**
     * Save booking.
     * 
     * @param booking
     *            the booking
     * @return the booking
     */
    Booking saveBooking(Booking booking);

    /**
     * Gets the.
     * 
     * @param bookingId
     *            the booking id
     * @return the booking
     */
    Booking get(int bookingId);

    /**
     * Gets the booking by movie date.
     *
     * @param movieId the movie id
     * @param showDate the show date
     * @return the booking by movie date
     */
    List<Booking> getBookingByMovieDate(int movieId, Date showDate);


    /**
     * Send show mail.
     * 
     * @return the list
     */
    List<Booking> sendScheduleMail();


}
