package com.impetus.filmduniya.service;

import java.text.ParseException;


import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.impetus.filmduniya.dao.ShowDao;
import com.impetus.filmduniya.dto.Shows;





/**
 * The Class ShowServiceImpl.
 *
 * @author mayank.patidar
 */
/**
 * The Class ShowServiceImpl.
 */
@Service
@Transactional
public class ShowServiceImpl implements ShowService {



    /** logs the details of class. */
    private static Logger logger = LoggerFactory
            .getLogger(ShowServiceImpl.class);

    /** The show dao. */
    @Autowired
    private ShowDao showDao;

    /*
     * @see
     * com.impetus.filmduniya.service.ShowService#getAllShowsByCriteria(int,
     * int, int, int, java.lang.String)
     */

    /**
     * Gets the all shows by criteria.
     *
     * @param cityId the city id
     * @param theatreId the theatre id
     * @param movieId the movie id
     * @param noOfSeats the no of seats
     * @param showDate the show date
     * @return the all shows by criteria
     */
    public List<Shows> getAllShowsByCriteria(int cityId, int theatreId,
            int movieId, int noOfSeats, String showDate) {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        Date showSearchDate = null;
        try {
            showSearchDate = formatter.parse(showDate);
        } catch (ParseException e) {

            logger.error("Error in GetAll Shows By Criteria", e);
        }

        return showDao.getAllShowsByCriteria(cityId, theatreId, movieId,
                noOfSeats, showSearchDate);
    }

    /*
     * @see com.impetus.filmduniya.service.ShowService#getByShowId(int)
     */

    /**
     * Gets the by show id.
     *
     * @param showId the show id
     * @return the by show id
     */
    public Shows getByShowId(int showId) {

        return showDao.getByShowId(showId);
    }

    /*
     * @see
     * com.impetus.filmduniya.service.ShowService#updateAvailableSeats(com.impetus
     * .filmduniya.dto.Shows)
     */
    /**
     * Update available seats.
     *
     * @param show the show
     * @return the int
     */
    public int updateAvailableSeats(Shows show) {
        return showDao.updateAvailableSeats(show);
    }

    /*
     * @see
     * com.impetus.filmduniya.service.ShowService#addShow(com.impetus.filmduniya
     * .dto.Shows)
     */
    /**
     * Adds the show.
     *
     * @param show the show
     */
    public void addShow(Shows show) {

        showDao.addShow(show);
    }

    /*
     * @see com.impetus.filmduniya.service.ShowService#getAllShowss()
     */
    /**
     * Gets the all showss.
     *
     * @return the all showss
     */
    public List<Shows> getAllShowss() {
        return showDao.getAllShowss();
    }

    /* (non-Javadoc)
     * @see com.impetus.filmduniya.service.ShowService#updateShow(com.impetus.filmduniya.dto.Shows)
     */
    /**
     * Update Show.
     *
     * @param shows the shows
     * @return the show
     */
    public void updateShow(Shows shows) {
        
        showDao.updateShow(shows);
        
    }

    /* (non-Javadoc)
     * @see com.impetus.filmduniya.service.ShowService#deleteShow(com.impetus.filmduniya.dto.Shows)
     */
    /**
     * Delete.
     *
     * @param show the show
     */
    public void deleteShow(Shows show) {
      
        showDao.deleteShow(show);
        
    }

    /* (non-Javadoc)
     * @see com.impetus.filmduniya.service.ShowService#addUpdateDeleteShow(java.lang.String, int, java.lang.String, java.lang.String, int, int, java.lang.String, int, java.lang.String, java.lang.String)
     */
    /**
     * @param endTime the end time
     * @param fare the fare
     * @param showDate the show date
     * @param startTime the start time
     * @param movieId the movie id
     * @param theatreId the theatre id
     * @param action the action
     * @param availableSeats the available seats
     * @param duration the duration
     * @param status the status
     */
    public void addUpdateDeleteShow(String[] time2Array, int fare, String showDate, int movieId, int theatreId,int availableSeats,String status) {
       
        showDao.addUpdateDeleteShow(time2Array, fare, showDate, movieId,theatreId,  availableSeats, status);
        
    }

    
    /* (non-Javadoc)
     * @see com.impetus.service.ShowServicee#getList(int, int, java.lang.String)
     */
    /**
     * Gets the all shows.
     *
     * @param movieId the movie id
     * @param theatreId the theatre id
     * @param date the date
     * @return the all shows
     */
    public List<Shows> getList(int movieId, int theatreId, String date) {
        return showDao.getfromShow(theatreId, movieId ,date);
    }
}



