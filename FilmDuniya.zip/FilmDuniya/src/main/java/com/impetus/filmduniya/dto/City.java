package com.impetus.filmduniya.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * @author mayank.patidar
 *
 */
/**
 * The Class City.
 */
@Entity
@Table(name = "CITY")
public class City {

    /** The city id. */
    @Id
    @Column(name = "CITYID")
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int cityId;

    /** The city name. */
    @Column(name = "CITY_NAME")
    private String cityName;

    /**
     * Gets the city id.
     * 
     * @return the city id
     */
    public int getCityId() {
        return cityId;
    }

    /**
     * Sets the city id.
     * 
     * @param cityId
     *            the new city id
     */
    public void setCityId(int cityId) {
        this.cityId = cityId;
    }

    /**
     * Gets the city name.
     * 
     * @return the city name
     */
    public String getCityName() {
        return cityName;
    }

    /**
     * Sets the city name.
     * 
     * @param cityName
     *            the new city name
     */
    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

}
