package com.impetus.filmduniya.service;

import java.util.List;

import com.impetus.filmduniya.dto.Booking;
import com.impetus.filmduniya.dto.Ticket;
import com.impetus.filmduniya.dto.User;




/**
 * @author mayank.patidar
 */
/**
 * The Interface BookingHistoryService.
 */
public interface BookingHistoryService {

    
    /**
     * Gets the booking history.
     *
     * @param user the user
     * @return the booking history
     */
    List<Booking> getBookingHistory(User user);

    
    /**
     * Gets the ticket details.
     *
     * @param bookingId the booking id
     * @return the ticket details
     */
    List<Ticket> getTicketDetails(int bookingId);

    
    
    /**
     * Cancel ticket.
     *
     * @param cancelTicketId the cancel ticket id
     * @return the int
     */
    int cancelTicket(int cancelTicketId);
}
