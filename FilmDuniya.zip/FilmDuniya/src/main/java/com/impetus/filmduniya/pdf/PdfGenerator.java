package com.impetus.filmduniya.pdf;

import java.util.List;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.itextpdf.text.DocumentException;
import com.impetus.filmduniya.pdf.AbstractITextPdfView;
import com.impetus.filmduniya.dto.Booking;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;


/**
 * The Class PdfGenerator.
 *
 * @author mayank.patidar
 */
public class PdfGenerator extends AbstractITextPdfView {

    /** The Constant TABLE_SIZE. */
    public static final int TABLE_SIZE = 7;

    /** The Constant WIDTH_PERCENTAGE. */
    public static final float WIDTH_PERCENTAGE = 100.0f;

    /** The Constant TABLE_SPACING. */
    public static final int TABLE_SPACING = 10;

    /** The Constant TABLE_CELL_PADDING. */
    public static final int TABLE_CELL_PADDING = 6;

    /*
     * @see
     * com.impetus.filmduniya.pdf.AbstractITextPdfView#buildPdfDocument(java
     * .util.Map, com.itextpdf.text.Document, com.itextpdf.text.pdf.PdfWriter,
     * javax.servlet.http.HttpServletRequest,
     * javax.servlet.http.HttpServletResponse)
     */
    @Override
    protected void buildPdfDocument(Map<String, Object> model,
            Document document, PdfWriter writer, HttpServletRequest request,
            HttpServletResponse response) {

        List<Booking> bookingList = (List<Booking>) model.get("bookingList");

        PdfPTable table = new PdfPTable(TABLE_SIZE);
        table.setWidthPercentage(WIDTH_PERCENTAGE);
        table.setSpacingBefore(TABLE_SPACING);

        // define font for table header row
        Font font = FontFactory.getFont(FontFactory.TIMES_ROMAN);
        font.setColor(BaseColor.WHITE);

        // define table header cell
        PdfPCell cell = new PdfPCell();
        cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
        cell.setPadding(TABLE_CELL_PADDING);

        // write table header
        cell.setPhrase(new Phrase("Name of User", font));
        table.addCell(cell);

        cell.setPhrase(new Phrase("Theatre Name", font));
        table.addCell(cell);

        cell.setPhrase(new Phrase("Number of Tickets", font));
        table.addCell(cell);

        cell.setPhrase(new Phrase("Actual Fare", font));
        table.addCell(cell);

        cell.setPhrase(new Phrase("Final Fare", font));
        table.addCell(cell);

        cell.setPhrase(new Phrase("Email-Id", font));
        table.addCell(cell);
        cell.setPhrase(new Phrase("Contact Number", font));
        table.addCell(cell);

        // write table row data
        for (Booking booking : bookingList) {

            table.addCell(booking.getUser().getFirstName() + " "
                    + booking.getUser().getLastName());
            table.addCell(booking.getShow().getTheatre().getTheatreName());
            table.addCell(String.valueOf(booking.getNoOfTickets()));
            table.addCell(String.valueOf(booking.getActualFare()));
            table.addCell(String.valueOf(booking.getTotalFare()));
            table.addCell(booking.getUser().getEmailId());
            table.addCell(booking.getUser().getContactNumber());

        }
        try {
            document.add(table);
        } catch (DocumentException e) {
            logger.error("Document Exception occured in PDF file" + e);
        }

    }

}
