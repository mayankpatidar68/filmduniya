package com.impetus.filmduniya.vo;


/**
 * @author mayank.patidar
 *
 */
/**
 * The Class TheatreTemp.
 */
public class TheatreVO {

    /** The city. */
    private String cityId;

    /** The theatre name. */
    private String theatreName;

    /** The no of rows. */
    private Integer noOfRows;

    /** The no of columns. */
    private Integer noOfColumns;

    /** The status. */
    private String status;

    /**
     * Gets the city id.
     * 
     * @return the city id
     */
    public String getCityId() {
        return cityId;
    }

    /**
     * Sets the city id.
     * 
     * @param cityId
     *            the new city id
     */
    public void setCityId(String cityId) {
        this.cityId = cityId;
    }

    /**
     * Gets the theatre name.
     * 
     * @return the theatre name
     */
    public String getTheatreName() {
        return theatreName;
    }

    /**
     * Sets the theatre name.
     * 
     * @param theatreName
     *            the new theatre name
     */
    public void setTheatreName(String theatreName) {
        this.theatreName = theatreName;
    }

    /**
     * Gets the no of rows.
     * 
     * @return the no of rows
     */
    public Integer getNoOfRows() {
        return noOfRows;
    }

    /**
     * Sets the no of rows.
     * 
     * @param noOfRows
     *            the new no of rows
     */
    public void setNoOfRows(Integer noOfRows) {
        this.noOfRows = noOfRows;
    }

    /**
     * Gets the no of columns.
     * 
     * @return the no of columns
     */
    public Integer getNoOfColumns() {
        return noOfColumns;
    }

    /**
     * Sets the no of columns.
     * 
     * @param noOfColumns
     *            the new no of columns
     */
    public void setNoOfColumns(Integer noOfColumns) {
        this.noOfColumns = noOfColumns;
    }

    /**
     * Gets the status.
     * 
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the status.
     * 
     * @param status
     *            the new status
     */
    public void setStatus(String status) {
        this.status = status;
    }

}
