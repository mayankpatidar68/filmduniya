package com.impetus.filmduniya.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


/**
 * @author mayank.patidar
 *
 */
/**
 * The Class Shows.
 */
@Entity
@Table(name = "SHOWS")
public class Shows {

    /** The show id. */
    @Id
    @Column(name = "SHOWID")
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int showId;

    /** The movie. */
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "movieId")
    private Movie movie;

    /** The theatre. */
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "theatreId")
    private Theatre theatre;

    /** The show date. */
    @Column(name = "SHOWDATE")
    private String showDate;

    /** The start time. */
    @Column(name = "STARTTIME")
    private String startTime;

    /** The end time. */
    @Column(name = "ENDTIME")
    private String endTime;

    /** The fare. */
    @Column(name = "FARE")
    private Integer fare;

    /** The available seats. */
    @Column(name = "AVAILABLESEATS")
    private Integer availableSeats;

    /** The duration. */
    @Column(name = "DURATION")
    private String duration;

    /** The status. */
    @Column(name = "STATUS")
    private String status;

    /**
     * Gets the show id.
     * 
     * @return the show id
     */
    public int getShowId() {
        return showId;
    }

    /**
     * Sets the show id.
     * 
     * @param showId
     *            the new show id
     */
    public void setShowId(int showId) {
        this.showId = showId;
    }

    /**
     * Gets the movie.
     * 
     * @return the movie
     */
    public Movie getMovie() {
        return movie;
    }

    /**
     * Sets the movie.
     * 
     * @param movie
     *            the new movie
     */
    public void setMovie(Movie movie) {
        this.movie = movie;
    }

    /**
     * Gets the theatre.
     * 
     * @return the theatre
     */
    public Theatre getTheatre() {
        return theatre;
    }

    /**
     * Sets the theatre.
     * 
     * @param theatre
     *            the new theatre
     */
    public void setTheatre(Theatre theatre) {
        this.theatre = theatre;
    }

    /**
     * Gets the show date.
     * 
     * @return the show date
     */
    public String getShowDate() {
        return showDate;
    }

    /**
     * Sets the show date.
     * 
     * @param showDate
     *            the new show date
     */
    public void setShowDate(String showDate) {
        this.showDate = showDate;
    }

    /**
     * Gets the start time.
     * 
     * @return the start time
     */
    public String getStartTime() {
        return startTime;
    }

    /**
     * Sets the start time.
     * 
     * @param startTime
     *            the new start time
     */
    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    /**
     * Gets the end time.
     * 
     * @return the end time
     */
    public String getEndTime() {
        return endTime;
    }

    /**
     * Sets the end time.
     * 
     * @param endTime
     *            the new end time
     */
    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    /**
     * Gets the fare.
     * 
     * @return the fare
     */
    public Integer getFare() {
        return fare;
    }

    /**
     * Sets the fare.
     * 
     * @param fare
     *            the new fare
     */
    public void setFare(Integer fare) {
        this.fare = fare;
    }

    /**
     * Gets the available seats.
     * 
     * @return the available seats
     */
    public Integer getAvailableSeats() {
        return availableSeats;
    }

    /**
     * Sets the available seats.
     * 
     * @param availableSeats
     *            the new available seats
     */
    public void setAvailableSeats(Integer availableSeats) {
        this.availableSeats = availableSeats;
    }

    /**
     * Gets the duration.
     * 
     * @return the duration
     */
    public String getDuration() {
        return duration;
    }

    /**
     * Sets the duration.
     * 
     * @param duration
     *            the new duration
     */
    public void setDuration(String duration) {
        this.duration = duration;
    }

    /**
     * Gets the status.
     * 
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the status.
     * 
     * @param status
     *            the new status
     */
    public void setStatus(String status) {
        this.status = status;
    }

}
