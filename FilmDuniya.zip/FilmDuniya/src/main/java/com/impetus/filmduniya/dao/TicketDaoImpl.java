package com.impetus.filmduniya.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.impetus.filmduniya.dto.Ticket;

/**
 * @author mayank.patidar
 * 
 */
/**
 * The Class TicketDaoImpl.
 */
@Repository
public class TicketDaoImpl implements TicketDao {
    
    /** logs the details of class. */
    private static Logger logger = LoggerFactory
            .getLogger(TicketDaoImpl.class);

    /** The session factory. */
    @Autowired
    private SessionFactory sessionFactory;

    /**
     * Sets the session factory.
     * 
     * @param sessionFactory
     *            the new session factory
     */
    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    /*
     * @see com.impetus.filmduniya.dao.TicketDao#addMovie(com.impetus.filmduniya
     * .dto.Ticket)
     */
    /**
     * Save.
     * 
     * @param ticket
     *            the ticket
     */
    public void save(Ticket ticket) {

        this.sessionFactory.getCurrentSession().save(ticket);
        logger.debug("Adding ticket");
    }

    /*
     * @see com.impetus.filmduniya.dao.TicketDao#get(int)
     */
    /**
     * Gets the.
     * 
     * @param cancelTicketId
     *            the cancel ticket id
     * @return the ticket
     */
    public Ticket get(int cancelTicketId) {

        Session session = this.sessionFactory.getCurrentSession();
        
        logger.info("Ticket Cancelled");
        logger.debug("Ticket Cancelled");
        return (Ticket) session.get(Ticket.class, cancelTicketId);
    }

    /*
     * @see
     * com.impetus.filmduniya.dao.TicketDao#update(com.impetus.filmduniya.dto
     * .Ticket)
     */
    /**
     * Update.
     * 
     * @param ticket
     *            the ticket
     */
    public void update(Ticket ticket) {

        this.sessionFactory.getCurrentSession().update(ticket);
    }

}
