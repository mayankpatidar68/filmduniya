package com.impetus.filmduniya.service;

import java.util.List;

import com.impetus.filmduniya.dto.Shows;




/**
 * The Interface ShowService.
 *
 * @author mayank.patidar
 */
public interface ShowService {

    
    
    /**
     * Adds the show.
     *
     * @param show the show
     */
    void addShow(Shows show);

    
    
    /**
     * Gets the all shows by criteria.
     *
     * @param cityId the city id
     * @param theatreId the theatre id
     * @param movieId the movie id
     * @param noOfSeats the no of seats
     * @param showDate the show date
     * @return the all shows by criteria
     */
    List<Shows> getAllShowsByCriteria(int cityId, int theatreId, int movieId,
            int noOfSeats, String showDate);

   
    
    
    /**
     * Gets the by show id.
     *
     * @param showId the show id
     * @return the by show id
     */
    Shows getByShowId(int showId);

   
    
   
    /**
     * Update available seats.
     *
     * @param show the show
     * @return the int
     */
    int updateAvailableSeats(Shows show);

   
    
    /**
     * Gets the all showss.
     *
     * @return the all showss
     */
    List<Shows> getAllShowss();

    /**
     * Update show.
     *
     * @param shows the shows
     */
    void updateShow(Shows shows);
    
    /**
     * Delete show.
     *
     * @param show the show
     */
    void deleteShow(Shows show);
    
    /**
     * Adds the update delete show.
     *
     * @param endTime the end time
     * @param fare the fare
     * @param showDate the show date
     * @param startTime the start time
     * @param movieId the movie id
     * @param theatreId the theatre id
     * @param action the action
     * @param availableSeats the available seats
     * @param duration the duration
     * @param status the status
     */
    void addUpdateDeleteShow(String[] time2Array, int fare, String showDate,
            int parseInt, int parseInt2, int availableSeats, String status);
    
    /**
     * Gets the list.
     *
     * @param movieId the movie id
     * @param theatreId the theatre id
     * @param date the date
     * @return the list
     */
    List<Shows> getList(int movieId, int theatreId, String date);



    
}
