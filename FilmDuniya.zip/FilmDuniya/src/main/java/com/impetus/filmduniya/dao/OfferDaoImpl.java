package com.impetus.filmduniya.dao;




import java.util.Date;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.exception.ConstraintViolationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import com.impetus.filmduniya.dto.Offer;
import com.impetus.filmduniya.dto.Shows;
import com.impetus.filmduniya.exception.DAOException;


/**
 * Implementation of interface OfferDao.
 * 
 * @author mayank.patidar
 */
@Repository
public class OfferDaoImpl implements OfferDao {

    /** logs the details of class. */
    private static Logger logger = LoggerFactory.getLogger(OfferDaoImpl.class);

    /** The session factory. */
    @Autowired
    private SessionFactory sessionFactory;

    /**
     * Sets the session factory.
     * 
     * @param sessionFactory
     *            the new session factory
     */
    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    /*
     * @see com.impetus.filmduniya.dao.OfferDao#getByOfferId(java.lang.String)
     */
    /**
     * Gets the by offer id.
     *
     * @param offerId the offer id
     * @return the by offer id
     */
    public Offer getByOfferId(int offerId) {
        Query query = this.sessionFactory.getCurrentSession().createQuery(
                "from Offer where offerId= :offerId ");
        query.setInteger("offerId", offerId);
        return (Offer) query.uniqueResult();
    }

    /*
     * @see com.impetus.filmduniya.dao.OfferDao#getOfferForShow(int)
     */
    /**
     * Gets the offer for show.
     *
     * @param showId the show id
     * @return the offer for show
     */
    public List<Offer> getOfferForShow(int showId) {
        try{
        long time = System.currentTimeMillis();
        Date date = new Date(time);

        List<Offer> offerList = new ArrayList<Offer>();
        // Retrieve session from Hibernate
        Session session = sessionFactory.getCurrentSession();
        Criteria criteria = session.createCriteria(Offer.class);
        criteria.createAlias("show", "show");
        criteria.add(Restrictions.eq("show.showId", showId))
                .add(Restrictions.le("startDate", date))
                .add(Restrictions.ge("endDate", date));
        offerList = criteria.list();

        Query query = session
                .createQuery("from Offer where type= 'ALL' AND startDate <= CURDATE() AND endDate >=  CURDATE()");
        offerList.addAll(query.list());
        return offerList;
        
    }
        catch(RuntimeException e)
        {
            logger.error("***********Error while getting deal by deal id***********");
            throw new DAOException("Error while getting deal by deal id",e);
        }
        
    }

    /*
     * @see com.impetus.filmduniya.dao.OfferDao#checkOffer(int, int)
     */
    /**
     * Check offer.
     *
     * @param offerCode the offer code
     * @param showId the show id
     * @return the offer
     */
    public Offer checkOffer(String offerCode, int showId) {
 
        Session session = sessionFactory.getCurrentSession();
     
        Query query = session
                .createQuery("from Offer where offerCode= :offerCode AND startDate <= CURDATE() AND endDate >=  CURDATE()");

        query.setString("offerCode", offerCode);
        Offer offer = (Offer) query.uniqueResult();
        int showCheck = 0;
        if (offer == null) {
            return offer;
        } else {
            if (offer.getType().equalsIgnoreCase("all")) {

                return offer;
            } else {
                Iterator<Shows> showIterator = offer.getShow().iterator();
                while (showIterator.hasNext()) {
                    Shows shows = showIterator.next();
                    if (showId == shows.getShowId()) {
                        showCheck = 1;
                    }

                }
                if (showCheck == 1) {
                    return offer;
                } else {
                    return null;
                }
            }
        }
    }
   

    

    /*
     * @see com.impetus.filmduniya.dao.OfferDao#addOffers(java.util.List)
     */
    /**
     * Adds the offers.
     *
     * @param offerInserList the offer inser list
     */
    public void addOffers(List<Offer> offerInserList) {

        try {
            this.sessionFactory.getCurrentSession().save(offerInserList);
        } catch (ConstraintViolationException e) {
            logger.error("Error in Add Offers List", e);
        }
    }

    /*
     * @see
     * com.impetus.filmduniya.dao.OfferDao#addOffer(com.impetus.filmduniya.dto
     * .Offer)
     */
    /**
     * Adds the offer.
     *
     * @param offer the offer
     */
    public void addOffer(Offer offer) {

        try {
            this.sessionFactory.getCurrentSession().save(offer);
        } catch (ConstraintViolationException e) {
            logger.error("Error in Add Offers", e);
        }
    }

}
