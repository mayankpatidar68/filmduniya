package com.impetus.filmduniya.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


/**
 * @author mayank.patidar
 *
 */
/**
 * The Class Ticket.
 */
@Entity
@Table(name = "TICKET")
public class Ticket {

    /** The ticket id. */
    @Id
    @Column(name = "TICKETID")
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int ticketId;

    /** The booking. */
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "bookingId")
    private Booking booking;

    /** The seat. */
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "seatId")
    private Seat seat;

    /** The status. */
    @Column(name = "STATUS")
    private String status;

    /**
     * Gets the ticket id.
     * 
     * @return the ticket id
     */
    public int getTicketId() {
        return ticketId;
    }

    /**
     * Sets the ticket id.
     * 
     * @param ticketId
     *            the new ticket id
     */
    public void setTicketId(int ticketId) {
        this.ticketId = ticketId;
    }

    /**
     * Gets the booking.
     * 
     * @return the booking
     */
    public Booking getBooking() {
        return booking;
    }

    /**
     * Sets the booking.
     * 
     * @param booking
     *            the new booking
     */
    public void setBooking(Booking booking) {
        this.booking = booking;
    }

    /**
     * Gets the seat.
     * 
     * @return the seat
     */
    public Seat getSeat() {
        return seat;
    }

    /**
     * Sets the seat.
     * 
     * @param seat
     *            the new seat
     */
    public void setSeat(Seat seat) {
        this.seat = seat;
    }

    /**
     * Gets the status.
     * 
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the status.
     * 
     * @param status
     *            the new status
     */
    public void setStatus(String status) {
        this.status = status;
    }

}
