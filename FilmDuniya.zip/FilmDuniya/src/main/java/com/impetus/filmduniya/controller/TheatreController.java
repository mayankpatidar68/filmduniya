package com.impetus.filmduniya.controller;

import java.io.IOException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.impetus.filmduniya.dto.City;
import com.impetus.filmduniya.dto.Theatre;
import com.impetus.filmduniya.exception.DAOException;
import com.impetus.filmduniya.service.TheatreService;
import com.impetus.filmduniya.vo.TheatreVO;





/**
 * The Class TheatreController.
 *
 * @author mayank.patidar
 */
@Controller
public class TheatreController {
    
    /** logs the details of class. */
    private static Logger logger = LoggerFactory
            .getLogger(MovieController.class);
    
    /** reference of class theatre service. */
    @Autowired
    private TheatreService theatreService;
    
    
    /**
     * Post user1.
     * 
     * @param detail
     *            the detail
     * @return the int
     */
    @RequestMapping(value = "/saveTheatre", method = RequestMethod.POST)
    @ResponseBody
    public int addTheatre(@RequestBody TheatreVO detail) {
        Theatre theatre = new Theatre();

        theatre.setTheatreName(detail.getTheatreName());

        theatre.setNoOfColumns(detail.getNoOfColumns());

        theatre.setNoOfRows(detail.getNoOfRows());

        theatre.setStatus(detail.getStatus());

        City city = new City();
        city.setCityId(Integer.parseInt(detail.getCityId()));
        theatre.setCity(city);
        theatreService.addTheatre(theatre);
        logger.info("In Save theatre  ");
        return 1;
    }

    /**
     * Handles the request to manage Theatre page.
     * 
     * @return the JSP page of manage Theatre
     */
    @RequestMapping(value = "/manageTheatre", method = RequestMethod.GET)
    @ResponseBody
    public List<Theatre> manageTheatre() {

        List<Theatre> theatre = theatreService.getAllTheatres();

        return theatre;

    }

    /**
     * Handles the request to delete a Theatre.
     * 
     * @param id
     *            the id
     * @return the JSP page to show after delete theatre
     */
    @RequestMapping(value = "/manageTheatre/{id}", method = RequestMethod.DELETE)
    public void destroytheatre(@PathVariable int id) {
        theatreService.delete(id);

    }

    /**
     * Handles the request to Add Theatre page.
     * 
     * 
     * @param model
     *            the model
     * @return the JSP page of TheatreAdder.
     */
    @RequestMapping(value = "/TheatreAdder", method = RequestMethod.GET)
    public String theatreAdder(ModelMap model) {
        logger.info("In Theatre Adder ");
        return "TheatreAdder";
    }

    /**
     * Handles the request to view all theatres.
     * 
     * @param cityId
     *            the city id
     * @return the list of theatres
     */
    @RequestMapping(value = "/theatre", method = RequestMethod.GET)
    @ResponseBody
    public List<Theatre> getAllTheatres(int cityId) {
        return theatreService.getAllTheatresByCityId(cityId);
    }
    
    /**
     * Handles the request to view all movies.
     * 
     * @param model
     *            the model
     * @return the list of movies
     * @throws IOException
     *             Signals that an I/O exception has occurred.
     */

    @RequestMapping(value = "/allTheatres", method = RequestMethod.GET)
    @ResponseBody
    public List<Theatre> getAllTheatres(Model model) throws IOException {

        List<Theatre> theatres = theatreService.getAllTheatres();

        return theatres;
    }
    
    /**
     * Handle exception.
     * 
     * @param e
     *            the e
     * @return the model and view
     */
    @ExceptionHandler(DAOException.class)
    public ModelAndView handleException(DAOException e) { 
        ModelAndView modelAndView7 = new ModelAndView();
        modelAndView7.setViewName("error");
        modelAndView7.addObject("error_message", "Something went wrong, Server not Available");
        return modelAndView7;
    }

    /**
     * Handle exception.
     * 
     * @param e
     *            the e
     * @return the model and view
     */
    @ExceptionHandler(Exception.class)
    public ModelAndView handleException(Exception e) {
        ModelAndView modelAndView8 = new ModelAndView();
        modelAndView8.setViewName("error");
        modelAndView8.addObject("error_message",
                "Something went wrong, Server not Available");
        return modelAndView8;
    }

}
