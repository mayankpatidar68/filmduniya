package com.impetus.filmduniya.service;

import java.util.List;

import com.impetus.filmduniya.dto.User;




/**
 * @author mayank.patidar
 */
/**
 * The Interface UserService.
 */
public interface UserService {

   
    /**
     * Adds the user.
     *
     * @param user the user
     */
    void addUser(User user);

   
   
    /**
     * Gets the by user email.
     *
     * @param currentUserEmail the current user email
     * @return the by user email
     */
    User getByUserEmail(String currentUserEmail);

    
    /**
     * Gets the user by id.
     *
     * @param userId the user id
     * @return the user by id
     */
    User getUserById(int userId);

   
    /**
     * Edits the user.
     *
     * @param user the user
     */
    void editUser(User user);

    
    /**
     * Gets the all users.
     *
     * @return the all users
     */
    List<User> getAllUsers();

   
    
    /**
     * Gets the user details.
     *
     * @param user the user
     * @return the user details
     */
    User getUserDetails(User user);

    
    /**
     * Send user mail.
     *
     * @param emailId the email id
     */
    void sendUserMail(String emailId);
}
