package com.impetus.filmduniya.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * @author mayank.patidar
 *
 */
/**
 * The Class Movie.
 */
@Entity
@Table(name = "MOVIE")
public class Movie {

    /** The movie id. */
    @Id
    @Column(name = "MOVIEID")
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int movieId;

    /** The movie name. */
    @Column(name = "MOVIENAME")
    private String movieName;

    /** The description. */
    @Column(name = "DESCRIPTION")
    private String description;

    // @Temporal(TemporalType.DATE)
    /** The release date. */
    @Column(name = "RELEASEDATE")
    private String releaseDate;

    /** The duration. */
    @Column(name = "DURATION")
    private String duration;

    /** The status. */
    @Column(name = "STATUS")
    private String status;

    /**
     * Gets the movie id.
     * 
     * @return the movie id
     */
    public int getMovieId() {
        return movieId;
    }

    /**
     * Sets the movie id.
     * 
     * @param movieId
     *            the new movie id
     */
    public void setMovieId(int movieId) {
        this.movieId = movieId;
    }

    /**
     * Gets the movie name.
     * 
     * @return the movie name
     */
    public String getMovieName() {
        return movieName;
    }

    /**
     * Sets the movie name.
     * 
     * @param movieName
     *            the new movie name
     */
    public void setMovieName(String movieName) {
        this.movieName = movieName;
    }

    /**
     * Gets the description.
     * 
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the description.
     * 
     * @param description
     *            the new description
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * Gets the release date.
     * 
     * @return the release date
     */
    public String getReleaseDate() {
        return releaseDate;
    }

    /**
     * Sets the release date.
     * 
     * @param releaseDate
     *            the new release date
     */
    public void setReleaseDate(String releaseDate) {
        this.releaseDate = releaseDate;
    }

    /**
     * Gets the duration.
     * 
     * @return the duration
     */
    public String getDuration() {
        return duration;
    }

    /**
     * Sets the duration.
     * 
     * @param duration
     *            the new duration
     */
    public void setDuration(String duration) {
        this.duration = duration;
    }

    /**
     * Gets the status.
     * 
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the status.
     * 
     * @param status
     *            the new status
     */
    public void setStatus(String status) {
        this.status = status;
    }

}
