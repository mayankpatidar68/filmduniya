package com.impetus.filmduniya.service;

import com.impetus.filmduniya.dto.Ticket;



/**
  * @author mayank.patidar
 */
/**
 * The Interface TicketService.
 */
public interface TicketService {

    
    /**
     * Save.
     *
     * @param ticket the ticket
     */
    void save(Ticket ticket);

}
