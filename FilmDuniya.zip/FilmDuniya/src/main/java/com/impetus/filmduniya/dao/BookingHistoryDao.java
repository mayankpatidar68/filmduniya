package com.impetus.filmduniya.dao;

import java.util.List;

import com.impetus.filmduniya.dto.Booking;
import com.impetus.filmduniya.dto.Ticket;
import com.impetus.filmduniya.dto.User;

/**
 * Data Access interface for BookingHistory table in database
 * 
 * @author mayank.patidar
 * 
 */
public interface BookingHistoryDao {

    /**
     * Gets the all BookingHistory.
     * 
     * @return the all History
     */
    List<Booking> getBookingHistory(User user);

    /**
     * Gets the Ticket Details.
     * 
     * @return the all Details
     */
    List<Ticket> getTicketDetails(int bookingId);
}
