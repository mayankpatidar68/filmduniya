package com.impetus.filmduniya.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


/**
 * @author mayank.patidar
 *
 */
/**
 * The Class Theatre.
 */
@Entity
@Table(name = "THEATRE")
public class Theatre {

    /** The theatre id. */
    @Id
    @Column(name = "THEATREID")
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int theatreId;

    /** The city. */
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "cityId")
    private City city;

    /** The theatre name. */
    @Column(name = "THEATRENAME")
    private String theatreName;

    /** The no of rows. */
    @Column(name = "NO_OF_ROWS")
    private Integer noOfRows;

    /** The no of columns. */
    @Column(name = "NO_OF_COLUMNS")
    private Integer noOfColumns;

    /** The status. */
    @Column(name = "STATUS")
    private String status;

    /**
     * Gets the theatre id.
     * 
     * @return the theatre id
     */
    public int getTheatreId() {
        return theatreId;
    }

    /**
     * Sets the theatre id.
     * 
     * @param theatreId
     *            the new theatre id
     */
    public void setTheatreId(int theatreId) {
        this.theatreId = theatreId;
    }

    /**
     * Gets the city.
     * 
     * @return the city
     */
    public City getCity() {
        return city;
    }

    /**
     * Sets the city.
     * 
     * @param city
     *            the new city
     */
    public void setCity(City city) {
        this.city = city;
    }

    /**
     * Gets the theatre name.
     * 
     * @return the theatre name
     */
    public String getTheatreName() {
        return theatreName;
    }

    /**
     * Sets the theatre name.
     * 
     * @param theatreName
     *            the new theatre name
     */
    public void setTheatreName(String theatreName) {
        this.theatreName = theatreName;
    }

    /**
     * Gets the no of rows.
     * 
     * @return the no of rows
     */
    public Integer getNoOfRows() {
        return noOfRows;
    }

    /**
     * Sets the no of rows.
     * 
     * @param noOfRows
     *            the new no of rows
     */
    public void setNoOfRows(Integer noOfRows) {
        this.noOfRows = noOfRows;
    }

    /**
     * Gets the no of columns.
     * 
     * @return the no of columns
     */
    public Integer getNoOfColumns() {
        return noOfColumns;
    }

    /**
     * Sets the no of columns.
     * 
     * @param noOfColumns
     *            the new no of columns
     */
    public void setNoOfColumns(Integer noOfColumns) {
        this.noOfColumns = noOfColumns;
    }

    /**
     * Gets the status.
     * 
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the status.
     * 
     * @param status
     *            the new status
     */
    public void setStatus(String status) {
        this.status = status;
    }

}
