package com.impetus.filmduniya.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.exception.ConstraintViolationException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.impetus.filmduniya.dto.Movie;
import com.impetus.filmduniya.exception.DAOException;


/**
 * Implementation of interface MovieDao.
 * 
 * @author mayank.patidar
 */
@Repository
public class MovieDaoImpl implements MovieDao {

    /** logs the details of class. */
    private static Logger logger = LoggerFactory.getLogger(MovieDaoImpl.class);

    /** The session factory. */
    @Autowired
    private SessionFactory sessionFactory;

    /**
     * Sets the session factory.
     * 
     * @param sessionFactory
     *            the new session factory
     */
    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    /*
     * @see com.impetus.filmduniya.dao.MovieDao#addMovie(com.impetus.filmduniya
     * .dto.Movie)
     */
    /**
     * Adds the movie.
     *
     * @param movie the movie
     */
    public void addMovie(Movie movie) {

        try {
            this.sessionFactory.getCurrentSession().save(movie);
        } catch (ConstraintViolationException e) {

            logger.error("Error in AddMovie", e);
        }

    }

    /*
     * @see com.impetus.filmduniya.dao.MovieDao#getAllMovieByTheatreId(int)
     */
    /**
     * Gets the all movie by theatre id.
     *
     * @param theatreId the theatre id
     * @return the all movie by theatre id
     */
    public List<Movie> getAllMovieByTheatreId(int theatreId) {
try{
        Query query = this.sessionFactory
                .getCurrentSession()
                .createQuery(
                        "FROM Movie where movieId in ( SELECT distinct shows.movie.movieId FROM Shows shows where shows.theatre.theatreId= :theatreId)");
        query.setInteger("theatreId", theatreId);
        return query.list();

    }
    catch(RuntimeException e){
        logger.error("**********Error while getting the movies by theatreId");
        throw new DAOException("Error while getting the movies by theatreId",e);
    }
}


    /*
     * @see com.impetus.filmduniya.dao.MovieDao#getAllMovies()
     */
    /**
     * Gets the all movies.
     *
     * @return the all movies
     */
    public List<Movie> getAllMovies() {
try{
        Query query = this.sessionFactory.getCurrentSession().createQuery(
                "FROM Movie");

        return query.list();

    }
    catch(RuntimeException e){
        logger.error("**********Error while getting the movies ");
        throw new DAOException("Error while getting the movies ",e);
    }
}

    /*
     * @see com.impetus.filmduniya.dao.MovieDao#delete(int)
     */
    /**
     * Delete.
     *
     * @param movieId the movie id
     */
    public void delete(int movieId) {
        // Retrieve session from Hibernate
try{
        Session session = sessionFactory.getCurrentSession();
        Query query = session.createQuery("from Movie where movieId= :movieId");
        query.setInteger("movieId", movieId);
        Movie movie = (Movie) query.uniqueResult();
        movie.setStatus("DELETED");
        session.delete(movie);
        session.getTransaction().commit();
        logger.debug("Movie deleted by Admin (Status changed)");
    }
    catch(RuntimeException e){
        logger.error("**********Error while deleting the movie");
        throw new DAOException("Error while deleting the movie",e);
    }
}



    /*
     * @see com.impetus.filmduniya.dao.MovieDao#getMovieById(int)
     */
    /**
     * Gets the movie by id.
     *
     * @param mid the mid
     * @return the movie by id
     */
    public Movie getMovieById(int mid) {
        return (Movie) sessionFactory.getCurrentSession().get(Movie.class, mid);
    }

    /*
     * @see
     * com.impetus.filmduniya.dao.MovieDao#editMovie(com.impetus.filmduniya.
     * dto.Movie)
     */
    /**
     * Edits the movie.
     *
     * @param movie the movie
     */
    public void editMovie(Movie movie) {
try{
        // Retrieve session from Hibernate

        Session session = sessionFactory.getCurrentSession();
        // Retrieve existing person via id
        Movie existingMovie = (Movie) session.get(Movie.class,
                movie.getMovieId());

        existingMovie.setMovieId(movie.getMovieId());
        // Assign updated values to this person
        existingMovie.setMovieName(movie.getMovieName());
        existingMovie.setDescription(movie.getDescription());
        existingMovie.setDuration(movie.getDuration());
        existingMovie.setReleaseDate(movie.getReleaseDate());
        existingMovie.setStatus(movie.getStatus());

        // Save updates
        session.save(existingMovie);
    }
    catch(RuntimeException e){
        logger.error("**********Error while edit the movie");
        throw new DAOException("Error while edit the movie",e);
    }
}

    /*
     * @see com.impetus.filmduniya.dao.MovieDao#getById(int)
     */
    /**
     * Gets the by id.
     *
     * @param movieId the movie id
     * @return the by id
     */
    public Movie getById(int movieId) {

        return (Movie) sessionFactory.getCurrentSession().get(Movie.class,
                movieId);
    }

    /*
     * @see com.impetus.filmduniya.dao.MovieDao#getByName(java.lang.String)
     */
    /**
     * Gets the by name.
     *
     * @param movieName the movie name
     * @return the by name
     */
    public Movie getByName(String movieName) {
        // Retrieve session from Hibernate
        Session session = sessionFactory.getCurrentSession();
        // Retrieve existing person first
        Query query = session
                .createQuery("from Movie where movieName= :movieName ");
        query.setString("movieName", movieName);
        return (Movie) query.uniqueResult();
    }

}
