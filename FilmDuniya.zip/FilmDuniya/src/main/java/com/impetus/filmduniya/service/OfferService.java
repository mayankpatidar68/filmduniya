package com.impetus.filmduniya.service;

import java.util.List;

import com.impetus.filmduniya.dto.Offer;




/**
 * @author mayank.patidar
 */
/**
 * The Interface OfferService.
 */
public interface OfferService {

   
    /**
     * Gets the by offer id.
     *
     * @param offerId the offer id
     * @return the by offer id
     */
    Offer getByOfferId(int offerId);

   
    /**
     * Gets the offer for show.
     *
     * @param showId the show id
     * @return the offer for show
     */
    List<Offer> getOfferForShow(int showId);

    
    /**
     * Check offer.
     *
     * @param dealCode the deal code
     * @param showId the show id
     * @return the offer
     */
    Offer checkOffer(String dealCode, int showId);

    
    /**
     * Adds the offer.
     *
     * @param offer the offer
     */
    void addOffer(Offer offer);
}
