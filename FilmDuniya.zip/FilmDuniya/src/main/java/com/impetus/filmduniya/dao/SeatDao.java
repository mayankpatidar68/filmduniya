package com.impetus.filmduniya.dao;

import java.util.List;

import com.impetus.filmduniya.dto.Seat;
import com.impetus.filmduniya.dto.Shows;

/**
 * The Interface SeatDao.
 * 
 * @author mayank.patidar
 */

public interface SeatDao {

    /**
     * Gets the seat.
     * 
     * @param show
     *            the show
     * @param seatNo
     *            the seat no
     * @return the seat
     */
    Seat getSeat(Shows show, int seatNo);

    /**
     * Update status.
     * 
     * @param seat
     *            the seat
     */
    void updateStatus(Seat seat);

    /**
     * Gets the reserved seats.
     * 
     * @param show
     *            the show
     * @return the reserved seats
     */
    List<Seat> getReservedSeats(Shows show);

    /**
     * Gets the seat by id.
     * 
     * @param seatId
     *            the seat id
     * @return the seat by id
     */
    Seat getSeatById(int seatId);
}
