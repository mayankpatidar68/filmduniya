package com.impetus.filmduniya.service;

import java.util.List;

import com.impetus.filmduniya.dto.Theatre;




/**
  * @author mayank.patidar
 */
/**
 * The Interface TheatreService.
 */
public interface TheatreService {

   
    
    /**
     * Gets the all theatres by city id.
     *
     * @param cityId the city id
     * @return the all theatres by city id
     */
    List<Theatre> getAllTheatresByCityId(int cityId);

   
    /**
     * Adds the theatre.
     *
     * @param theatre the theatre
     */
    void addTheatre(Theatre theatre);

   
    
    /**
     * Gets the all theatres.
     *
     * @return the all theatres
     */
    List<Theatre> getAllTheatres();

    
    
    /**
     * Delete.
     *
     * @param theatreId the theatre id
     */
    void delete(int theatreId);

}
