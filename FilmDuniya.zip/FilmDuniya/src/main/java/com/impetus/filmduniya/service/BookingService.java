package com.impetus.filmduniya.service;

import java.util.List;

import com.impetus.filmduniya.dto.Booking;



/**
 * The Interface BookingService.
 *
 * @author mayank.patidar
 */

public interface BookingService {

   
    
    /**
     * Reserve seat and book.
     *
     * @param seatNoValue the seat no value
     * @param currentUserEmail the current user email
     * @return the booking
     */
    Booking reserveSeatAndBook(Integer seatNoValue[], String currentUserEmail);

    
    
    /**
     * Send booking mail.
     *
     * @param i the i
     * @param string the string
     */
    int sendBookingMail(int i, String string);

   
    
    
    /**
     * Gets the PDF detail.
     *
     * @param movieIdString the movie id string
     * @param showDateString the show date string
     * @return the PDF detail
     */
    List<Booking> getPDFDetail(String movieIdString, String showDateString);
    
    /**
     * Scheduled email.
     */
    void scheduledEmail();
}
