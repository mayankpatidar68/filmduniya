package com.impetus.filmduniya.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.impetus.filmduniya.dto.Seat;
import com.impetus.filmduniya.dto.Shows;



/**
 * @author mayank.patidar
 *
 */
/**
 * The Class SeatDaoImpl.
 */
@Repository
public class SeatDaoImpl implements SeatDao {

    /** The session factory. */
    @Autowired
    private SessionFactory sessionFactory;

    /**
     * Sets the session factory.
     * 
     * @param sessionFactory
     *            the new session factory
     */
    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    /*
     * @see com.impetus.filmduniya.dao.ShowsDAO#getByshowId(java.lang.String)
     */
    /**
     * Gets the seat.
     *
     * @param show the show
     * @param seatNo the seat no
     * @return the seat
     */
    public Seat getSeat(Shows show, int seatNo) {

        Query query = this.sessionFactory.getCurrentSession().createQuery(
                "FROM Seat where seatNo= :seatNo and shows= :shows");
        query.setInteger("seatNo", seatNo);
        query.setEntity("shows", show);
        return (Seat) query.uniqueResult();

    }

    /*
     * @see com.impetus.filmduniya.dao.SeatDAO#updateSeat(com.impetus.filmduniya
     * .Seat)
     */
    /**
     * Update status.
     *
     * @param seat the seat
     */
    public void updateStatus(Seat seat) {
        this.sessionFactory.getCurrentSession().update(seat);
    }

    /*
     * @see
     * com.impetus.filmduniya.dao.SeatDao#getReservedSeats(com.impetus.filmduniya
     * .dto.Shows)
     */
    /**
     * Gets the reserved seats.
     *
     * @param show the show
     * @return the reserved seats
     */
    public List<Seat> getReservedSeats(Shows show) {
        Query query = this.sessionFactory.getCurrentSession().createQuery(
                "FROM Seat where shows= :shows and status= :status");
        query.setEntity("shows", show);
        query.setString("status", "Booked");
        return query.list();
    }

    /*
     * @see com.impetus.filmduniya.dao.SeatDao#getSeatById(int)
     */
    /**
     * Gets the seat by id.
     *
     * @param seatId the seat id
     * @return the seat by id
     */
    public Seat getSeatById(int seatId) {
        Session session = sessionFactory.getCurrentSession();

        return (Seat) session.get(Seat.class, seatId);

    }

}
