package com.impetus.filmduniya.vo;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;




/**
 * @author mayank.patidar
 *
 */
/**
 * The Class FileUploadValidator.
 */
@Component
@Scope("prototype")
public class FileUploadValidator implements Validator {

    /*
     * @see org.springframework.validation.Validator#supports(java.lang.Class)
     */
    /**
     * Supports.
     *
     * @param clazz the clazz
     * @return true, if successful
     */
    public boolean supports(Class clazz) {
        // just validate the FileUpload instances
        return FileUploadForm.class.isAssignableFrom(clazz);

    }

    /*
     * @see org.springframework.validation.Validator#validate(java.lang.Object,
     * org.springframework.validation.Errors)
     */
    /**
     * Validate.
     *
     * @param target the target
     * @param errors the errors
     */
    public void validate(Object target, Errors errors) {

    }

    /**
     * Validate offers.
     * 
     * @param uploadOffer
     *            the upload offer
     * @param errors
     *            the errors
     */
    public void validateOffers(Object uploadOffer, Errors errors) {

    }

}
