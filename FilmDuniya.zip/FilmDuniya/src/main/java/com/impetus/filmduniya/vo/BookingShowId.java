package com.impetus.filmduniya.vo;



/**
 * The Class BookingShowId.
 *
 * @author mayank.patidar
 */
/**
 * The Class BookingShowId.
 */
public class BookingShowId {

    /** The shows id. */
    private int showsId;
    
    /** The no of seats. */
    private int noOfSeats;

    /**
     * Gets the no of seats.
     *
     * @return the no of seats
     */
    public int getNoOfSeats() {
        return noOfSeats;
    }

    /**
     * Sets the no of seats.
     *
     * @param noOfSeats the new no of seats
     */
    public void setNoOfSeats(int noOfSeats) {
        this.noOfSeats = noOfSeats;
    }

    /**
     * Gets the shows id.
     * 
     * @return the shows id
     */
    public int getShowsId() {
        return showsId;
    }

    /**
     * Sets the shows id.
     * 
     * @param showsId
     *            the new shows id
     */
    public void setShowsId(int showsId) {
        this.showsId = showsId;
    }

    /*
     * @see java.lang.Object#toString()
     */
    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "BookingShowId [showsId=" + showsId + "]";
    }

}
