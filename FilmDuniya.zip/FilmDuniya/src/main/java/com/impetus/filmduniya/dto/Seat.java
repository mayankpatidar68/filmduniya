package com.impetus.filmduniya.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


/**
 * @author mayank.patidar
 *
 */
/**
 * The Class Seat.
 */
@Entity
@Table(name = "SEAT")
public class Seat {

    /** The seat id. */
    @Id
    @Column(name = "SEATID")
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int seatId;

    /** The seat no. */
    @Column(name = "SEATNO")
    private String seatNo;

    /** The shows. */
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "showId")
    private Shows shows;

    /** The status. */
    @Column(name = "STATUS")
    private String status;

    /**
     * Gets the seat id.
     * 
     * @return the seat id
     */
    public int getSeatId() {
        return seatId;
    }

    /**
     * Sets the seat id.
     * 
     * @param seatId
     *            the new seat id
     */
    public void setSeatId(int seatId) {
        this.seatId = seatId;
    }

    /**
     * Gets the seat no.
     * 
     * @return the seat no
     */
    public String getSeatNo() {
        return seatNo;
    }

    /**
     * Sets the seat no.
     * 
     * @param seatNo
     *            the new seat no
     */
    public void setSeatNo(String seatNo) {
        this.seatNo = seatNo;
    }

    /**
     * Gets the shows.
     * 
     * @return the shows
     */
    public Shows getShows() {
        return shows;
    }

    /**
     * Sets the shows.
     * 
     * @param shows
     *            the new shows
     */
    public void setShows(Shows shows) {
        this.shows = shows;
    }

    /**
     * Gets the status.
     * 
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the status.
     * 
     * @param status
     *            the new status
     */
    public void setStatus(String status) {
        this.status = status;
    }

}
