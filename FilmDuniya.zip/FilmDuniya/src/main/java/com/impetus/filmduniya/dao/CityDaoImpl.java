package com.impetus.filmduniya.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.exception.ConstraintViolationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.impetus.filmduniya.dto.City;
import com.impetus.filmduniya.exception.DAOException;


/**
 * Implementation of interface CityDao.
 * 
 * @author mayank.patidar
 */
@Repository
public class CityDaoImpl implements CityDao {

    /** logs the details of class. */
    private static Logger logger = LoggerFactory.getLogger(CityDaoImpl.class);

    /** The session factory. */
    @Autowired
    private SessionFactory sessionFactory;

    /**
     * Sets the session factory.
     * 
     * @param sessionFactory
     *            the new session factory
     */
    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    /*
     * @see com.impetus.filmduniya.dao.CityDao#getAllCities()
     */
    /**
     * Gets the all cities.
     *
     * @return the all cities
     */
    public List<City> getAllCities() {
        Query query = this.sessionFactory.getCurrentSession().createQuery(
                "FROM City");
        logger.info("get all Cities");
        return query.list();
    }

    /*
     * @see
     * com.impetus.filmduniya.dao.CityDao#addCity(com.impetus.filmduniya.dto
     * .City)
     */
    /**
     * Adds the city.
     *
     * @param city the city
     */
    public void addCity(City city) {

        try {
            this.sessionFactory.getCurrentSession().save(city);
        } catch (ConstraintViolationException e) {

            logger.error("Error in Add city", e);
        }

    }

    /*
     * @see com.impetus.filmduniya.dao.CityDao#delete(int)
     */
    /**
     * Delete.
     *
     * @param cityId the city id
     */
    public void delete(int cityId) {
try{
        Session session = sessionFactory.getCurrentSession();
        Query query = session.createQuery("from City where cityId= :cityId");
        query.setInteger("cityId", cityId);

        City city = (City) query.uniqueResult();
        session.delete(city);
        session.getTransaction().commit();

    }
    catch(RuntimeException e){
        logger.error("**********Error while deleting the city");
        throw new DAOException("Error while deleting the city",e);
    }
}

    /*
     * @see
     * com.impetus.filmduniya.dao.CityDao#editCity(com.impetus.filmduniya.dto
     * .City)
     */
    /**
     * Edits the city.
     *
     * @param city the city
     */
    public void editCity(City city) {
try{
        Session session = sessionFactory.getCurrentSession();

        // Retrieve existing person via id
        City existingCity = (City) session.get(City.class, city.getCityId());

        existingCity.setCityName(city.getCityName());

        // Save updates
        session.save(existingCity);
    }
    catch(RuntimeException e){
        logger.error("**********Error while edit the city");
        throw new DAOException("Error while edit the city",e);
    }
}
}
