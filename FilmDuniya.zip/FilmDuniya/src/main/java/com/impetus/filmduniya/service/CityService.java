package com.impetus.filmduniya.service;

import java.util.List;

import com.impetus.filmduniya.dto.City;




/**
 * @author mayank.patidar
 */
/**
 * The Interface CityService.
 */
public interface CityService {

   
    /**
     * Gets the all cities.
     *
     * @return the all cities
     */
    List<City> getAllCities();

    
    
    /**
     * Adds the city.
     *
     * @param city the city
     */
    void addCity(City city);

    
    /**
     * Delete.
     *
     * @param cityId the city id
     */
    void delete(int cityId);

    
   
    /**
     * Edits the city.
     *
     * @param city the city
     */
    void editCity(City city);
}