package com.impetus.filmduniya.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.impetus.filmduniya.dao.TicketDao;
import com.impetus.filmduniya.dto.Ticket;



/**
 * @author mayank.patidar
 *
 */
/**
 * The Class TicketServiceImpl.
 */
@Service
@Transactional
public class TicketServiceImpl implements TicketService {

    /** The ticket dao. */
    @Autowired
    private TicketDao ticketDao;

    /*
     * @see
     * com.impetus.filmduniya.service.TicketService#save(com.impetus.filmduniya
     * .dto.Ticket)
     */
    /**
     * Save.
     *
     * @param ticket the ticket
     */
    public void save(Ticket ticket) {
        ticketDao.save(ticket);

    }

}
