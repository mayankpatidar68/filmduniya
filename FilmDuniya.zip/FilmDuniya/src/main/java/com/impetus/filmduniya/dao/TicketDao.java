package com.impetus.filmduniya.dao;

import com.impetus.filmduniya.dto.Ticket;




/**
 * The Interface TicketDao.
 *
 * @author mayank.patidar
 */

public interface TicketDao {

    /**
     * Save.
     *
     * @param ticket the ticket
     */
    void save(Ticket ticket);

   
    /**
     * Gets the.
     *
     * @param cancelTicketId the cancel ticket id
     * @return the ticket
     */
    Ticket get(int cancelTicketId);

    /**
     * Update.
     *
     * @param ticket the ticket
     */
    void update(Ticket ticket);
}
