package com.impetus.filmduniya.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


/**
 * @author mayank.patidar
 *
 */
/**
 * The Class Booking.
 */
@Entity
@Table(name = "BOOKING")
public class Booking {

    /** The booking id. */
    @Id
    @Column(name = "BOOKINGID")
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int bookingId;

    /** The user. */
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "userId")
    private User user;

    /** The shows. */
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "showId")
    private Shows shows;

    /** The no of tickets. */
    @Column(name = "NO_OF_TICKETS")
    private Integer noOfTickets;

    /** The actual fare. */
    @Column(name = "ACTUALFARE")
    private Integer actualFare;

    /** The total fare. */
    @Column(name = "TOTALFARE")
    private Integer totalFare;

    /** The offer. */
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "offerId")
    private Offer offer;

    /**
     * Gets the offer.
     * 
     * @return the offer
     */
    public Offer getOffer() {
        return offer;
    }

    /**
     * Sets the offer.
     * 
     * @param offer
     *            the new offer
     */
    public void setOffer(Offer offer) {
        this.offer = offer;
    }

    /**
     * Gets the booking id.
     * 
     * @return the booking id
     */
    public int getBookingId() {
        return bookingId;
    }

    /**
     * Sets the booking id.
     * 
     * @param bookingId
     *            the new booking id
     */
    public void setBookingId(int bookingId) {
        this.bookingId = bookingId;
    }

    /**
     * Gets the user.
     * 
     * @return the user
     */
    public User getUser() {
        return user;
    }

    /**
     * Sets the user.
     * 
     * @param user
     *            the new user
     */
    public void setUser(User user) {
        this.user = user;
    }

    /**
     * Gets the show.
     * 
     * @return the show
     */
    public Shows getShow() {
        return shows;
    }

    /**
     * Sets the show.
     * 
     * @param shows
     *            the new show
     */
    public void setShow(Shows shows) {
        this.shows = shows;
    }

    /**
     * Gets the no of tickets.
     * 
     * @return the no of tickets
     */
    public Integer getNoOfTickets() {
        return noOfTickets;
    }

    /**
     * Sets the no of tickets.
     * 
     * @param noOfTickets
     *            the new no of tickets
     */
    public void setNoOfTickets(Integer noOfTickets) {
        this.noOfTickets = noOfTickets;
    }

    /**
     * Gets the actual fare.
     * 
     * @return the actual fare
     */
    public Integer getActualFare() {
        return actualFare;
    }

    /**
     * Sets the actual fare.
     * 
     * @param actualFare
     *            the new actual fare
     */
    public void setActualFare(Integer actualFare) {
        this.actualFare = actualFare;
    }

    /**
     * Gets the total fare.
     * 
     * @return the total fare
     */
    public Integer getTotalFare() {
        return totalFare;
    }

    /**
     * Sets the total fare.
     * 
     * @param totalFare
     *            the new total fare
     */
    public void setTotalFare(Integer totalFare) {
        this.totalFare = totalFare;
    }

}
