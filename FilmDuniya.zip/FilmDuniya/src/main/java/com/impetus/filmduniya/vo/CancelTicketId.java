package com.impetus.filmduniya.vo;


/**
 * @author mayank.patidar
 *
 */
/**
 * The Class CancelTicketId.
 */
public class CancelTicketId {

    /** The cancel ticket id. */
    private int cancelTicketId;

    /**
     * Gets the cancel ticket id.
     * 
     * @return the cancel ticket id
     */
    public int getCancelTicketId() {
        return cancelTicketId;
    }

    /**
     * Sets the cancel ticket id.
     * 
     * @param cancelTicketId
     *            the new cancel ticket id
     */
    public void setCancelTicketId(int cancelTicketId) {
        this.cancelTicketId = cancelTicketId;
    }

    /*
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "CancelTicketId [cancelTicketId=" + cancelTicketId + "]";
    }

}
