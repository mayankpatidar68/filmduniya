package com.impetus.filmduniya.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.impetus.filmduniya.dao.CityDao;
import com.impetus.filmduniya.dto.City;



/**
 * @author mayank.patidar
 *
 */
/**
 * The Class CityServiceImpl.
 */
@Service
@Transactional
public class CityServiceImpl implements CityService {

    /** The city dao. */
    @Autowired
    private CityDao cityDao;

    /*
     * @see com.impetus.filmduniya.service.CityService#getAllCities()
     */
    /**
     * Gets the all cities.
     *
     * @return the all cities
     */
    public List<City> getAllCities() {
        return cityDao.getAllCities();
    }

    /*
     * @see
     * com.impetus.filmduniya.service.CityService#addCity(com.impetus.filmduniya
     * .dto.City)
     */
    /**
     * Adds the city.
     *
     * @param city the city
     */
    public void addCity(City city) {

        cityDao.addCity(city);
    }

    /*
     * @see com.impetus.filmduniya.service.CityService#delete(int)
     */
    /**
     * Delete.
     *
     * @param cityId the city id
     */
    public void delete(int cityId) {

        cityDao.delete(cityId);

    }

    /*
     * @see
     * com.impetus.filmduniya.service.CityService#editCity(com.impetus.filmduniya
     * .dto.City)
     */
    /**
     * Edits the city.
     *
     * @param city the city
     */
    public void editCity(City city) {
        cityDao.editCity(city);
    }

}
