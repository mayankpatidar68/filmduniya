package com.impetus.filmduniya.dao;

import java.util.Date;

import java.util.List;

import com.impetus.filmduniya.dto.Shows;

/**
 * The Interface ShowDao.
 * 
 * @author mayank.patidar
 */
public interface ShowDao {

    /**
     * Gets the all shows by criteria.
     * 
     * @param cityId
     *            the city id
     * @param theatreId
     *            the theatre id
     * @param movieId
     *            the movie id
     * @param noOfSeats
     *            the no of seats
     * @param showSearchDate
     *            the show search date
     * @return the all shows by criteria
     */
    List<Shows> getAllShowsByCriteria(int cityId, int theatreId, int movieId,
            int noOfSeats, Date showSearchDate);

    /**
     * Gets the by show id.
     * 
     * @param showId
     *            the show id
     * @return the by show id
     */
    Shows getByShowId(int showId);

    /**
     * Update available seats.
     * 
     * @param show
     *            the show
     * @return the int
     */
    int updateAvailableSeats(Shows show);

    /**
     * Adds the show.
     * 
     * @param show
     *            the show
     */
    void addShow(Shows show);

    /**
     * Gets the all showss.
     * 
     * @return the all showss
     */
    List<Shows> getAllShowss();

    /**
     * Update show.
     * 
     * @param shows
     *            the shows
     */
    void updateShow(Shows shows);

    /**
     * Delete show.
     * 
     * @param show
     *            the show
     */
    void deleteShow(Shows show);

    /**
     * Adds the update delete show.
     * 
     * @param endTime
     *            the end time
     * @param fare
     *            the fare
     * @param showDate
     *            the show date
     * @param startTime
     *            the start time
     * @param movieId
     *            the movie id
     * @param theatreId
     *            the theatre id
     * @param action
     *            the action
     * @param availableSeats
     *            the available seats
     * @param duration
     *            the duration
     * @param status
     *            the status
     */
    void addUpdateDeleteShow(String[] time2Array, int fare, String showDate,
             int movieId, int theatreId, 
            int availableSeats,  String status);

    /**
     * Gets the from show.
     * 
     * @param theatreId
     *            the theatre id
     * @param movieId
     *            the movie id
     * @param date
     *            the date
     * @return the from show
     */
    List<Shows> getfromShow(int theatreId, int movieId, String date);

}
