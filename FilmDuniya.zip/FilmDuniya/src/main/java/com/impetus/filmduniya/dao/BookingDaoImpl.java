package com.impetus.filmduniya.dao;

import java.text.ParseException;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.impetus.filmduniya.dto.Booking;
import com.impetus.filmduniya.exception.DAOException;



/**
 * Implementation of interface BookingDao.
 * 
 * @author mayank.patidar
 */
@Repository
public class BookingDaoImpl implements BookingDao {

    /** logs the details of class. */
    private static Logger logger = LoggerFactory
            .getLogger(BookingDaoImpl.class);
    
    /** The Constant PRESEND_TIME. */
    private static final int PRESEND_TIME = 3;

    /** The session factory. */
    @Autowired
    private SessionFactory sessionFactory;

    /**
     * Sets the session factory.
     * 
     * @param sessionFactory
     *            the new session factory
     */
    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    /*
     * @see
     * com.impetus.filmduniya.dao.BookingDao#addBooking(com.impetus.filmduniya
     * .dto.Booking)
     */
    /**
     * Save booking.
     *
     * @param booking the booking
     * @return the booking
     */
  
    public Booking saveBooking(Booking booking) {
     // Retrieve session from Hibernate
        Session session = sessionFactory.getCurrentSession();
        
        session.save(booking);
       
        logger.info("Saving Booking details Saved");
        Booking bookingPersist = (Booking) session.get(Booking.class,
                booking.getBookingId());
        logger.debug("Dao Booking details Saved");
        return bookingPersist;

    }



    /*
     * @see com.impetus.filmduniya.dao.BookingDao#get(int)
     */
    /**
     * Gets the.
     *
     * @param bookingId the booking id
     * @return the booking
     */
    public Booking get(int bookingId) {
        Session session = sessionFactory.getCurrentSession();
        return (Booking) session.get(Booking.class, bookingId);
    }

    /*
     * @see com.impetus.filmduniya.dao.BookingDao#sendShowMail()
     */
    /**
     * Send show mail.
     *
     * @return the list
     */
    /* (non-Javadoc)
     * @see com.impetus.cw.dao.BookingDao#sendScheduleMail()
     */
    public List<Booking> sendScheduleMail()  {
        Session session = this.sessionFactory.openSession();
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.HOUR, PRESEND_TIME);
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
        String str = sdf.format(calendar.getTime());
        try {
            Date date = sdf.parse(str);
            
            logger.info("date time : "+date+"Time : "+str);
            Query query=session.createQuery("from Booking where shows.startTime =:startTime and shows.showDate = CURDATE()");
            query.setParameter("startTime", date);
            return query.list();
        } catch (ParseException e) {
            logger.error("Error in parsing date" + e);
        }
        return null;
    }

    


    /**
     * Gets the booking by movie date.
     *
     * @param movieId the movie id
     * @param showDate the show date
     * @return the booking by movie date
     */
    public List<Booking> getBookingByMovieDate(int movieId, Date showDate) {
        try{

        Session session = this.sessionFactory.openSession();
        
        Query query=session.createQuery("from Booking booking where booking.shows.movie.movieId= :movieId AND booking.shows.showDate= :showDate");
        query.setInteger("movieId",movieId); 
        query.setDate("showDate",showDate);
        logger.info("getting details for PDF");
        logger.debug("getting details for PDF");
        return query.list();
    }

        catch(HibernateException e)
        {
            logger.error("*****************Error while getting data for PDF Generation****************");
            throw new DAOException("Error while getting data for PDF Generation",e);
        }

    }

}
