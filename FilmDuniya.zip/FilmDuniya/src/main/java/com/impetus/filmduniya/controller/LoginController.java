package com.impetus.filmduniya.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.impetus.filmduniya.vo.BookingShowId;
import com.impetus.filmduniya.vo.CancelTicketId;

/**
 * Handles all the activities of Login.
 * 
 * @author mayank.patidar
 * 
 */
@Controller
public class LoginController {

    /** logs the details of class. */
    private static Logger logger = LoggerFactory
            .getLogger(LoginController.class);

    /**
     * Sign up.
     * 
     * @param model
     *            the model
     * @return the string
     */
    @RequestMapping(value = "/loginPage", method = RequestMethod.GET)
    public String signUp(ModelMap model) {

        return "UserRegistration";
    }

    /**
     * Handles the request to Welcome Page.
     * 
     * @param model
     *            the model
     * @return the JSP page of Login Page
     */
    @RequestMapping(value = "/Welcome", method = RequestMethod.GET)
    public String login(ModelMap model) {

        return "LoginPage";

    }

    /**
     * Handles the request to Fail Login page.
     * 
     * @param model
     *            the model
     * @return the JSP page of Login Failed
     */
    @RequestMapping(value = "/faillogin", method = RequestMethod.GET)
    public String faillogin(ModelMap model) {

        return "LoginFailed";

    }

    /**
     * Handles the request to logoff page.
     * 
     * @param model
     *            the model
     * @return the JSP page of Search Movie
     */
    @RequestMapping(value = "/logoff", method = RequestMethod.GET)
    public String logoff(ModelMap model) {
        model.addAttribute("showIdAttribute", new BookingShowId());

        return "SearchMovie";

    }

    /**
     * Handles the request to Booking History page.
     * 
     * @param model
     *            the model
     * @return the JSP page of BookingHistory
     */
    @RequestMapping(value = "/userBookingHistory", method = RequestMethod.GET)
    public String bookingHistory(Model model) {
        logger.info("Booking History is clicked");
        model.addAttribute("cancelTicketFormAttribute", new CancelTicketId());
        return "BookingHistory";
    }

    /**
     * Handles the request to Login page.
     * 
     * @param model
     *            the model
     * @return the JSP page of LoginPage
     */
    @RequestMapping(value = "/LoginPage", method = RequestMethod.GET)
    public String loginUser(ModelMap model) {

        return "LoginPage";

    }
}
