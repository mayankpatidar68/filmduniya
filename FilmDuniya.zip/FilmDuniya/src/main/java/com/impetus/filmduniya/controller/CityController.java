package com.impetus.filmduniya.controller;

import java.io.IOException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.impetus.filmduniya.dto.City;
import com.impetus.filmduniya.exception.DAOException;
import com.impetus.filmduniya.service.CityService;




/**
 * The Class CityController.
 *
 * @author mayank.patidar
 */
@Controller
public class CityController {
    
    /** logs the details of class. */
    private static Logger logger = LoggerFactory
            .getLogger(MovieController.class);
    
    /** reference of class city service. */
    @Autowired
    private CityService cityService;
    
    
    /**
     * Handles the request to add a city.
     * 
     * @param detail
     *            the detail
     * @return the JSP page to show after adding city
     */
    @RequestMapping(value = "/saveCity", method = RequestMethod.POST)
    @ResponseBody
    public int addCity(@RequestBody City detail) {

        cityService.addCity(detail);
        logger.info("In Save City ");
        return 1;
    }

    /**
     * Handles the request to City Adder page.
     * 
     * @param model
     *            the model
     * @return the JSP page of City Adder
     */
    @RequestMapping(value = "/CityAdder", method = RequestMethod.GET)
    public String cityAdder(ModelMap model) {
        logger.info("In City Adder ");
        return "CityAdder";
    }

    /**
     * Manage city.
     * 
     * @return the list
     */
    @RequestMapping(value = "/manageCity", method = RequestMethod.GET)
    @ResponseBody
    public List<City> manageCity() {

        List<City> city = cityService.getAllCities();

        return city;

    }

    /**
     * Handles the request to delete a City.
     * 
     * @param id
     *            the id
     * @return the JSP page to show after delete city
     */
    @RequestMapping(value = "/manageCity/{id}", method = RequestMethod.DELETE)
    public void destroyCity(@PathVariable int id) {
        cityService.delete(id);

    }
    
    /**
     * Edits the city.
     * 
     * @param city
     *            the city
     * @return the string
     */
    @RequestMapping(value = "/editCity", method = RequestMethod.POST)
    @ResponseBody
    public String editCity(City city) {

        cityService.editCity(city);
        return "1";

    }
    
    
    /**
     * Handles the request to view all cities.
     * 
     * @param model
     *            the model
     * @return the list of cities
     * @throws IOException
     *             Signals that an I/O exception has occurred.
     */

    @RequestMapping(value = "/city", method = RequestMethod.GET)
    @ResponseBody
    public List<City> getAllCities(Model model) throws IOException {

        return cityService.getAllCities();
    }
    
    /**
     * Handle exception.
     * 
     * @param e
     *            the e
     * @return the model and view
     */
    @ExceptionHandler(DAOException.class)
    public ModelAndView handleException(DAOException e) { 
        ModelAndView modelAndView1 = new ModelAndView();
        modelAndView1.setViewName("error");
        modelAndView1.addObject("error_message", "Something went wrong, Server not Available");
        return modelAndView1;
    }

    /**
     * Handle exception.
     * 
     * @param e
     *            the e
     * @return the model and view
     */
    @ExceptionHandler(Exception.class)
    public ModelAndView handleException(Exception e) {
        ModelAndView modelAndView2 = new ModelAndView();
        modelAndView2.setViewName("error");
        modelAndView2.addObject("error_message",
                "Something went wrong, Server not Available");
        return modelAndView2;
    }

}
