package com.impetus.filmduniya.vo;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;


/**
 * @author mayank.patidar
 *
 */
/**
 * The Class FileUploadForm.
 */
public class FileUploadForm {

    /** The files. */
    private List<MultipartFile> files;

    /** The file. */
    private MultipartFile file;

    /**
     * Gets the files.
     * 
     * @return the files
     */
    public List<MultipartFile> getFiles() {
        return files;
    }

    /**
     * Gets the file.
     * 
     * @return the file
     */
    public MultipartFile getFile() {
        return file;
    }

    /**
     * Sets the files.
     * 
     * @param files
     *            the new files
     */
    public void setFiles(List<MultipartFile> files) {
        this.files = files;
    }

    /**
     * Sets the file.
     * 
     * @param file
     *            the new file
     */
    public void setFile(MultipartFile file) {
        this.file = file;
    }
}
