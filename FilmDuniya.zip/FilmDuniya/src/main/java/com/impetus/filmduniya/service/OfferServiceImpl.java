package com.impetus.filmduniya.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.impetus.filmduniya.dao.OfferDao;
import com.impetus.filmduniya.dto.Offer;



/**
 * @author mayank.patidar
 *
 */
/**
 * The Class OfferServiceImpl.
 */
@Service
@Transactional
public class OfferServiceImpl implements OfferService {

    /** The offer dao. */
    @Autowired
    private OfferDao offerDao;

    /*
     * @see com.impetus.filmduniya.service.OfferService#getByOfferId(int)
     */

    /**
     * Gets the by offer id.
     *
     * @param offerId the offer id
     * @return the by offer id
     */
    public Offer getByOfferId(int offerId) {
        return offerDao.getByOfferId(offerId);
    }

    /*
     * @see com.impetus.filmduniya.service.OfferService#getOfferForShow(int)
     */

    /**
     * Gets the offer for show.
     *
     * @param showId the show id
     * @return the offer for show
     */
    public List<Offer> getOfferForShow(int showId) {
        return offerDao.getOfferForShow(showId);
    }

    /*
     * @see
     * com.impetus.filmduniya.service.OfferService#checkOffer(java.lang.String,
     * int)
     */
    /**
     * Check offer.
     *
     * @param offerCode the offer code
     * @param showId the show id
     * @return the offer
     */
    public Offer checkOffer(String offerCode, int showId) {
        return offerDao.checkOffer(offerCode, showId);
    }


    
    /*
     * @see
     * com.impetus.filmduniya.service.OfferService#addOffer(com.impetus.filmduniya
     * .dto.Offer)
     */
    /**
     * Adds the offer.
     *
     * @param offer the offer
     */
    public void addOffer(Offer offer) {

        offerDao.addOffer(offer);
    }

}
