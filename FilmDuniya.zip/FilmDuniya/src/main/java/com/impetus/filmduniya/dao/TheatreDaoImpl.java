package com.impetus.filmduniya.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.exception.ConstraintViolationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.impetus.filmduniya.dto.Theatre;
import com.impetus.filmduniya.exception.DAOException;


/**
 * Implementation of interface TheatreDao.
 * 
 * @author mayank.patidar
 */

@Repository
public class TheatreDaoImpl implements TheatreDao {

    /** logs the details of class. */
    private static Logger logger = LoggerFactory
            .getLogger(TheatreDaoImpl.class);

    /** The session factory. */
    @Autowired
    private SessionFactory sessionFactory;

    /**
     * Sets the session factory.
     * 
     * @param sessionFactory
     *            the new session factory
     */
    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    /*
     * @see com.impetus.filmduniya.dao.TheatreDao#getAll()
     */
    /**
     * Gets the all theatres by city id.
     *
     * @param cityId the city id
     * @return the all theatres by city id
     */
    public List<Theatre> getAllTheatresByCityId(int cityId) {
try{
        Query query = this.sessionFactory.getCurrentSession().createQuery(
                "FROM Theatre where cityId= :cityId");
        query.setInteger("cityId", cityId);
        return query.list();
    }catch(RuntimeException e){
        logger.error("**********Error while getting thr list of theatre by cityId");
        throw new DAOException("Error while getting thr list of theatre by cityId",e);
    }
}
    

    /*
     * @see
     * com.impetus.filmduniya.dao.TheatreDao#addTheatre(com.impetus.filmduniya
     * .dto.Theatres)
     */
    /**
     * Adds the theatre.
     *
     * @param theatre the theatre
     */
    public void addTheatre(Theatre theatre) {

        try {
            this.sessionFactory.getCurrentSession().save(theatre);
        } catch (ConstraintViolationException e) {

            logger.error("Error in Add Theatre", e);
        }
    }

    /*
     * @see com.impetus.filmduniya.dao.TheatreDao#getAllTheatres()
     */
    /**
     * Gets the all theatres.
     *
     * @return the all theatres
     */
    public List<Theatre> getAllTheatres() {
        Query query = this.sessionFactory.getCurrentSession().createQuery(
                "FROM Theatre");

        return query.list();
    }

    /*
     * @see com.impetus.filmduniya.dao.TheatreDao#delete(int)
     */
    /**
     * Delete.
     *
     * @param theatreId the theatre id
     */
    public void delete(int theatreId) {
try{
        Session session = sessionFactory.getCurrentSession();
        Query query = session.createQuery("from Theatre where theatreId=?");
        query.setInteger(0, theatreId);

        Theatre theatre = (Theatre) query.uniqueResult();
        session.delete(theatre);
        session.getTransaction().commit();
    }
    catch(RuntimeException e){
        logger.error("**********Error while deleting the theatre");
        throw new DAOException("Error while deleting the theatre",e);
    }
}
}
