package com.impetus.filmduniya.service;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.impetus.filmduniya.dto.Movie;
import com.impetus.filmduniya.dto.Shows;
import com.impetus.filmduniya.dto.Theatre;


/**
 * The Class JobSchedulerForCsv.
 */
@Service
@Transactional
public class CsvScheduler {

    /** The log csv. */
    private final Logger logCSV = Logger.getLogger(CsvScheduler.class);

    /** The show service. */
    @Autowired
    private ShowService showService;

    /** The Constant ONE. */
    static final int ONE = 1;

    /** The Constant TWO. */
    static final int TWO = 2;

    /** The Constant THREE. */
    static final int THREE = 3;

    /** The Constant FOUR. */
    static final int FOUR = 4;

    /** The Constant FIVE. */
    static final int FIVE = 5;

    /** The Constant SIX. */
    static final int SIX = 6;

    /** The Constant SEVEN. */
    static final int SEVEN = 7;

    /** The Constant EIGHT. */
    static final int EIGHT = 8;

    /** The Constant NINE. */
    static final int NINE = 9;

    /** The Constant TEN. */
    static final int TEN = 10;

    /** The Constant SIXTY. */
    static final int SIXTY = 60;

    /** The Constant TWENTYFOUR. */
    static final int TWENTYFOUR = 24;

    /** The Constant THOUSAND. */
    static final int THOUSAND = 1000;

    /**
     * JobSchedulerForCsv method.
     */
    @Scheduled(cron="0 0 12 ? * * ")
    public void demoServiceMethod() {

        run();

    }

    /**
     * Run.
     */
    private synchronized void run() {

        String csvFile = "D:\\CSV\\schedule.csv";
        BufferedReader br = null;
        String line = "";
        String cvsSplitBy = ",";

        try {

            br = new BufferedReader(new FileReader(csvFile));
            while ((line = br.readLine()) != null) {
                while ((line = br.readLine()) != null) {
                String[] showData = line.split(cvsSplitBy);

                logCSV.info("shows data = " + " End Time " + showData[0]
                        + " Show Fare " + showData[ONE] + " Show Date "
                        + showData[TWO] + "Show Start Time " + showData[THREE]
                        + " Movie Id " + showData[FOUR] + " Theatre ID "
                        + showData[FIVE] + " , Show Action = " + showData[SIX]
                        + "" + showData[SEVEN] + "" + showData[EIGHT] + ""
                        + showData[NINE] + "");

                String endTime = (showData[0]);
                int fare = Integer.parseInt((showData[ONE]));
                String showDate = (showData[TWO]);
                String startTime = (showData[THREE]);
                String movieId = (showData[FOUR]);
                String theatreId = (showData[FIVE]);
                String action = (showData[SIX]);
                int intAvailableSeats = Integer
                        .parseInt((showData[SEVEN]));
                String strDuration = (showData[EIGHT]);
                String strStatus = (showData[NINE]);
                String[] timeArray=new String[FOUR];
                timeArray[0]=startTime;
                timeArray[1]=endTime;
                timeArray[2]=movieId;
                timeArray[THREE]=theatreId;
                showOperations(timeArray,fare, showDate,action, intAvailableSeats, strDuration,
                        strStatus);

            }
            }
        } catch (FileNotFoundException e) {
            logCSV.error("error logging in scheduling job " + e.getMessage());
        } catch (IOException e) {
            logCSV.error("error logging in scheduling job " + e.getMessage());
        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (IOException e) {
                    logCSV.error("error logging in scheduling job "
                            + e.getMessage());
                }
            }
        }

        logCSV.info("scheduler is working ");
    }

    /**
     * Show operations.
     * 
     * @param endTime
     *            the end time
     * @param fare
     *            the fare
     * @param showDate
     *            the show date
     * @param startTime
     *            the start time
     * @param movieId
     *            the movie id
     * @param theatreId
     *            the theatre id
     * @param action
     *            the action
     * @param availableSeats
     *            the available seats
     * @param duration
     *            the duration
     * @param status
     *            the status
     */
    private void showOperations(String[] timeArray,int fare, String showDate,String action,
            int availableSeats, String duration, String status) {
        String startTime=timeArray[0];
        String endTime=timeArray[1];
        String movieId=timeArray[2];
        String theatreId=timeArray[THREE];
        logCSV.info("going to perform operation by scheduler ");
        if (!"".equals(action) && !endTime.equals("") && !showDate.equals("")
                && !startTime.equals("") && !movieId.equals("")
                && !theatreId.equals("")) {
            
            
            if (checkToAvoidDuplicacy(Integer.parseInt(movieId),
                    Integer.parseInt(theatreId), showDate)) {
                String[] time1Array=new String[FOUR];
                time1Array[0]=startTime;
                time1Array[1]=endTime;
                time1Array[2]=movieId;
                time1Array[THREE]=theatreId;
                schedulerOperation(time1Array, fare, showDate, 
                 action, availableSeats,duration, status);
            }
            
        }

        else {
            logCSV.info("No operation available to perform ");
        }
    }

    /**
     * Scheduler operation.
     * 
     * @param endTime
     *            the end time
     * @param fare
     *            the fare
     * @param showDate
     *            the show date
     * @param startTime
     *            the start time
     * @param movieId
     *            the movie id
     * @param theatreId
     *            the theatre id
     * @param action
     *            the action
     * @param availableSeats
     *            the available seats
     * @param duration
     *            the duration
     * @param status
     *            the status
     */
    public void schedulerOperation(String[] time1Array, int fare, String showDate,
             String action,int availableSeats, String duration, String status) {
        String startTime=time1Array[0];
        String endTime=time1Array[1];
        String movieId=time1Array[2];
        String theatreId=time1Array[THREE];
        Shows showsdata = new Shows();
        showsdata.setEndTime(endTime);
        showsdata.setStartTime(startTime);
        showsdata.setShowDate(showDate);
        showsdata.setFare(fare);
        showsdata.setMovie(movieOpertaion(movieId));
        showsdata.setTheatre(theatreOperation(theatreId));
        showsdata.setAvailableSeats(availableSeats);
        showsdata.setDuration(duration);
        showsdata.setStatus(status);

        logCSV.info(" shows data obecjt properties  " + showsdata.toString());
        String[] time2Array=new String[FOUR];
        time2Array[0]=startTime;
        time2Array[1]=endTime;
        time2Array[2]=action;
        time2Array[THREE]=duration;
        showService.addUpdateDeleteShow(time2Array, fare, showDate, 
                Integer.parseInt(movieId), Integer.parseInt(theatreId), 
                availableSeats,status);
    }

    /**
     * Theatre operation.
     * 
     * @param theatreId
     *            the theatre id
     * @return the theatre
     */
    private Theatre theatreOperation(String theatreId) {
        logCSV.info("in theatreOperation method theatre id is  " + theatreId);
        int theatreIdInt = Integer.parseInt(theatreId);
        Theatre theatre = new Theatre();
        theatre.setTheatreId(theatreIdInt);
        return theatre;
    }

    /**
     * Movie opertaion.
     * 
     * @param movieId
     *            the movie id
     * @return the movie
     */
    private Movie movieOpertaion(String movieId) {

        int movieIdInt = Integer.parseInt(movieId);
        logCSV.info("in movieOpertaion method movie id is  " + movieIdInt);
        Movie movie = new Movie();
        movie.setMovieId(Integer.parseInt(movieId));
        return movie;

    }

    
    /**
     * Check to avoid duplicacy.
     * 
     * @param movieId
     *            the movie id
     * @param theatreId
     *            the theatre id
     * @param date
     *            the date
     * @return true, if successful
     */
    private boolean checkToAvoidDuplicacy(int movieId, int theatreId,
            String date) {
        List<Shows> showList = showService.getList(movieId, theatreId, date);
        boolean checkAvailability = false;
        if (showList.size() == 0) {
            logCSV.info("show is not available so we can add it ");
            checkAvailability = true;
        }

        else {
            logCSV.info("show is already available so can't be insert duplicate data ,  show details are  ===> MovieId is  "
                    + " showDate is " + date);
            checkAvailability = false;
        }

        return checkAvailability;

    }

}
