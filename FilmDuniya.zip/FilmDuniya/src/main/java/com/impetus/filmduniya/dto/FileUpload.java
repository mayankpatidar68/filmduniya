package com.impetus.filmduniya.dto;

import org.springframework.web.multipart.MultipartFile;


/**
 * @author mayank.patidar
 *
 */
/**
 * The Class FileUpload.
 */
public class FileUpload {

    /** The file. */
    private MultipartFile file;

    /**
     * Gets the file.
     * 
     * @return the file
     */
    public MultipartFile getFile() {
        return file;
    }

    /**
     * Sets the file.
     * 
     * @param file
     *            the new file
     */
    public void setFile(MultipartFile file) {

        this.file = file;
    }
}
