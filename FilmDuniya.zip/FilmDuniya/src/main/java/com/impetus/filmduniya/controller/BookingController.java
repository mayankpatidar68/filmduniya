package com.impetus.filmduniya.controller;



import java.util.List;
import javax.persistence.EntityExistsException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import com.impetus.filmduniya.dto.Booking;
import com.impetus.filmduniya.dto.Seat;
import com.impetus.filmduniya.dto.Shows;
import com.impetus.filmduniya.dto.Ticket;
import com.impetus.filmduniya.dto.User;
import com.impetus.filmduniya.exception.DAOException;
import com.impetus.filmduniya.service.BookingHistoryService;
import com.impetus.filmduniya.service.BookingService;
import com.impetus.filmduniya.service.SeatService;
import com.impetus.filmduniya.service.ShowService;
import com.impetus.filmduniya.service.UserService;
import com.impetus.filmduniya.vo.BookingShowId;


/**
 * Handles all the activities of Booking.
 * 
 * @author mayank.patidar
 * 
 */
@Controller
public class BookingController {

    /** logs the details of class. */
    private static Logger logger = LoggerFactory
            .getLogger(BookingController.class);



    /** reference of class show service. */
    @Autowired
    private ShowService showService;

    /** reference of class booking service. */
    @Autowired
    private BookingService bookingService;

    
    /** The seat service. */
    @Autowired
    private SeatService seatService;


    /** The booking history service. */
    @Autowired
    private BookingHistoryService bookingHistoryService;


    /** The user service. */
    @Autowired
    private UserService userService;
    
   
    /**
     * Handles the request to view all shows.
     * 
     * @param cityId
     *            the city id
     * @param theatreId
     *            the theatre id
     * @param movieId
     *            the movie id
     * @param noOfSeats
     *            the no of seats
     * @param showDate
     *            the show date
     * @return the list of shows
     */
    @RequestMapping(value = "/search", method = RequestMethod.GET)
    @ResponseBody
    public List<Shows> getSearchInput(int cityId, int theatreId, int movieId,BookingShowId bookingShowId,
            int noOfSeats, String showDate,HttpSession session) {
         session.setAttribute("noOfSeats",bookingShowId.getNoOfSeats());
        return showService.getAllShowsByCriteria(cityId, theatreId, movieId,
                noOfSeats, showDate);
    }

    /**
     * Handles the request to view Report generation page.
     * 
     * @param model
     *            the model
     * @return the JSP page of Report Generation
     */
    @RequestMapping(value = "/generatePDF", method = RequestMethod.GET)
    public String pdfReport(ModelMap model) {
        return "GeneratePdfReport";
    }

    /**
     * Handles the request to Download pdf.
     * 
     * @param request
     *            containg detail to generate pdf
     * @return the model and view
     */
    @RequestMapping(value = "/downloadPDF", method = RequestMethod.POST)
    public ModelAndView downloadPdf(HttpServletRequest request) {
        String movieIdString = request.getParameter("movieDropDown");
        String showDateString = request.getParameter("showDate");
        logger.info("movieIdString: " + movieIdString);
        logger.info("fromDateString: " + showDateString);
        List<Booking> bookingList = bookingService.getPDFDetail(movieIdString,
                showDateString);
        return new ModelAndView("pdfView", "bookingList", bookingList);
    }

   
    
    /**
     * Resolve the request to book Movie page.
     * 
     * @param bookingShowId
     *            the booking show id
     * @param model
     *            the model
     * @param session
     *            the session
     * @return the JSP page of bookShow
     */
    @RequestMapping(value = "/book", method = RequestMethod.POST)
    public String bookRequest(
            @ModelAttribute("showIdAttribute") BookingShowId bookingShowId,
            Model model, HttpSession session) {
        logger.info("In book call" + bookingShowId.getShowsId());
   
        Authentication auth = SecurityContextHolder.getContext()
                .getAuthentication();
        String currentUsername = auth.getName();
        logger.info("Booking email id" + currentUsername);
        int showsId = bookingShowId.getShowsId();
        session.setAttribute("showId", showsId);
        session.setAttribute("user", currentUsername);
        model.addAttribute("showId", showsId);
        model.addAttribute("user", currentUsername);
        return "BookShow";

    }

    /**
     * Resolve the request of book Movie page.
     * 
     * @param model
     *            the model
     * @return the JSP page to SearchMovie
     */
    @RequestMapping(value = "/book", method = RequestMethod.GET)
    public String bookPage(Model model) {
        model.addAttribute("showIdAttribute", new BookingShowId());
        return "SearchMovie";
    }

    /**
     * Resolve the request to book Booking page.
     * 
     * @param seatNoValue
     *            the seat no value
     * @param session
     *            the session
     * @return the JSP page of booking movie
     */
    @RequestMapping(value = "/reservation", method = RequestMethod.POST)
    @ResponseBody
    public Booking seatBooking(@RequestBody Integer seatNoValue[],
            HttpSession session) {
        Authentication auth = SecurityContextHolder.getContext()
                .getAuthentication();
        String currentUserEmail = auth.getName();

        logger.info("user");
        logger.info("showId1");
        Booking booking = bookingService.reserveSeatAndBook(seatNoValue,
                currentUserEmail);
        session.setAttribute("bookingId", booking.getBookingId());
        return booking;
    }

    
    
    

    /**
     * Gets the reserved seats.
     * 
     * @param showId
     *            the show id
     * @return the reserved seats
     */
    @RequestMapping(value = "/bookedSeats", method = RequestMethod.GET)
    @ResponseBody
    public List<Seat> getReservedSeats(int showId) {

        return seatService.getReservedSeats(showId);
    }

    /**
     * Payment gatway.
     * 
     * @param model
     *            the model
     * @param session
     *            the session
     * @return the string
     */
    @RequestMapping(value = "/PaymentGateway", method = RequestMethod.GET)
    public String paymentGateway(Model model, HttpSession session) {

        return "PaymentGateway";
    }

    /**
     * Handles the request to show page after ticket is booked.
     * 
     * @param model
     *            the model
     * @param session
     *            the session
     * @return the JSP page after booking payment gets success
     */

    @RequestMapping(value = "/paymentSuccess", method = RequestMethod.GET)
    public String paymentSuccessPage(ModelMap model, HttpSession session) {
        int showId = (Integer) session.getAttribute("showId");
        Authentication auth = SecurityContextHolder.getContext()
                .getAuthentication();
        String emailId = auth.getName();
        int i = bookingService.sendBookingMail(showId, emailId);
        String mailDetails = null;
        if (i == 0)
        {
            mailDetails = "Sorry Mail could not be sent as Mail server was down but tickets have been booked";
            model.addAttribute("MailDetail",mailDetails);
        }
        else
        {
            mailDetails = "Mail sent on " + emailId + " and Tickets booked";
            model.addAttribute("MailDetail",mailDetails);
        }

        logger.info("payment is done");
        return "paymentSuccess";
    }

    

    /**
     * Ticket history detail.
     * 
     * @param bookingId
     *            the booking id
     * @return the list
     */
    @RequestMapping(value = "/ticketHistory", method = RequestMethod.GET)
    @ResponseBody
    public List<Ticket> ticketHistoryDetail(int bookingId) {

        logger.info("travel data for grid " + bookingId);
        return bookingHistoryService.getTicketDetails(bookingId);

    }

    /**
     * Cancel ticket.
     * 
     * @param cancellationTicketId
     *            the cancellation ticket id
     * @return the int
     */
    @RequestMapping(value = "/cancelTicket", method = RequestMethod.POST)
    @ResponseBody
    public int cancelTicket(@RequestBody Integer cancellationTicketId) {
        logger.info("cancel ticket" + cancellationTicketId);

        return bookingHistoryService.cancelTicket(cancellationTicketId);

    }

    /**
     * History.
     * 
     * @return the list
     */
    @RequestMapping(value = "/history", method = RequestMethod.GET)
    @ResponseBody
    public List<Booking> history() {

        logger.info("booking data for grid");
        Authentication auth = SecurityContextHolder.getContext()
                .getAuthentication();
        String currentUsername = auth.getName();

        User user = userService.getByUserEmail(currentUsername);

        return bookingHistoryService.getBookingHistory(user);

    }


    /**
     * Handles the request to SearchMovie page.
     * 
     * @param model
     *            the model
     * @return the JSP page of Search Movie
     */
    @RequestMapping(value = "/SearchMovie", method = RequestMethod.GET)
    public String searchMovie(ModelMap model) {
        model.addAttribute("showIdAttribute", new BookingShowId());
        return "SearchMovie";
    }

    /**
     * Handle exception.
     * 
     * @param e
     *            the e
     * @return the model and view
     */
    @ExceptionHandler(DAOException.class)
    public ModelAndView handleException(DAOException e) {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("error");
        modelAndView.addObject("error_message","Something went wrong, Server not Available");
        return modelAndView;
    }

    /**
     * Handle exception.
     * 
     * @param e
     *            the e
     * @return the model and view
     */
    @ExceptionHandler(Exception.class)
    public ModelAndView handleException(Exception e) {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("error");
        modelAndView.addObject("error_message",
                "Something went wrong, Server not Available");
        return modelAndView;
    }

    /**
     * Handle entity exception.
     * 
     * @param e
     *            the e
     * @return the model and view
     */
    @ExceptionHandler(EntityExistsException.class)
    public ModelAndView handleEntityException(EntityExistsException e) { 
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("error");
        modelAndView.addObject("error_message", "Something went wrong, Server not Available");
        return modelAndView;
    }

}
