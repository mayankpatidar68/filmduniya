package com.impetus.filmduniya.vo;

import org.springframework.validation.Errors;
import org.springframework.validation.Validator;



/**
 * @author mayank.patidar
 *
 */
/**
 * The Class FileValidator.
 */
public class FileValidator implements Validator {

    
    /*
     * @see org.springframework.validation.Validator#supports(java.lang.Class)
     */
    /**
     * Supports.
     *
     * @param arg0 the arg0
     * @return true, if successful
     */
    public boolean supports(Class<?> arg0) {

        return false;
    }

    
    /*
     * @see org.springframework.validation.Validator#validate(java.lang.Object,
     * org.springframework.validation.Errors)
     */
    /**
     * Validate.
     *
     * @param uploadedFile the uploaded file
     * @param errors the errors
     */
    public void validate(Object uploadedFile, Errors errors) {

      
    }
}
