package com.impetus.filmduniya.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.impetus.filmduniya.dao.BookingDao;
import com.impetus.filmduniya.dao.ShowDao;
import com.impetus.filmduniya.dto.Booking;
import com.impetus.filmduniya.dto.Offer;
import com.impetus.filmduniya.dto.Seat;
import com.impetus.filmduniya.dto.Shows;
import com.impetus.filmduniya.dto.Ticket;
import com.impetus.filmduniya.dto.User;
import com.impetus.filmduniya.exception.DAOException;
import com.impetus.filmduniya.exception.TicketNotAvailableException;
import com.impetus.filmduniya.mail.MailSend;

/**
 * The Class BookingServiceImpl.
 * 
 * @author mayank.patidar
 */
@Service
@Transactional(readOnly = true)
public class BookingServiceImpl implements BookingService {

    /** logs the details of class. */
    private static Logger logger = LoggerFactory
            .getLogger(BookingServiceImpl.class);
    

    /** The Constant TIME_SPAN. */
    private static final int TIME_SPAN = 1000 * 60;

    /** The user service. */
    @Autowired
    private UserService userService;

    /** The show service. */
    @Autowired
    private ShowService showService;

    /** The offer service. */
    @Autowired
    private OfferService offerService;

    /** The booking dao. */
    @Autowired
    private BookingDao bookingDao;

    /** The seat service. */
    @Autowired
    private SeatService seatService;

    /** The show dao. */
    @Autowired
    private ShowDao showDao;

    /** The ticket service. */
    @Autowired
    private TicketService ticketService;

    /** The mail. */
    @Autowired
    private MailSend mail;
    
    private int fare;

    /*
     * @see
     * com.impetus.filmduniya.service.BookingService#reserveSeatAndBook(java
     * .lang.Integer[], java.lang.String)
     */
    /**
     * Reserve seat and book.
     * 
     * @param seatNoValue
     *            the seat no value
     * @param currentUserEmail
     *            the current user email
     * @return the booking
     */
    @Transactional(rollbackFor=Exception.class)
    public  Booking reserveSeatAndBook(Integer[] seatNoValue,
            String currentUserEmail) {
        logger.info("Request to book Movie Ticket");
        int showId = seatNoValue[0];
        int length = seatNoValue.length;
        Offer offer;
        Shows show = showService.getByShowId(showId);
        int offerId = seatNoValue[length - 1];
        if (offerId == 0) {
            offer = null;
        } else {
            offer = offerService.getByOfferId(offerId);
        }

        int noOfSeats = length - 2;

        Booking booking = new Booking();
        if (show.getAvailableSeats() < noOfSeats) {
           
            DAOException daoException= new DAOException("seat not available");
            throw daoException;
        }

        else {
            int count = 1;
            for (int i = 1; i <= (length - 2); i++) {
                Seat seat = seatService.getSeat(show, seatNoValue[i]);
                logger.info(seat.getSeatNo());
                if (seat.getStatus().equalsIgnoreCase("Booked")) {
                    count = 0;
                    break;
                } else {
                    seat.setStatus("Booked");
                    seatService.updateStatus(seat);
                }

            }
            if (count == 1) {
                show.setAvailableSeats(show.getAvailableSeats() - noOfSeats);
                showService.updateAvailableSeats(show);
                User user = userService.getByUserEmail(currentUserEmail);
                int actualFare = show.getFare() * noOfSeats;

                booking.setActualFare(actualFare);
                booking.setUser(user);
                booking.setShow(show);
                booking.setOffer(offer);
                booking.setNoOfTickets(noOfSeats);
                if (offer == null) {
                       fare=(actualFare);
                    booking.setTotalFare(fare);

                } else {
                   fare= actualFare - (offer.getDiscount()*noOfSeats);
                    booking.setTotalFare(fare);
                }
                Booking booked = bookingDao.saveBooking(booking);
                logger.info("booking details entered");

                logger.debug("booking Done");
                bookingss(length, booked, show, seatNoValue);
                logger.debug("tickets generated");
                return booked;
            } else {
                
                logger.error("tickets trying for are sold");
                throw new TicketNotAvailableException("Tickets Not available");

            }

        }
    }

    /**
     * Bookingss.
     * 
     * @param length
     *            the length
     * @param booked
     *            the booked
     * @param show
     *            the show
     * @param seatNoValue
     *            the seat no value
     */
    public void bookingss(int length, Booking booked, Shows show,
            Integer[] seatNoValue) {
        for (int i = 1; i <= (length - 2); i++) {
            Ticket ticket = new Ticket();
            Seat seat = seatService.getSeat(show, seatNoValue[i]);
            ticket.setStatus("Active");
            ticket.setBooking(booked);
            ticket.setSeat(seat);
            ticketService.save(ticket);
        }
    }

    /*
     * @see com.impetus.filmduniya.service.BookingService#sendBookingMail(int,
     * java.lang.String)
     */
    /**
     * Send booking mail.
     * 
     * @param showId
     *            the show id
     * @param emailId
     *            the email id
     */
    
    public int sendBookingMail(int showId, String emailId) {
        logger.info("In Mail.......");
        Shows show = showDao.getByShowId(showId);
        StringBuffer messageBuffer = new StringBuffer();
        String message;
        messageBuffer.append("Hello Sir/Madam, \n\n");
        messageBuffer
                .append("Thank You for using FILM-DUNIYA, its our pleasure to serve you."
                        + "\n\n Here is the ticket which you have booked from FILM_DUNIYA !!"
                        + "\n\n Movie Name \t\t:\t"
                        + show.getMovie().getMovieName()
                        + "\n Theatre Name \t\t:\t"
                        + show.getTheatre().getTheatreName()
                        + "\n City \t\t\t:\t"
                        + show.getTheatre().getCity().getCityName()
                        + "\n Show Date \t\t:\t"
                        + show.getShowDate()
                        + "\n Show Time \t\t:\t"
                        + show.getStartTime()
                        + "\n Fare \t\t\t:\t" + fare);

        message = messageBuffer.toString();
        try{
        mail.sendMail(emailId, "Ticket booked", message);
        logger.info("Mail Send");}
        catch(Exception e){
            return 0;
        }
            return 1;
    }

    

    /*
     * @see com.impetus.filmduniya.service.BookingService#getPDFDetail(java.lang
     * .String, java.lang.String)
     */
    /**
     * Gets the PDF detail.
     *
     * @param movieIdString the movie id string
     * @param showDateString the show date string
     * @return the PDF detail
     */
    public List<Booking> getPDFDetail(String movieIdString,
         String showDateString) {
        int movieId = Integer.parseInt(movieIdString);
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        Date showDate = null;
        
        try {
            showDate = formatter.parse(showDateString);
        } catch (ParseException e) {
            logger.error("Date parsing exception" + e);
        }
        return bookingDao.getBookingByMovieDate(movieId,showDate);
        
    }

    /**
     * Scheduled email.
     */
    @Scheduled(fixedRate = TIME_SPAN)
    public void scheduledEmail() {
        logger.info("In email scheduler");
        List<Booking> bookings = bookingDao.sendScheduleMail();

        for (Booking booking : bookings) {
            String message = "You have Your Movie Show Starting in 3 Hours of Movie: "
                    + booking.getShow().getMovie().getMovieName()
                    + " in Theatre "
                    + booking.getShow().getTheatre().getTheatreName()
                    + " please be on time and enjoy the show.";
            logger.info("Mail scheduled message " + message);
            try {
                mail.sendMail(booking.getUser().getEmailId(), "Show Reminder!",
                        message);
            } catch (Exception e) {
                logger.error("Scheduled mail could not be delivered due to unavailablity of Mail server.");
            }
            logger.info("Scheduled mail sent");
        }

    }
}