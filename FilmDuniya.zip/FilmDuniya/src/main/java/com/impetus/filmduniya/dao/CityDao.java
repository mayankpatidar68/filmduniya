package com.impetus.filmduniya.dao;

import java.util.List;

import com.impetus.filmduniya.dto.City;


/**
 * Data Access interface for city table in database.
 *
 * @author mayank.patidar
 */
public interface CityDao {

    
    /**
     * Gets the all cities.
     *
     * @return the all cities
     */
    List<City> getAllCities();

    /**
     * Adds the city.
     *
     * @param city the city
     */
    void addCity(City city);

    
    /**
     * Delete.
     *
     * @param cityId the city id
     */
    void delete(int cityId);

    /**
     * Edits the city.
     *
     * @param city the city
     */
    void editCity(City city);
}
