package com.impetus.filmduniya.exception;

/**
 * handles Exception when ticket not available.
 * 
 * @author mayank.patidar
 */
public class TicketNotAvailableException extends RuntimeException {

    /** The message. */
    private String message;

    /** The cause. */
    private Throwable cause;

    /*
     * @see java.lang.Throwable#getMessage()
     */
    public String getMessage() {
        return message;
    }

    /**
     * Sets the message.
     * 
     * @param message
     *            the new message
     */
    public void setMessage(String message) {
        this.message = message;
    }

    /*
     * @see java.lang.Throwable#getCause()
     */
    public Throwable getCause() {
        return cause;
    }

    /**
     * Sets the cause.
     * 
     * @param cause
     *            the new cause
     */
    public void setCause(Throwable cause) {
        this.cause = cause;
    }

    /**
     * Instantiates a new ticket not available exception.
     */
    public TicketNotAvailableException() {
        super();
    }

    /**
     * Instantiates a new ticket not available exception.
     * 
     * @param message
     *            the message
     */
    public TicketNotAvailableException(String message) {
        super();
        this.message = message;
    }

    /**
     * Instantiates a new ticket not available exception.
     * 
     * @param message
     *            the message
     * @param cause
     *            the cause
     */
    public TicketNotAvailableException(String message, Throwable cause) {
        super(message, cause);
        this.message = message;
        this.cause = cause;
    }

}
