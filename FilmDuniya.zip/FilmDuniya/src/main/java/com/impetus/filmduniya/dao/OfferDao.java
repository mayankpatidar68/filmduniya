package com.impetus.filmduniya.dao;

import java.util.List;

import com.impetus.filmduniya.dto.Offer;


/**
 * Data Access interface for offer table in database.
 * 
 * @author mayank.patidar
 */
public interface OfferDao {

    /**
     * Gets the by offer id.
     *
     * @param offerId the offer id
     * @return the by offer id
     */
    Offer getByOfferId(int offerId);

    /**
     * Gets the offer for show.
     *
     * @param showId the show id
     * @return the offer for show
     */
    List<Offer> getOfferForShow(int showId);

   
    /**
     * Check offer.
     *
     * @param offerCode the offer code
     * @param showId the show id
     * @return the offer
     */
    Offer checkOffer(String offerCode, int showId);

    
    /**
     * Adds the offers.
     *
     * @param offerInserList the offer inser list
     */
    void addOffers(List<Offer> offerInserList);

   
    /**
     * Adds the offer.
     *
     * @param offer the offer
     */
    void addOffer(Offer offer);
}
