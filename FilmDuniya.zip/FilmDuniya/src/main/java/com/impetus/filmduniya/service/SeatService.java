package com.impetus.filmduniya.service;

import java.util.List;

import com.impetus.filmduniya.dto.Seat;
import com.impetus.filmduniya.dto.Shows;





/**
 * The Interface SeatService.
 *
 * @author mayank.patidar
 */

public interface SeatService {

   
    
    /**
     * Gets the seat.
     *
     * @param show the show
     * @param seatNo the seat no
     * @return the seat
     */
    Seat getSeat(Shows show, int seatNo);

    
    /**
     * Update status.
     *
     * @param seat the seat
     */
    void updateStatus(Seat seat);

    
    
    /**
     * Gets the reserved seats.
     *
     * @param showId the show id
     * @return the reserved seats
     */
    List<Seat> getReservedSeats(int showId);
}
