package com.impetus.filmduniya.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.impetus.filmduniya.dao.SeatDao;
import com.impetus.filmduniya.dto.Seat;
import com.impetus.filmduniya.dto.Shows;



/**
 * @author mayank.patidar
 *
 */
/**
 * The Class SeatServiceImpl.
 */
@Service
@Transactional
public class SeatServiceImpl implements SeatService {

    /** The seat dao. */
    @Autowired
    private SeatDao seatDao;

    /** The show service. */
    @Autowired
    private ShowService showService;

    /*
     * @see
     * com.impetus.filmduniya.service.SeatService#getSeat(com.impetus.filmduniya
     * .dto.Shows, int)
     */
    /**
     * Gets the seat.
     *
     * @param show the show
     * @param seatNo the seat no
     * @return the seat
     */
    public Seat getSeat(Shows show, int seatNo) {

        return seatDao.getSeat(show, seatNo);
    }

    /*
     * @see com.impetus.filmduniya.service.SeatService#updateStatus(com.impetus.
     * filmduniya.dto.Seat)
     */
    /**
     * Update status.
     *
     * @param seat the seat
     */
    public void updateStatus(Seat seat) {

        seatDao.updateStatus(seat);
    }

    /*
     * @see com.impetus.filmduniya.service.SeatService#getReservedSeats(int)
     */
    /**
     * Gets the reserved seats.
     *
     * @param showId the show id
     * @return the reserved seats
     */
    public List<Seat> getReservedSeats(int showId) {
        Shows show = showService.getByShowId(showId);
        return seatDao.getReservedSeats(show);
    }

}
