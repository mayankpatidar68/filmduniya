package com.impetus.filmduniya.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.impetus.filmduniya.dao.UserDao;
import com.impetus.filmduniya.dto.User;
import com.impetus.filmduniya.mail.MailSend;



/**
 * @author mayank.patidar
 *
 */
/**
 * The Class UserServiceImpl.
 */
@Service
@Transactional
public class UserServiceImpl implements UserService {

    /** logs the details of class. */
    private static Logger logger = LoggerFactory
            .getLogger(UserServiceImpl.class);

    /** The user dao. */
    @Autowired
    private UserDao userDao;

    /** The mail. */
    @Autowired
    private MailSend mail;

    /*
     * @see
     * com.impetus.filmduniya.service.UserService#addUser(com.impetus.filmduniya
     * .dto.User)
     */

    /**
     * Adds the user.
     *
     * @param user the user
     */
    public void addUser(User user) {

        userDao.addUser(user);
    }

    /*
     * @see
     * com.impetus.filmduniya.service.UserService#getByUserEmail(java.lang.String
     * )
     */
    /**
     * Gets the by user email.
     *
     * @param currentUserEmail the current user email
     * @return the by user email
     */
    public User getByUserEmail(String currentUserEmail) {

        return userDao.getByUserEmail(currentUserEmail);

    }

    /*
     * @see
     * com.impetus.filmduniya.service.UserService#editUser(com.impetus.filmduniya
     * .dto.User)
     */
    /**
     * Edits the user.
     *
     * @param user the user
     */
    public void editUser(User user) {
        userDao.editUser(user);
    }

    /*
     * @see com.impetus.filmduniya.service.UserService#getAllUsers()
     */
    /**
     * Gets the all users.
     *
     * @return the all users
     */
    public List<User> getAllUsers() {
        return userDao.getAllUsers();
    }

    /*
     * @see
     * com.impetus.filmduniya.service.UserService#getUserDetails(com.impetus
     * .filmduniya.dto.User)
     */
    /**
     * Gets the user details.
     *
     * @param user the user
     * @return the user details
     */
    public User getUserDetails(User user) {
        return userDao.getUserDetails(user.getEmailId());
    }

    /*
     * @see com.impetus.filmduniya.service.UserService#getUserById(int)
     */
    /**
     * Gets the user by id.
     *
     * @param userId the user id
     * @return the user by id
     */
    public User getUserById(int userId) {

        return null;
    }

    /*
     * @see
     * com.impetus.filmduniya.service.UserService#sendUserMail(java.lang.String)
     */
    /**
     * Send user mail.
     *
     * @param emailId the email id
     */
    public void sendUserMail(String emailId) {
        logger.info("In Mail.......");
        User user = userDao.getUserDetails(emailId);
       
        StringBuffer messageBuffer = new StringBuffer();
       
        String message;
        messageBuffer.append("Hello Sir/Madam, \n\n");
        messageBuffer
                .append("Thank You for using FilmDuniya, its our pleasure to serve you."

                        + "\n\n Your Password Is \t\t:\t" + user.getPassword());

        // + "\n Seat No(S) \t\t:\t"+

        message = messageBuffer.toString();

        mail.sendMail(emailId, "User Details", message);
        logger.info("Mail Send");
    }
}
