package com.impetus.filmduniya.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.impetus.filmduniya.dao.MovieDao;
import com.impetus.filmduniya.dto.Movie;



/**
 * @author mayank.patidar
 *
 */
/**
 * The Class MovieServiceImpl.
 */
@Service
@Transactional
public class MovieServiceImpl implements MovieService {

    /** logs the details of class.  */
    private static Logger logger = LoggerFactory
            .getLogger(MovieServiceImpl.class);

    /** The movie dao. */
    @Autowired
    private MovieDao movieDao;

    /*
     * @see
     * com.impetus.filmduniya.service.MovieService#addMovie(com.impetus.filmduniya
     * .dto.Movie)
     */
    /**
     * Adds the movie.
     *
     * @param movie the movie
     */
    public void addMovie(Movie movie) {

        movieDao.addMovie(movie);
    }

    /*
     * @see
     * com.impetus.filmduniya.service.MovieService#getAllShowsByTheatreId(int)
     */
    /**
     * Gets the all movies by theatre id.
     *
     * @param TheatreId the theatre id
     * @return the all movies by theatre id
     */
    public List<Movie> getAllShowsByTheatreId(int theatreId) {
        return movieDao.getAllMovieByTheatreId(theatreId);
    }

    /*
     * @see com.impetus.filmduniya.service.MovieService#getAllMovies()
     */
    /**
     * Gets the all movies.
     *
     * @return the all movies
     */
    public List<Movie> getAllMovies() {
        return movieDao.getAllMovies();
    }

    /*
     * @see com.impetus.filmduniya.service.MovieService#delete(int)
     */
    /**
     * Delete.
     *
     * @param movieId the movie id
     */
    public void delete(int movieId) {
  
        movieDao.delete(movieId);

    }

    /*
     * @see com.impetus.filmduniya.service.MovieService#getMovieById(int)
     */
    /**
     * Gets the movies by  id.
     *
     * @param MovieId the id
     * @return the  movies by  id
     */
    public Movie getMovieById(int mid) {
        return movieDao.getMovieById(mid);
    }

    /*
     * @see
     * com.impetus.filmduniya.service.MovieService#editMovie(com.impetus.filmduniya
     * .dto.Movie)
     */
    /**
     * Update.
     *
     * @param movie the movie 
     */
    public void editMovie(Movie movie) {
        movieDao.editMovie(movie);
    }

    /*
     * @see
     * com.impetus.filmduniya.service.MovieService#getByName(java.lang
     * .String)
     */
    /**
     * Gets the movie by  Name.
     *
     * @param MovieName the name
     * @return the  movie by  name
     */
    public Movie getByName(String movieName) {
        logger.info("getting movie by its name");
        logger.debug("getting movie by its name");
        return movieDao.getByName(movieName);
    }

}
