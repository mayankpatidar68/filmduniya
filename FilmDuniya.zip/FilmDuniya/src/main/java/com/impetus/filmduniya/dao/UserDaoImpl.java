package com.impetus.filmduniya.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.exception.ConstraintViolationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.impetus.filmduniya.dto.User;
import com.impetus.filmduniya.exception.DAOException;



/**
 * @author mayank.patidar
 *
 */
/**
 * The Class UserDaoImpl.
 */
@Repository
public class UserDaoImpl implements UserDao {

    /** logs the details of class. */
    private static Logger logger = LoggerFactory.getLogger(UserDaoImpl.class);

    /** The session factory. */
    @Autowired
    private SessionFactory sessionFactory;

    /**
     * Sets the session factory.
     * 
     * @param sessionFactory
     *            the new session factory
     */
    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    /*
     * @see
     * com.impetus.filmduniya.dao.UserDao#addUser(com.impetus.filmduniya.dto
     * .User)
     */
    /**
     * Adds the user.
     *
     * @param user the user
     */
    public void addUser(User user) {

        try {
            this.sessionFactory.getCurrentSession().save(user);
        } catch (ConstraintViolationException e) {
            logger.error("Error in Add User", e);
            throw new DAOException("Error adding a new user account",e);

        }

    }

    /*
     * @see com.impetus.filmduniya.dao.UserDao#getByUserEmail(java.lang.String)
     */
    /**
     * Gets the by user email.
     *
     * @param userEmail the user email
     * @return the by user email
     */
    public User getByUserEmail(String userEmail) {
        try{
        Query query = this.sessionFactory.getCurrentSession().createQuery(
                "from User where emailId= :userEmail ");
        query.setString("userEmail", userEmail);
        User user = (User) query.uniqueResult();

        return user;
    }
    catch(RuntimeException e){
        logger.error("**************Error while getting user by email id**************");
        throw new DAOException("Error while getting user by email id",e);
}
}


    /*
     * @see
     * com.impetus.filmduniya.dao.UserDao#editUser(com.impetus.filmduniya.dto
     * .User)
     */
    /**
     * Edits the user.
     *
     * @param user the user
     */
    public void editUser(User user) {
try{
        // Retrieve session from Hibernate
        Session session = sessionFactory.getCurrentSession();

        // Retrieve existing person via id
        User existingUser = (User) session.get(User.class, user.getUserId());

        // Assign updated values to this person
        existingUser.setFirstName(user.getFirstName());
        existingUser.setLastName(user.getLastName());
        existingUser.setEmailId(user.getEmailId());
        existingUser.setPassword(user.getPassword());
        existingUser.setConfirmPassword(user.getConfirmPassword());
        existingUser.setContactNumber(user.getContactNumber());

        // Save updates
        session.save(existingUser);
    }catch(RuntimeException e){

        logger.error("**************Error Changing User Information**************");
        throw new DAOException("Error Changing User Information",e);
    }
    
}



    /*
     * @see com.impetus.filmduniya.dao.UserDao#getUserDetails(java.lang.String)
     */
    /**
     * Gets the user details.
     *
     * @param emailId the email id
     * @return the user details
     */
    public User getUserDetails(String emailId) {

        Session session = sessionFactory.getCurrentSession();
        Query query = session.createQuery("from User where emailId= :emailId");
        query.setParameter("emailId", emailId);

        return (User) query.uniqueResult();
    }

    /**
     * Gets the user details.
     * 
     * @param user
     *            the user
     * @return the user details
     */
    public List<User> getUserDetails(User user) {
        Query query = this.sessionFactory.getCurrentSession().createQuery(
                "FROM User where userId= :userId");
        query.setEntity("user", user);
        return query.list();
    }

    /*
     * @see com.impetus.filmduniya.dao.UserDao#getAllUsers()
     */
    /**
     * Gets the all users.
     *
     * @return the all users
     */
    public List<User> getAllUsers() {

        return null;

    }

    /**
     * Gets the user by id.
     * 
     * @param userId
     *            the user id
     * @return the user by id
     */
    public User getUserById(int userId) {
        return (User) sessionFactory.getCurrentSession()
                .get(User.class, userId);
    }
    
    
}
