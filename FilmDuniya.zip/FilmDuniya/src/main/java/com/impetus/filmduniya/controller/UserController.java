package com.impetus.filmduniya.controller;

import java.util.ArrayList;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import com.impetus.filmduniya.dto.User;
import com.impetus.filmduniya.exception.DAOException;
import com.impetus.filmduniya.service.CsvScheduler;
import com.impetus.filmduniya.service.UserService;
import com.impetus.filmduniya.vo.BookingShowId;


/**
 * Handles all the activities of user.
 * 
 * @author mayank.patidar
 * 
 */

@Controller
public class UserController {

    /** logs the details of class. */
    private static Logger logger = LoggerFactory
            .getLogger(UserController.class);

    /** The user service. */
    @Autowired
    private UserService userService;

    
    /** The obj. */
    @Autowired
    private CsvScheduler obj;
    
    

   
    /**
     * Handles the request to add a User.
     * 
     * @param detail
     *            the detail
     * @return the JSP page to show after adding user
     */
    @RequestMapping(value = "/user", method = RequestMethod.POST)
    @ResponseBody
    public int addUser(@RequestBody User detail) {
        userService.addUser(detail);
        return 1;

    }

    /**
     * Handles the request to page.
     * 
     * @param model
     *            the model
     * @return the JSP page of SearchMovie
     */
    @RequestMapping(value = "/", method = RequestMethod.GET)
    public String welcomePage(Model model) {
        logger.info("***********In CONTROLLER*******");
        model.addAttribute("showIdAttribute", new BookingShowId());
        obj.demoServiceMethod();
        return "SearchMovie";

    }

    /**
     * Handles the request to User Registration page.
     * 
     * @param model
     *            the model
     * @return the JSP page of User Registration
     */
    @RequestMapping(value = "/UserRegistration", method = RequestMethod.GET)
    public String addUserPage(ModelMap model) {

        return "UserRegistration";

    }

    /**
     * Edits the user.
     * 
     * @param user
     *            the user
     * @return the string
     */
    @RequestMapping(value = "/editUser", method = RequestMethod.POST)
    @ResponseBody
    public String editUser(User user) {

        userService.editUser(user);

        return "1";

    }

    /**
     * User details.
     * 
     * @return the list
     */
    @RequestMapping(value = "/details", method = RequestMethod.GET)
    @ResponseBody
    public List<User> userDetails() {

        logger.info("booking data for grid");
        Authentication auth = SecurityContextHolder.getContext()
                .getAuthentication();
        String currentUsername = auth.getName();
        User user = userService.getByUserEmail(currentUsername);
        List<User> users = new ArrayList<User>();
        users.add(user);
        return users;
    }

    
    
    /**
     * Useredit.
     * 
     * @param model
     *            the model
     * @return the string
     */
    @RequestMapping(value = "/EditUserDetails", method = RequestMethod.GET)
    public String useredit(ModelMap model) {

        return "EditUserDetails";

    }

    /**
     * Forgot password.
     * 
     * @param emailId
     *            the email id
     * @return the string
     */
    @RequestMapping(value = "/forgotPassword", method = RequestMethod.POST)
    @ResponseBody
    public String forgotPassword(@RequestBody String emailId) {

        logger.info("emailId== " + emailId);

        userService.sendUserMail(emailId);
        return "1";
    }

    
    
    /**
     * Handle exception.
     * 
     * @param e
     *            the e
     * @return the model and view
     */
    @ExceptionHandler(DAOException.class)
    public ModelAndView handleException(DAOException e) {
        ModelAndView modelAndView10 = new ModelAndView();
        modelAndView10.setViewName("error");
        modelAndView10.addObject("error_message", "Something went wrong, Server not Available");
        return modelAndView10;
    }

    /**
     * Handle exception.
     * 
     * @param e
     *            the e
     * @return the model and view
     */
    @ExceptionHandler(Exception.class)
    public ModelAndView handleException(Exception e) {
        ModelAndView modelAndView11 = new ModelAndView();
        modelAndView11.setViewName("error");
        modelAndView11.addObject("error_message",
                "Something went wrong, Server not Available");
        return modelAndView11;
    }

}
