package com.impetus.filmduniya.controller;


import java.io.IOException;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import com.impetus.filmduniya.dto.Movie;
import com.impetus.filmduniya.exception.DAOException;
import com.impetus.filmduniya.service.MovieService;



/**
 * Handles all the activities of Movie.
 * 
 * @author mayank.patidar
 * 
 */
@Controller
public class MovieController {

    /** logs the details of class. */
    private static Logger logger = LoggerFactory
            .getLogger(MovieController.class);

    /** reference of class movie service. */
    @Autowired
    private MovieService movieService;

    
    

    /**
     * Handles the request to add a Movie.
     * 
     * @param detail
     *            the detail
     * @return the JSP page to show after adding movie
     */
    @RequestMapping(value = "/saveMovie", method = RequestMethod.POST)
    @ResponseBody
    public int addMovie(@RequestBody Movie detail) {

        movieService.addMovie(detail);
        return 1;

    }

    /**
     * Manage movie.
     * 
     * @return the list
     */
    @RequestMapping(value = "/manageMovie", method = RequestMethod.GET)
    @ResponseBody
    public List<Movie> manageMovie() {

        List<Movie> movie = movieService.getAllMovies();

        return movie;

    }

    /**
     * Destroy movie.
     * 
     * @param id
     *            the id
     */
    @RequestMapping(value = "/manageMovie/{id}", method = RequestMethod.DELETE)
    public void destroyMovie(@PathVariable int id) {
        movieService.delete(id);

    }

    /**
     * Edits the movie.
     * 
     * @param movie
     *            the movie
     * @return the string
     */
    @RequestMapping(value = "/editmovie", method = RequestMethod.POST)
    @ResponseBody
    public String editMovie(Movie movie) {

        movieService.editMovie(movie);
        return "1";
    }

    /**
     * Handles the request to Add Movie page.
     * 
     * @param model
     *            the model
     * @return the JSP page of Movie Adder
     */
    @RequestMapping(value = "/MovieAdder", method = RequestMethod.GET)
    public String movieAdder(ModelMap model) {
        logger.info("In Movie Adder ");
        return "MovieAdder";
    }
    
    /**
     * Handles the request to view all movies.
     * 
     * @param theatreId
     *            the theatre id
     * @return the list of movies
     */
    @RequestMapping(value = "/movie", method = RequestMethod.GET)
    @ResponseBody
    public List<Movie> getAllMovies(int theatreId) {

        return movieService.getAllShowsByTheatreId(theatreId);
    }

    /**
     * Handles the request to view all movies.
     * 
     * @param model
     *            the model
     * @return the list of movies
     * @throws IOException
     *             Signals that an I/O exception has occurred.
     */

    @RequestMapping(value = "/allMovies", method = RequestMethod.GET)
    @ResponseBody
    public List<Movie> getAllMovies(Model model) throws IOException {

        return movieService.getAllMovies();
    }


    /**
     * Handle exception.
     * 
     * @param e
     *            the e
     * @return the model and view
     */
    @ExceptionHandler(DAOException.class)
    public ModelAndView handleException(DAOException e) { 
        ModelAndView modelAndView4 = new ModelAndView();
        modelAndView4.setViewName("error");
        modelAndView4.addObject("error_message", "Something went wrong, Server not Available");
        return modelAndView4;
    }

    /**
     * Handle exception.
     * 
     * @param e
     *            the e
     * @return the model and view
     */
    @ExceptionHandler(Exception.class)
    public ModelAndView handleException(Exception e) {
        ModelAndView modelAndView5 = new ModelAndView();
        modelAndView5.setViewName("error");
        modelAndView5.addObject("error_message",
                "Something went wrong, Server not Available");
        return modelAndView5;
    }

}
