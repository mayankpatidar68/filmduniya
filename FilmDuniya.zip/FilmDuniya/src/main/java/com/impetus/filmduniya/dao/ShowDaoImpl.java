package com.impetus.filmduniya.dao;

import java.util.Date;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.exception.ConstraintViolationException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.impetus.filmduniya.dto.Shows;
import com.impetus.filmduniya.exception.DAOException;


/**
 * Implementation of interface ShowDao.
 * 
 * @author mayank.patidar
 */
@Repository
public class ShowDaoImpl implements ShowDao {

    private static final int THREE = 3;

    /** logs the details of class. */
    private static Logger logger = LoggerFactory.getLogger(ShowDaoImpl.class);

    /** The session factory. */
    @Autowired
    private SessionFactory sessionFactory;

    /**
     * Sets the session factory.
     * 
     * @param sessionFactory
     *            the new session factory
     */
    public void setSessionFactory(SessionFactory sessionFactory) {

        this.sessionFactory = sessionFactory;
    }

    /*
     * @see com.impetus.filmduniya.dao.ShowDao#getAll()
     */
    /**
     * Gets the all shows by criteria.
     * 
     * @param cityId
     *            the city id
     * @param theatreId
     *            the theatre id
     * @param movieId
     *            the movie id
     * @param noOfSeats
     *            the no of seats
     * @param showSearchDate
     *            the show search date
     * @return the all shows by criteria
     */
    public List<Shows> getAllShowsByCriteria(int cityId, int theatreId,
            int movieId, int noOfSeats, Date showSearchDate) {
        try{
        Session session = this.sessionFactory.openSession();

        Query query = session
                .createQuery("from Shows shows where shows.theatre.theatreId= :theatreId AND shows.theatre.city.cityId= :cityId AND shows.movie.movieId= :movieId AND shows.availableSeats>= :noOfSeats AND shows.showDate= :showSearchDate");
        query.setInteger("cityId", cityId);
        query.setInteger("theatreId", theatreId);
        query.setInteger("movieId", movieId);
        query.setInteger("noOfSeats", noOfSeats);
        query.setDate("showSearchDate", showSearchDate);
        return query.list();

    }catch(HibernateException e)
    {
        logger.error("**************Error while getting  all shows for this date**************");
        throw new DAOException("Error while getting  all shows for this date",e);
    }
    
}


    /*
     * @see com.impetus.filmduniya.dao.ShowsDAO#getByshowId(java.lang.String)
     */
    /**
     * Gets the by show id.
     * 
     * @param showId
     *            the show id
     * @return the by show id
     */
    public Shows getByShowId(int showId) {
        Query query = this.sessionFactory.getCurrentSession().createQuery(
                "from Shows where showId= :showId ");
        query.setInteger("showId", showId);
        Shows show = (Shows) query.uniqueResult();

        return show;
    }

    /*
     * @see com.impetus.filmduniya.dao.DealDAO#updateAvailableSeats(com.impetus.
     * filmduniya .dao)
     */
    /**
     * Update available seats.
     * 
     * @param show
     *            the show
     * @return the int
     */
    public int updateAvailableSeats(Shows show) {
        this.sessionFactory.getCurrentSession().update(show);
        return 1;
    }

    /*
     * @see com.impetus.filmduniya.dao.ShowDao#addShow(com.impetus.filmduniya
     * .dto.Shows)
     */
    /**
     * Adds the show.
     * 
     * @param show
     *            the show
     */
    public void addShow(Shows show) {

        try {
            this.sessionFactory.getCurrentSession().save(show);

        } catch (ConstraintViolationException e) {

            logger.error("Error in Add Show", e);
        }

    }

    /*
     * @see com.impetus.filmduniya.dao.ShowDao#getAllShowss()
     */
    /**
     * Gets the all showss.
     * 
     * @return the all showss
     */
    public List<Shows> getAllShowss() {
        Query query = this.sessionFactory.getCurrentSession().createQuery(
                "FROM Shows");

        return query.list();
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.impetus.dao.ShowDao#updateShow(com.impetus.model.Shows)
     */
    /**
     * update.
     *
     * @param shows the shows
     */
    public void updateShow(Shows shows) {
        Session session = sessionFactory.getCurrentSession();
        session.saveOrUpdate(shows);

    }

    /*
     * (non-Javadoc)
     * 
     * @see com.impetus.dao.ShowDao#deleteShow(com.impetus.model.Shows)
     */
    /**
     * Delete.
     *
     * @param show the show
     */
    public void deleteShow(Shows show) {

        Session session = sessionFactory.getCurrentSession();

        session.delete(show);

    }

    /**
     * Upload schedule.
     */
    public void uploadSchedule() {
        Session session = sessionFactory.getCurrentSession();
        Query query = session
                .createSQLQuery("LOAD DATA LOCAL INFILE 'D:/CSV/schedule.csv' INTO TABLE temp FIELDS TERMINATED BY ',' ENCLOSED BY '\"' LINES TERMINATED BY '\n'");
        query.executeUpdate();
        query = session.createSQLQuery("CALL addSchedule()");
        query.executeUpdate();
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.impetus.omp.dao.ShowDao#addUpdateDeleteShow(java.lang.String,
     * int, java.lang.String, java.lang.String, int, int, java.lang.String)
     */
    /**
     * Adds the update delete show.
     *
     * @param endTime the end time
     * @param fare the fare
     * @param showDate the show date
     * @param startTime the start time
     * @param movieId the movie id
     * @param theatreId the theatre id
     * @param action the action
     * @param availableSeats the available seats
     * @param duration the duration
     * @param status the status
     */
    public void addUpdateDeleteShow(String[] time2Array, int fare, String showDate,
             int movieId, int theatreId,int availableSeats,  String status) {
        String startTime=time2Array[0];
        String endTime=time2Array[1];
        String action=time2Array[2];
        String duration=time2Array[THREE];
        Session session = sessionFactory.getCurrentSession();
        Query callStoredProcedure = session
                .createSQLQuery("CALL show_InserUpdateDelete(:update_type, :varAvailableSeats , :varDuration ,:varEndtime, :varFare, :varShowDate, :varStarttime, :varStatus, :varMovieId, :varTheaterId )");
        callStoredProcedure.setString("update_type", action);
        callStoredProcedure.setInteger("varAvailableSeats", availableSeats);
        callStoredProcedure.setString("varDuration", duration);
        callStoredProcedure.setString("varEndtime", endTime);
        callStoredProcedure.setInteger("varFare", fare);
        callStoredProcedure.setString("varShowDate", showDate);
        callStoredProcedure.setString("varStarttime", startTime);
        callStoredProcedure.setString("varStatus", status);
        callStoredProcedure.setInteger("varMovieId", movieId);
        callStoredProcedure.setInteger("varTheaterId", theatreId);
        callStoredProcedure.executeUpdate();

    }

    /*
     * (non-Javadoc)
     * 
     * @see com.impetus.dao.ShowDao#getfromShow(int, int, java.lang.String)
     */
    /**
     *
     * @param theatreID the theatre id
     * @param movieId the movie id
     * @param compareDate the compare date
     * @return the from show
     */
    public List<Shows> getfromShow(int theatreID, int movieId,
            String compareDate) {

        logger.info("in show dao impl to search for movieId where query criteria is "
                + theatreID);
        Session session = sessionFactory.getCurrentSession();

        Query query = session.createQuery("from Shows where theatreId = '"
                + theatreID + "' AND movieId ='" + movieId
                + "' And  showDate = '" + compareDate + "'");

        List<Shows> showList = query.list();

        for (Shows show : showList) {
            logger.info("getting tables from Show Start Time "
                    + show.getStartTime() + " show End Time "
                    + show.getEndTime());
            logger.info("getting tables from show "
                    + show.getMovie().getMovieName());
        }
        return showList;

    }

}
