package com.impetus.filmduniya.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.impetus.filmduniya.dao.TheatreDao;
import com.impetus.filmduniya.dto.Theatre;



/**
 * @author mayank.patidar
 *
 */
/**
 * The Class TheatreServiceImpl.
 */
@Service
@Transactional
public class TheatreServiceImpl implements TheatreService {

    /** The theatre dao. */
    @Autowired
    private TheatreDao theatreDao;

    /*
     * @see
     * com.impetus.filmduniya.service.TheatreService#getAllTheatresByCityId(int)
     */
    /**
     * Gets the all theatres by city id.
     *
     * @param cityId the city id
     * @return the all theatres by city id
     */
    public List<Theatre> getAllTheatresByCityId(int cityId) {

        return theatreDao.getAllTheatresByCityId(cityId);
    }

    /*
     * @see
     * com.impetus.filmduniya.service.TheatreService#addTheatre(com.impetus.
     * filmduniya.dto.Theatre)
     */
    /**
     * Adds the theatre.
     *
     * @param theatre the theatre
     */
    public void addTheatre(Theatre theatre) {

        theatreDao.addTheatre(theatre);
    }

    /*
     * @see com.impetus.filmduniya.service.TheatreService#getAllTheatres()
     */
    /**
     * Gets the all theatres.
     *
     * @return the all theatres
     */
    public List<Theatre> getAllTheatres() {
        return theatreDao.getAllTheatres();
    }

    /*
     * @see com.impetus.filmduniya.service.TheatreService#delete(int)
     */
    /**
     * Delete.
     *
     * @param theatreId the theatre id
     */
    public void delete(int theatreId) {

        theatreDao.delete(theatreId);

    }

}
