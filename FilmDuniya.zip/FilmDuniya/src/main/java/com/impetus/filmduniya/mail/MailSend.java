package com.impetus.filmduniya.mail;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.mail.MailSender;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.stereotype.Service;



/**
 * @author mayank.patidar
 */
/**
 * The Class Mail.
 */
@Service("mailService")
public class MailSend {

    /** The mail sender. */
    @Autowired
    /** The mail sender. */
    private MailSender mailSender;

    
    /**
     * Sets the mail sender.
     *
     * @param mailSender the new mail sender
     */
    public void setMailSender(MailSender mailSender) {
        this.mailSender = mailSender;
    }

    
    /**
     * Send mail.
     *
     * @param to the to
     * @param subject the subject
     * @param msg the msg
     */
    public void sendMail(String to, String subject, String msg) {

        SimpleMailMessage message = new SimpleMailMessage();

        message.setFrom("FilmDuniya01@gmail.com");
        message.setTo(to);
        message.setSubject(subject);
        message.setText(msg);
        mailSender.send(message);
    }

}
