package com.impetus.filmduniya.exception;


/**
 * handles Exception due to entity already existing.
 * 
 * @author mayank.patidar
 */
public class EntityAlreadyExistException extends RuntimeException {

    /** The message. */
    private String emessage;

    /** The cause. */
    private Throwable ecause;

    /* 
     * @see java.lang.Throwable#getMessage()
     */
    public String getMessage() {
        return emessage;
    }

    
    /**
     * Sets the message.
     *
     * @param message the new message
     */
    public void setMessage(String message) {
        this.emessage = message;
    }

    
    /* 
     * @see java.lang.Throwable#getCause()
     */
    public Throwable getCause() {
        return ecause;
    }

    
    /**
     * Sets the cause.
     *
     * @param cause the new cause
     */
    public void setCause(Throwable cause) {
        this.ecause = cause;
    }

    
    /**
     * Instantiates a new entity already exist exception.
     *
     * @param message the message
     * @param cause the cause
     */
    public EntityAlreadyExistException(String message, Throwable cause) {
        super(message, cause);
        this.emessage = message;
        this.ecause = cause;
    }

    
    /**
     * Instantiates a new entity already exist exception.
     */
    public EntityAlreadyExistException() {
        super();

    }

}
