package com.impetus.filmduniya.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.impetus.filmduniya.dao.BookingDao;
import com.impetus.filmduniya.dao.BookingHistoryDao;
import com.impetus.filmduniya.dao.SeatDao;
import com.impetus.filmduniya.dao.ShowDao;
import com.impetus.filmduniya.dao.TicketDao;
import com.impetus.filmduniya.dto.Booking;
import com.impetus.filmduniya.dto.Seat;
import com.impetus.filmduniya.dto.Shows;
import com.impetus.filmduniya.dto.Ticket;
import com.impetus.filmduniya.dto.User;
import com.impetus.filmduniya.mail.MailSend;


/**
 * The Class BookingHistoryServiceImpl.
 */
/**
 * @author mayank.patidar
 * 
 */
@Service
@Transactional
public class BookingHistoryServiceImpl implements BookingHistoryService {

    /** logs the details of class. */
    private static Logger logger = LoggerFactory
            .getLogger(BookingHistoryServiceImpl.class);

    /** The booking history dao. */
    @Autowired
    private BookingHistoryDao bookingHistoryDao;

    /** The ticket dao. */
    @Autowired
    private TicketDao ticketDao;

    /** The booking dao. */
    @Autowired
    private BookingDao bookingDao;

    /** The show dao. */
    @Autowired
    private ShowDao showDao;

    /** The seat dao. */
    @Autowired
    private SeatDao seatDao;

    /** The mail. */
    @Autowired
    private MailSend mail;
    
    /** The Constant Cancellation_Fee */
    static final int CANCELLATION_FEE=30;

    /*
     * @see
     * com.impetus.filmduniya.service.BookingHistoryService#getBookingHistory
     * (com.impetus.filmduniya.dto.User)
     */
    /**
     * Gets the booking history.
     *
     * @param user the user
     * @return the booking history
     */
    public List<Booking> getBookingHistory(User user) {
        return bookingHistoryDao.getBookingHistory(user);
    }

    /*
     * @see
     * com.impetus.filmduniya.service.BookingHistoryService#getTicketDetails
     * (int)
     */
    /**
     * Gets the ticket details.
     *
     * @param bookingId the booking id
     * @return the ticket details
     */
    public List<Ticket> getTicketDetails(int bookingId) {
        logger.info("booking id is {} ", bookingId);
        return bookingHistoryDao.getTicketDetails(bookingId);
    }

    /*
     * @see
     * com.impetus.filmduniya.service.BookingHistoryService#cancelTicket(int)
     */
    /**
     * Cancel ticket.
     *
     * @param cancelTicketId the cancel ticket id
     * @return the int
     */
    @Transactional(rollbackFor=Exception.class)
    public int cancelTicket(int cancelTicketId) {

        Ticket ticket = ticketDao.get(cancelTicketId);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date dateWithoutTime = null;
        try {
            dateWithoutTime = sdf.parse(sdf.format(new Date()));
        } catch (ParseException e) {

            logger.error("Date Parsing exception", e);
        }

        Date val = null;
        try {
            val = sdf.parse(ticket.getBooking().getShow().getShowDate());
        } catch (ParseException e) {

            logger.error("CancelTicket", e);
        }

        if (val.compareTo(dateWithoutTime) >= 0) {
            ticket.setStatus("Cancelled");
            ticketDao.update(ticket);
            Booking booking = bookingDao
                    .get(ticket.getBooking().getBookingId());
            booking.setNoOfTickets(booking.getNoOfTickets() - 1);
           booking.setTotalFare(booking.getTotalFare() - ticket.getBooking().getShow().getFare()+ CANCELLATION_FEE);
            bookingDao.saveBooking(booking);
            Shows shows = showDao.getByShowId(ticket.getBooking().getShow()
                    .getShowId());
            shows.setAvailableSeats(shows.getAvailableSeats() + 1);
            showDao.updateAvailableSeats(shows);
            Seat seat = seatDao.getSeatById(ticket.getSeat().getSeatId());
            seat.setStatus("Available");
            seatDao.updateStatus(seat);
            String emailId = ticket.getBooking().getUser().getEmailId();

            StringBuffer sb = new StringBuffer();

            String message;
            sb.append("Hello Sir/Madam, \n\n");
            sb.append("Thank You for using FILM-DUNIYA, its our pleasure to serve you."
                    + "\n\n Your ticket has been  cancelled  for Movie !!"
                    + "\n\n Movie Name \t\t:\t"
                    + ticket.getBooking().getShow().getMovie().getMovieName()
                    + "\n Theatre Name \t\t:\t"
                    + ticket.getBooking().getShow().getTheatre().getTheatreName()
                    + "\n show date \t\t:\t"
                    + ticket.getBooking().getShow().getShowDate()
                    + "\n show time \t\t:\t"
                    + ticket.getBooking().getShow().getStartTime()
                    + "\n Seat No \t\t:\t"
                    + ticket.getSeat().getSeatNo());
                    
            
            message = sb.toString();
            logger.info("Mail Message for cancellation " + message);
            if (val.compareTo(dateWithoutTime) >= 0) 
            {
            try{
            mail.sendMail(emailId, "Ticket cancelled", message);}
            catch(Exception e)
            {
                return 2;
            }

            logger.info(message);
            logger.debug(message);
            return 1;
             } }
        else {
            return 0;
        }
        return 0;
    }
    
}
