package com.impetus.filmduniya.dao;

import java.util.List;

import com.impetus.filmduniya.dto.Movie;




/**
 * The Interface MovieDao.
 *
 * @author mayank.patidar
 */
public interface MovieDao {

   
    /**
     * Adds the movie.
     *
     * @param movie the movie
     */
    void addMovie(Movie movie);

    /**
     * Gets the all movie by theatre id.
     *
     * @param theatreId the theatre id
     * @return the all movie by theatre id
     */
    List<Movie> getAllMovieByTheatreId(int theatreId);

    
    /**
     * Gets the all movies.
     *
     * @return the all movies
     */
    List<Movie> getAllMovies();

    
    /**
     * Delete.
     *
     * @param movieId the movie id
     */
    void delete(int movieId);

    /**
     * Gets the movie by id.
     *
     * @param mid the mid
     * @return the movie by id
     */
    Movie getMovieById(int mid);

    
    /**
     * Edits the movie.
     *
     * @param movie the movie
     */
    void editMovie(Movie movie);

    /**
     * Gets the by id.
     *
     * @param movieId the movie id
     * @return the by id
     */
    Movie getById(int movieId);

    
    /**
     * Gets the by name.
     *
     * @param movieName the movie name
     * @return the by name
     */
    Movie getByName(String movieName);
}
