package com.impetus.filmduniya.dao;

import java.util.List;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.impetus.filmduniya.dto.Booking;
import com.impetus.filmduniya.dto.Ticket;
import com.impetus.filmduniya.dto.User;
import com.impetus.filmduniya.exception.DAOException;


/**
 * Implementation of interface BookingHistoryDao.
 * 
 * @author mayank.patidar
 */
@Repository
public class BookingHistoryDaoImpl implements BookingHistoryDao {
    
    /** logs the details of class. */
    private static Logger logger = LoggerFactory
            .getLogger(BookingHistoryDaoImpl.class);
    

    /** The session factory. */
    @Autowired
    private SessionFactory sessionFactory;

    /**
     * Sets the session factory.
     * 
     * @param sessionFactory
     *            the new session factory
     */
    public void setSessionFactory(SessionFactory sessionFactory) {

        this.sessionFactory = sessionFactory;
    }

    /*
     * @see
     * com.impetus.filmduniya.dao.BookingHistoryDao#getBookingHistory(com.impetus
     * .filmduniya.dto.User)
     */
    /**
     * Gets the booking history.
     *
     * @param user the user
     * @return the booking history
     */
    public List<Booking> getBookingHistory(User user) {
try{
        Query query = this.sessionFactory.getCurrentSession().createQuery(
                "FROM Booking where user= :user");
        query.setEntity("user", user);
        return query.list();
    }
    catch(RuntimeException e)
    {
        logger.error("**************Error while getting Booking by bookingId**************");
        throw new DAOException("Error while getting Booking by bookingId",e);
    }
    
}




    /*
     * @see com.impetus.filmduniya.dao.BookingHistoryDao#getTicketDetails(int)
     */
    /**
     * Gets the ticket details.
     *
     * @param bookingId the booking id
     * @return the ticket details
     */
    public List<Ticket> getTicketDetails(int bookingId) {
try{
        Query query = this.sessionFactory.getCurrentSession().createQuery(
                "FROM Ticket where bookingId= :bookingId");
        query.setInteger("bookingId", bookingId);
        return query.list();
    }
    catch(RuntimeException e)
    {
        logger.error("**************Error while getting TicketDetails by bookingId**************");
        throw new DAOException("Error while getting TicketDetails by bookingId",e);
    }
    
    }
    }
