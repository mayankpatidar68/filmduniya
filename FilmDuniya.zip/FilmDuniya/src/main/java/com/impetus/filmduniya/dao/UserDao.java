package com.impetus.filmduniya.dao;

import java.util.List;

import com.impetus.filmduniya.dto.User;



/**
 * The Interface UserDao.
 *
 * @author mayank.patidar
 */

public interface UserDao {

    
    /**
     * Adds the user.
     *
     * @param user the user
     */
    void addUser(User user);

    /**
     * Gets the by user email.
     *
     * @param currentUserEmail the current user email
     * @return the by user email
     */
    User getByUserEmail(String currentUserEmail);

    /**
     * Gets the all users.
     *
     * @return the all users
     */
    List<User> getAllUsers();

    /**
     * Edits the user.
     *
     * @param user the user
     */
    void editUser(User user);

   
    /**
     * Gets the user details.
     *
     * @param emailId the email id
     * @return the user details
     */
    User getUserDetails(String emailId);

   
    /**
     * Gets the user details.
     *
     * @param user the user
     * @return the user details
     */
    List<User> getUserDetails(User user);

    /**
     * Gets the user by id.
     *
     * @param userId the user id
     * @return the user by id
     */
    User getUserById(int userId);
    
  
}
