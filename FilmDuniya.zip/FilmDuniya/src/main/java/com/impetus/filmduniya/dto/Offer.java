package com.impetus.filmduniya.dto;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * @author mayank.patidar
 *
 */
/**
 * The Class Offer.
 */
@Entity
@Table(name = "OFFER")
public class Offer {

    /** The offer id. */
    @Id
    @Column(name = "OFFERID")
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int offerId;

    /** The offer code. */
    @Column(name = "OFFERCODE")
    private String offerCode;

    /** The description. */
    @Column(name = "DESCRIPTION")
    private String description;

    /** The start date. */
    @Temporal(TemporalType.DATE)
    @Column(name = "STARTDATE")
    private Date startDate;

    /** The end date. */
    @Temporal(TemporalType.DATE)
    @Column(name = "ENDDATE")
    private Date endDate;

    /** The type. */
    @Column(name = "TYPE")
    private String type;

    /** The discount. */
    @Column(name = "DISCOUNT")
    private Integer discount;

    /** The show. */
    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "OFFER_SHOW", joinColumns = { @JoinColumn(name = "offerId") }, inverseJoinColumns = { @JoinColumn(name = "showId") })
    private Set<Shows> show = new HashSet<Shows>();

    /**
     * Gets the offer id.
     * 
     * @return the offer id
     */
    public int getOfferId() {
        return offerId;
    }

    /**
     * Sets the offer id.
     * 
     * @param offerId
     *            the new offer id
     */
    public void setOfferId(int offerId) {
        this.offerId = offerId;
    }

    /**
     * Gets the offer code.
     * 
     * @return the offer code
     */
    public String getOfferCode() {
        return offerCode;
    }

    /**
     * Sets the offer code.
     * 
     * @param offerCode
     *            the new offer code
     */
    public void setOfferCode(String offerCode) {
        this.offerCode = offerCode;
    }

    /**
     * Gets the description.
     * 
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the description.
     * 
     * @param description
     *            the new description
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * Gets the start date.
     * 
     * @return the start date
     */
    public Date getStartDate() {
        return startDate;
    }

    /**
     * Sets the start date.
     * 
     * @param startDate
     *            the new start date
     */
    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    /**
     * Gets the end date.
     * 
     * @return the end date
     */
    public Date getEndDate() {
        return endDate;
    }

    /**
     * Sets the end date.
     * 
     * @param endDate
     *            the new end date
     */
    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    /**
     * Gets the type.
     * 
     * @return the type
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the type.
     * 
     * @param type
     *            the new type
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * Gets the discount.
     * 
     * @return the discount
     */
    public Integer getDiscount() {
        return discount;
    }

    /**
     * Sets the discount.
     * 
     * @param discount
     *            the new discount
     */
    public void setDiscount(Integer discount) {
        this.discount = discount;
    }

    /**
     * Gets the show.
     * 
     * @return the show
     */
    public Set<Shows> getShow() {
        return show;
    }

    /**
     * Sets the show.
     * 
     * @param show
     *            the new show
     */
    public void setShow(Set<Shows> show) {
        this.show = show;
    }

}
