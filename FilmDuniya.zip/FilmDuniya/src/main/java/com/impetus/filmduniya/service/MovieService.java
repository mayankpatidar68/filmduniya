package com.impetus.filmduniya.service;

import java.util.List;

import com.impetus.filmduniya.dto.Movie;



/**
 * @author mayank.patidar
 */
/**
 * The Interface MovieService.
 */
public interface MovieService {

   
    /**
     * Adds the movie.
     *
     * @param movie the movie
     */
    void addMovie(Movie movie);

    
    /**
     * Gets the all shows by theatre id.
     *
     * @param theatreId the theatre id
     * @return the all shows by theatre id
     */
    List<Movie> getAllShowsByTheatreId(int theatreId);

   
    /**
     * Gets the all movies.
     *
     * @return the all movies
     */
    List<Movie> getAllMovies();

    
     /**
      * Gets the movie by id.
      *
      * @param mid the mid
      * @return the movie by id
      */
     Movie getMovieById(int mid);

    
    /**
     * Delete.
     *
     * @param movieId the movie id
     */
    void delete(int movieId);

    
    /**
     * Edits the movie.
     *
     * @param movie the movie
     */
    void editMovie(Movie movie);

    
    
    /**
     * Gets the by name.
     *
     * @param movieName the movie name
     * @return the by name
     */
    Movie getByName(String movieName);

}
