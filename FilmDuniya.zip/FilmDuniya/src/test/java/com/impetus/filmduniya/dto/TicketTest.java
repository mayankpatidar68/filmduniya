package com.impetus.filmduniya.dto;



import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.impetus.filmduniya.dto.Ticket;
import com.opensymphony.xwork2.XWorkTestCase;


// TODO: Auto-generated Javadoc
/**
 * The Class TicketTest.
 */
public class TicketTest extends XWorkTestCase {

    /** The Ticket. */
	Ticket ticket;

	/** The booking. */
	Booking booking;
	
	/** The seat. */
	Seat seat;
    /*
     * (non-Javadoc)
     * 
     * @see com.opensymphony.xwork2.XWorkTestCase#setUp()
     */

    
    @Before
    public void setUp() {
    	
    	ticket = new Ticket();
        
    }

    /**
     * Test getter setter. 
     */
    @Test
    public void testGetterSetter() {
    	
    	ticket.setTicketId(1);
        int actual = ticket.getTicketId();
        Assert.assertEquals(1, actual);
       
       
        ticket.setBooking(booking);
        Booking actual2=ticket.getBooking();
        Assert.assertEquals(booking, actual2);
       
       
        ticket.setSeat(seat);
        Seat actual4=ticket.getSeat();
        Assert.assertEquals(seat, actual4);
    

        ticket.setStatus("Running");
        String actual5=ticket.getStatus();
        Assert.assertEquals("Running", actual5);
        
       
    }
}
