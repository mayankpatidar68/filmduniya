package com.impetus.filmduniya.dao;

import java.util.List;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import com.impetus.filmduniya.dto.City;
import com.impetus.filmduniya.dto.Theatre;






// TODO: Auto-generated Javadoc
/**
 * The Class TheatreDaoTest.
 */
@Transactional
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/Dispatcher-servlet.xml" })
public class TheatreDaoTest {
	
	/** The theatre dao. */
	@Autowired
	private TheatreDaoImpl theatreDao;
	
	/** The theatre. */
	Theatre theatre;
	
	/** The theatre. */
	Theatre theatre1;
	
	/** The city. */
	City city;
	
	/**
     * Sets the up.
     *
     * @throws Exception the exception
     */
    @Before
    public void setUp() throws Exception {
        
        theatre = new Theatre();
        theatre.setTheatreId(12);
        
        theatre1 = new Theatre();
        theatre1.setNoOfColumns(15);
        theatre1.setNoOfRows(10);
        theatre1.setTheatreId(111);
        theatre1.setTheatreName("PVR");
        theatre1.setCity(city);
        theatre1.setStatus("Active");
    
    }
	
	/**
	 * View theatre test.
	 */
	@Test
	public void viewTheatreTest() {
		try {
			List<Theatre> theatreList = theatreDao.getAllTheatresByCityId(4);
			Assert.assertNotNull(theatreList);
		} catch (Exception e) {
			Assert.assertTrue(false);
		}
	}
	
	/**
	 * Test add Theatre.
	 */
	@Test
	@Transactional
	public void testAddTheatre(){

		try{
			theatreDao.addTheatre(theatre);
		}catch(Exception e){
			Assert.assertTrue(false);
		}		
			}
	
	/**
	 * Gets the all theatres test.
	 *
	 * @return the all theatres test
	 */
	@Test
	public void getAllTheatresTest() {
		try {
			List<Theatre> theatreList = theatreDao.getAllTheatres();
			Assert.assertNotNull(theatreList);
		} catch (Exception e) {
			Assert.assertTrue(false);
		}
	}
	

		
	/**
	 * Delete.
	 */
	@Test
	@Transactional
    public void delete(){
		try{
		    theatre.setTheatreId(7);
			 theatreDao.delete(7);
		}catch(Exception e){
			Assert.assertTrue(true);
		}
	}
}
