package com.impetus.filmduniya.dto;

import java.util.Date;


import java.util.Set;



import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.impetus.filmduniya.dto.Offer;
import com.opensymphony.xwork2.XWorkTestCase;



// TODO: Auto-generated Javadoc
/**
 * The Class OfferTest.
 */
public class OfferTest extends XWorkTestCase {

    /** The Offer. */
	Offer offer;
   
	/** The show. */
	Set<Shows> show;
    /*
     * (non-Javadoc)
     * 
     * @see com.opensymphony.xwork2.XWorkTestCase#setUp()
     */

    
    @Before
    public void setUp() {
    	
    	offer = new Offer();
        
    }

    /**
     * Test getter setter. 
     */
    @Test
    public void testGetterSetter() {
    	Date date= new Date(2014-10-10);
    	
    	offer.setOfferId(1);
        int actual = offer.getOfferId();
        Assert.assertEquals(1, actual);
       
       
        offer.setOfferCode("Co1");
       String actual2=offer.getOfferCode();
        Assert.assertEquals("Co1", actual2);
       
        offer.setDescription("bkajfbkj");
        String actual3=offer.getDescription();
         Assert.assertEquals("bkajfbkj", actual3);
        
         offer.setShow(show);
         Set<Shows> actual4=offer.getShow();
          Assert.assertEquals(show, actual4);
         
         offer.setStartDate(date);
        Date actual5=offer.getStartDate();
         Assert.assertEquals(date, actual5);
         
         offer.setType("Good");
         String actual6=offer.getType();
          Assert.assertEquals("Good", actual6);
        
        offer.setDiscount(152);
        int actual7=offer.getDiscount();
        Assert.assertEquals(152, actual7);
        
        offer.setEndDate(date);
        Date actual8=offer.getEndDate();
        Assert.assertEquals(date, actual8);
    }

}
