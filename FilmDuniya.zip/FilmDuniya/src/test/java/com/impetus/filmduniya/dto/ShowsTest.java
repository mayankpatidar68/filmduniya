package com.impetus.filmduniya.dto;



import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.impetus.filmduniya.dto.Shows;
import com.opensymphony.xwork2.XWorkTestCase;



// TODO: Auto-generated Javadoc
/**
 * The Class ShowsTest.
 */
public class ShowsTest  extends XWorkTestCase {

    /** The Shows. */
	Shows shows;

	/** The movie. */
	Movie movie;
	
	/** The theatre. */
	Theatre theatre;
	
    /*
     * (non-Javadoc)
     * 
     * @see com.opensymphony.xwork2.XWorkTestCase#setUp()
     */

    
    @Before
    public void setUp() {
    	
    	shows = new Shows();
        
    }

    /**
     * Test getter setter. 
     */
    @Test
    public void testGetterSetter() {
    	
    	shows.setShowId(1);
        int actual = shows.getShowId();
        Assert.assertEquals(1, actual);
       
       
        shows.setShowDate("2014:12:10");
        String actual2=shows.getShowDate();
        Assert.assertEquals("2014:12:10", actual2);
       
        shows.setEndTime("03:00:00");
        String actual3=shows.getEndTime();
        Assert.assertEquals("03:00:00", actual3);
        
        shows.setStartTime("03:00:00");
        String actual4=shows.getStartTime();
        Assert.assertEquals("03:00:00", actual4);
        
        shows.setDuration("3");
        String actual5=shows.getDuration();
        Assert.assertEquals("3", actual5);
        
        shows.setFare(450);
        int actual6=shows.getFare();
        Assert.assertEquals(450, actual6);
        
        shows.setStatus("ABC");
        String actual7=shows.getStatus();
        Assert.assertEquals("ABC", actual7);
        
        shows.setAvailableSeats(152);
        int actual8=shows.getAvailableSeats();
        Assert.assertEquals(152, actual8);
        
        shows.setMovie(movie);
        Movie actual9=shows.getMovie();
        Assert.assertEquals(movie, actual9);
        
        shows.setTheatre(theatre);
        Theatre actual10=shows.getTheatre();
        Assert.assertEquals(theatre, actual10);
    }


}
