package com.impetus.filmduniya.vo;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;



/**
 * The Class AdminControllerTest.
 */
@Transactional
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/Dispatcher-servlet.xml" })
public class BookingShowIdTest {

	
	/** The admin controller. */
	BookingShowId bookingShowId;

	/**
	 * Sets the up.
	 *
	 * @throws Exception the exception
	 */
	@Before
	public void setUp() throws Exception {
		bookingShowId=new BookingShowId();
	}

	/**
	 * Test Add Movie.
	 */
	@Test
		public void testCancelMovie() {
		
			bookingShowId.setShowsId(1);
			bookingShowId.getShowsId();
		
	}
	
	/**
     * Test Add Movie.
     */
    @Test
        public void testnoOfSeats() {
        
            bookingShowId.setNoOfSeats(1);
            bookingShowId.getNoOfSeats();
        
    }
}
