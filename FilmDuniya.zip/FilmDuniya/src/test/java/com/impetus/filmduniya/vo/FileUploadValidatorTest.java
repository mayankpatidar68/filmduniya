package com.impetus.filmduniya.vo;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.Errors;


// TODO: Auto-generated Javadoc
/**
 * The Class AdminControllerTest.
 */
@Transactional
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/Dispatcher-servlet.xml" })
public class FileUploadValidatorTest {

	
	/** The admin controller. */
	FileUploadValidator fileUploadValidator;

	/**
	 * Sets the up.
	 *
	 * @throws Exception the exception
	 */
	@Before
	public void setUp() throws Exception {
		fileUploadValidator=new FileUploadValidator();
	}

	/**
	 * Test Add Movie.
	 */
	@Test
		public void testFileUploadValidator() {
		
		Errors errors = null;
        Object target = null;
        fileUploadValidator.validate(target, errors);
		Object uploadOffer = null;
        fileUploadValidator.validateOffers(uploadOffer, errors);
		
	}
}
