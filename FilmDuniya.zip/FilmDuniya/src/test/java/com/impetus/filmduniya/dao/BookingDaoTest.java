package com.impetus.filmduniya.dao;


import java.util.Date;
import java.util.List;





import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import com.impetus.filmduniya.dto.Booking;
import com.impetus.filmduniya.dto.Movie;


/**
 * The Class BookingDaoTest.
 */
@Transactional
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/Dispatcher-servlet.xml" })
public class BookingDaoTest {
	
	/** The booking dao. */
	@Autowired
	private BookingDao bookingDao ;
	
	
	/** The booking. */
	Booking booking;
	
	/** The movie. */
	Movie movie;
	
	
	/**
	 * Test Book .
	 */
	@Test
	@Transactional
	public void testSaveBooking(){

		try{
		booking = bookingDao.saveBooking(booking);
		Assert.assertNotNull(booking);
		}catch(Exception e){
			Assert.assertTrue(true);
		}		
			}
	
	/**
	 * Test get.
	 */
	@Test
	public void testGet() {
		
			booking = bookingDao.get(1);
			
		
	}
	
	
	/**
	 * Send show mail test.
	 */
	@Test
	public void sendShowMailTest() {
	    try{
			List<Booking> sendmail=bookingDao.sendScheduleMail();
			Assert.assertNotNull(sendmail);
	    }catch(Exception e){
            Assert.assertTrue(true);
        }
    }
	
	
	/**
	 * Gets the booking bymovie date.
	 *
	 * @return the booking bymovie date
	 */
	@Test
	@Transactional
	public void getbookingBymovieDate(){
		try{
		  
			Date showDate=null;
            int movieId=1;
            List<Booking> getBookingByMovieDate = bookingDao.getBookingByMovieDate(movieId, showDate);
			Assert.assertNotNull(getBookingByMovieDate);
		}catch(Exception e){
			Assert.assertTrue(false);
		}
	}

    
	
}
