package com.impetus.filmduniya.exception;

import org.junit.Assert;

import org.junit.Test;

import com.opensymphony.xwork2.XWorkTestCase;




// TODO: Auto-generated Javadoc
/**
 * The Class EntityAlreadyExistExceptionTest.
 */
public class EntityAlreadyExistExceptionTest extends XWorkTestCase {

    /** The entity already exist exception. */
    EntityAlreadyExistException entityAlreadyExistException = new EntityAlreadyExistException();
    
    /**
     * Test getter setter message.
     */
    @Test
    public void testGetterSetterMessage() {
        entityAlreadyExistException.setMessage("dgdfgfg");
        String actual = entityAlreadyExistException.getMessage();
        Assert.assertEquals("dgdfgfg", actual);
    } 
   

    /**
     * Test getter setter cause.
     */
    @Test
    public void testGetterSetterCause() {
        entityAlreadyExistException.setCause(null);
        Throwable actual = entityAlreadyExistException.getCause();
        Assert.assertEquals(null, actual);
    }


}
