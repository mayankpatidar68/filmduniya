package com.impetus.filmduniya.service;

import java.util.List;


import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.impetus.filmduniya.dao.SeatDao;
import com.impetus.filmduniya.dto.Seat;
import com.impetus.filmduniya.dto.Shows;


/**
 * The Class SeatServiceImplTest.
 */
@Transactional
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/Dispatcher-servlet.xml" })
public class SeatServiceImplTest {
	
	/** The seat service. */
	@Autowired
	SeatService seatService ;
	
	/** The seat dao. */
	@Autowired
	SeatDao seatDao;

	/** The show. */
	Shows show;
	
	/** The seat. */
	Seat seat;
	
	/**
	 * Sets the up.
	 *
	 * @throws Exception the exception
	 */
	@Before
	public void setUp() throws Exception {
		show = new Shows();
		show.setShowId(1);
		
		seat = new Seat();
		seat.setSeatId(20);
		
	}

	/**
	 * Test get seat.
	 */
	@Test
	public void testGetSeat() {
		try
		{
			Seat seat=seatService.getSeat(show, 5);
		Assert.assertNotNull(seat);
		}catch(Exception e)
		{
			Assert.assertTrue(false);
		}
	}

	/**
	 * Test update status.
	 */
	@Test
	public void testUpdateStatus() {
		try
		{
			seat.setStatus("Cancelled");
			seatService.updateStatus(seat);
		Assert.assertEquals("Cancelled",seatDao.getSeatById(20).getStatus());
		}catch(Exception e)
		{
			Assert.assertTrue(false);
		}
	}

	/**
	 * Test get reserved seats.
	 */
	@Test
	public void testGetReservedSeats() {
		try
		{
			List<Seat> seat=seatService.getReservedSeats(1);
		Assert.assertNotNull(seat);
		}catch(Exception e)
		{
			Assert.assertTrue(false);
		}
	}

}
