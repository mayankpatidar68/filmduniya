package com.impetus.filmduniya.pdf;

import java.util.Map;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.itextpdf.text.Document;
import com.itextpdf.text.pdf.PdfWriter;


// TODO: Auto-generated Javadoc
/**
 * The Class AdminControllerTest.
 */
@Transactional
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/Dispatcher-servlet.xml" })
public class PDFGenerateTest {


	
	/** The admin controller. */

 private PdfGenerator pdfGenerator;
	

	/**
	 * Sets the up.
	 *
	 * @throws Exception the exception
	 */
	@Before
	public void setUp() throws Exception {
		pdfGenerator =new PdfGenerator();
	}


	/**
	 * Handle exception test.
	 */
	@Test
	public void PdfTest() {
		
		
		try {
			javax.servlet.http.HttpServletRequest request = null;
			javax.servlet.http.HttpServletResponse response = null;
			PdfWriter writer = null;
			Document document = null;
			Map<String, Object> model = null;
			pdfGenerator.buildPdfDocument(model, document, writer,request,response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
