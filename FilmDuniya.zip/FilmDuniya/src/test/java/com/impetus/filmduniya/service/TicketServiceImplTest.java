package com.impetus.filmduniya.service;


import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import com.impetus.filmduniya.dto.Booking;
import com.impetus.filmduniya.dto.City;
import com.impetus.filmduniya.dto.Movie;
import com.impetus.filmduniya.dto.Seat;
import com.impetus.filmduniya.dto.Shows;
import com.impetus.filmduniya.dto.Theatre;
import com.impetus.filmduniya.dto.Ticket;
import com.impetus.filmduniya.dto.User;


/**
 * The Class TicketServiceImplTest.
 */
@Transactional
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/Dispatcher-servlet.xml" })
public class TicketServiceImplTest {
	
	/** The ticket service. */
	@Autowired
	TicketService ticketService;
	
	/** The ticket. */
	Ticket ticket;
	
	/** The booking. */
	Booking booking;
	
	/** The user2. */
	User user2;
	
	/** The show. */
	Shows show;
	
	/** The seat. */
	Seat seat;
	
	/** The movie. */
	Movie movie;
	
	/** The theatre. */
	Theatre theatre;
	
	/** The city. */
	City city;

	/**
	 * Sets the up.
	 *
	 * @throws Exception the exception
	 */
	@Before
	public void setUp() throws Exception {
		
		city = new City();
		city.setCityId(111);
		city.setCityName("Coimbatore");
		
		movie = new Movie();
		movie.setDescription("Rating- 4* Mush Watch");
		movie.setDuration("3Hrs");
		movie.setMovieId(111);
		movie.setMovieName("Ram Leela");
		movie.setReleaseDate("2014-05-06");
		movie.setStatus("Active");
		
		theatre = new Theatre();
		theatre.setCity(city);
		theatre.setNoOfColumns(10);
		theatre.setNoOfRows(10);
		theatre.setStatus("Active");
		
		
		show = new Shows();
		show.setAvailableSeats(10);
		show.setDuration("3Hrs");
		show.setEndTime("2014-05-06");
		show.setFare(200);
		show.setMovie(movie);
		show.setShowDate("2014-05-06");
		show.setShowId(111);
		show.setStartTime("2014-05-06");
		show.setStatus("Active");
		show.setTheatre(theatre);
		
		user2 = new User();
		user2.setUserId(111);
		user2.setFirstName("mayank");
		user2.setPassword("mayank");
		user2.setContactNumber("0123456789");
		user2.setLastName("patidar");
	
		user2.setEmailId("avani.mittalMam@gmail.com");
		
		
		booking = new Booking();
		booking.setBookingId(0);
		booking.setActualFare(500);
		booking.setNoOfTickets(3);
		booking.setOffer(null);
		booking.setShow(show);
		booking.setTotalFare(500);
		booking.setUser(user2);
		
		seat = new Seat();
		seat.setSeatId(11);
		seat.setSeatNo("11");
		seat.setShows(show);
		seat.setStatus("Available");
		
		ticket = new Ticket();
		ticket.setTicketId(41);
		ticket.setBooking(booking);
		ticket.setSeat(seat);
		ticket.setStatus("Booked");
	}
	

	/**
	 * Test save.
	 */
	@Test
	public void testSave() {
		try
		{
		    ticket.setTicketId(41);
		ticketService.save(ticket);
		}
		catch(Exception e)
		{
			Assert.assertTrue(false);
		}
		
	}
}
