package com.impetus.filmduniya.vo;
import java.util.List;


import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;


// TODO: Auto-generated Javadoc
/**
 * The Class AdminControllerTest.
 */
@Transactional
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/Dispatcher-servlet.xml" })
public class FileUploadFormTest {

	
	/** The admin controller. */
	FileUploadForm fileUploadForm;

	
	
	/**
	 * Sets the up.
	 *
	 * @throws Exception the exception
	 */
	@Before
	public void setUp() throws Exception {
		fileUploadForm=new FileUploadForm();
	}

	/**
	 * Test Add Movie.
	 */
	@Test
		public void testFileUploadForm() {
		
		
		String fileName = "Shows.csv";
		byte[] content = null ;
		MockMultipartFile file = new MockMultipartFile("fileData",fileName, "text/plain",content);
		fileUploadForm.getFile();
		fileUploadForm.setFile(file);
		
		fileUploadForm.getFiles();
		
		List<MultipartFile> files =null;
		fileUploadForm.setFiles(files);
		
		
	}
}
