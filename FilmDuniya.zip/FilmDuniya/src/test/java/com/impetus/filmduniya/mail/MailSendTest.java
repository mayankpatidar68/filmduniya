package com.impetus.filmduniya.mail;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.mail.MailException;
import org.springframework.mail.MailSender;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;



/**
 * The Class AdminControllerTest.
 */
@Transactional
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/Dispatcher-servlet.xml" })
public class MailSendTest {


	/** The admin controller. */

	MailSend mailSend;
	
	/**
	 * Sets the up.
	 *
	 * @throws Exception the exception
	 */
	@Before
	public void setUp() throws Exception {

		mailSend =new MailSend();
	}


	/**
	 * Handle exception test.
	 */
	@Test
	public void mailTest() {
		MailSender mailSender=new MailSender(){

			public void send(SimpleMailMessage arg0) throws MailException {
				

			}

			public void send(SimpleMailMessage[] arg0) throws MailException {
				

			}
		};
		mailSend.setMailSender(mailSender);
		mailSend.sendMail("mayank.patidar@impetus.co.in", "Hello !!", "Hi, Thanks");
	}

}
