package com.impetus.filmduniya.service;


import java.util.List;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import com.impetus.filmduniya.dao.MovieDao;
import com.impetus.filmduniya.dto.Movie;



/**
 * The Class MovieServiceImplTest.
 */
@Transactional
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/Dispatcher-servlet.xml" })
public class MovieServiceImplTest {
	
	/** The movie service. */
	@Autowired
	MovieService movieService ;
	
	/** The movie dao. */
	@Autowired
    MovieDao movieDao ;
	
	/** The movie. */
	Movie movie;
	
	/** The movie1. */
	Movie movie1;
	
	/**
	 * Sets the up.
	 *
	 * @throws Exception the exception
	 */
	@Before
	public void setUp() throws Exception {
		
		movie = new Movie();
		movie.setMovieId(12);
		
		movie1 = new Movie();
		movie1.setDescription("Rating- 4* Mush Watch");
		movie1.setDuration("3Hrs");
		movie1.setMovieId(3);
		movie1.setMovieName("Mast");
		movie1.setReleaseDate("showSearchDate");
		movie1.setStatus("Active");
		
	}

	/**
	 * Test add movie.
	 */
	@Test
	public void testAddMovie() {
		try
		{
			movieService.addMovie(movie1);
		}catch(Exception e)
		{
			Assert.assertTrue(false);
		}
	}

	/**
	 * Test get all shows by theatre id.
	 */
	@Test
	public void testGetAllShowsByTheatreId() {
		try
		{
			List<Movie> movies = movieService.getAllShowsByTheatreId(1);
			Assert.assertNotNull(movies);
		}catch(Exception e)
		{
			Assert.assertTrue(false);
		}
	}

	/**
	 * Test get movie details.
	 */
	@Test
	public void testGetMovieDetails() {
		try
		{
			List<Movie> movies = movieService.getAllMovies();
			Assert.assertNotNull(movies);
		}catch(Exception e)
		{
			Assert.assertTrue(false);
		}
	}

	/**
	 * Test get movie.
	 */
	@Test
	public void testGetMovie() {
		try
		{
			Movie movie = movieService.getMovieById(2);
		Object excepted= movieDao.getMovieById(2);
			Assert.assertEquals(excepted, movie);
		}catch(Exception e)
		{
			Assert.assertTrue(false);
		}
	}

	/**
	 * Test update.
	 */
	@Test
	public void testUpdate() {
		try
		{
			movie.setMovieName("Mast");
			movieService.editMovie(movie);
		}catch(Exception e)
		{
			Assert.assertTrue(true);
		}
	}

	/**
	 * Test delete.
	 */
	@Test
	public void testDelete() {
		try
		{
			movieService.delete(8);
		}catch(Exception e)
		{
			Assert.assertTrue(true);
		}
	}

	/**
	 * Test get all movies.
	 */
	@Test
	public void testGetAllMovies() {
		try
		{
			List<Movie> movies = movieService.getAllMovies();
			Assert.assertNotNull(movies);
		}catch(Exception e)
		{
			Assert.assertTrue(false);
		}
	}
	
	/**
	 * Test get movie by name.
	 */
	@Test
    public void testGetMovieByName() {
        try
        {
           movie.setMovieName("Mast");
            movieService.getByName("Mast");
        }catch(Exception e)
        {
            Assert.assertTrue(false);
        }
    }
}
