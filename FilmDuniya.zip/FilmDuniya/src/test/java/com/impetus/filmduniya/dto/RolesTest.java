package com.impetus.filmduniya.dto;



import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.impetus.filmduniya.dto.Roles;
import com.opensymphony.xwork2.XWorkTestCase;



// TODO: Auto-generated Javadoc
/**
 * The Class RolesTest.
 */
public class RolesTest extends XWorkTestCase {

    /** The Roles. */
	Roles roles;

    /*
     * (non-Javadoc)
     * 
     * @see com.opensymphony.xwork2.XWorkTestCase#setUp()
     */

    
    @Before
    public void setUp() {
    	
    	roles = new Roles();
        
    }

    /**
     * Test getter setter. 
     */
    @Test
    public void testGetterSetter() {
    	
    	roles.setRoleId(1);
        int actual = roles.getRoleId();
        Assert.assertEquals(1, actual);
       
       
        roles.setRole("Admin");
        String actual2=roles.getRole();
        Assert.assertEquals("Admin", actual2);
       
        
    }
}
