package com.impetus.filmduniya.dao;



import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import com.impetus.filmduniya.dto.User;
import com.opensymphony.xwork2.interceptor.annotations.Before;





/**
 * The Class UserDaoTest.
 */

@Transactional
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/Dispatcher-servlet.xml" })
public class UserDaoTest {



	/** The user dao. */
	@Autowired
	private UserDao userDao ;

   /** The user. */
   User user;
    
    /** The user1. */
    User user1;
    
    /** The user2. */
    User user2;

	/**
     * Sets the up.
     *
     * @throws Exception the exception
     */
    @Before
    public void setUp() throws Exception {
        user1 = new User();
        user1.setUserId(2);
        user1.setFirstName("jayesh");
        user1.setPassword("9993965444");
        user1.setContactNumber("99939654");
        user1.setLastName("patidar");
        
        user1.setEmailId("jayeshptd@gmail.com");
        
        user2 = new User();
        user2.setUserId(1);
        user2.setFirstName("mayank");
        user2.setPassword("9893989368");
        user2.setContactNumber("98939893");
        user2.setLastName("patidar");
    
        user2.setEmailId("mayankpith@gmail.com");
    }


	/**
	 * Test add User.
	 */

	@Test
	@Transactional
	public void testaddUser(){
       try{
		//user.setUserId(2);
			userDao.addUser(user2);
			
       } catch (Exception e) {
			Assert.assertTrue(true);
		}
	}



	/**
	 * Test get by email id.
	 */
	@Test
	@Transactional
	public void testgetByUserEmail(){

		User userAct = userDao.getByUserEmail("jayeshptd@gmail.com");
		Assert.assertEquals("jayeshptd@gmail.com", userAct.getEmailId());

	}

	/**
	 * Test get by id.
	 */
	@Test
	@Transactional
	public void testGetById() {


		User userAct = userDao.getUserById(2);
		Assert.assertEquals(2, userAct.getUserId());

	}


	/**
	 * Gets the user details test.
	 *
	 * @return the user details test
	 */
	@Test
	@Transactional
	public void getUserDetailsTest() {
		try {

			List<User> users=userDao.getUserDetails(user);
			Assert.assertEquals(null, users);
		} catch (Exception e) {
			Assert.assertTrue(true);
		}
	}


	/**
	 * Gets the all user test.
	 *
	 * @return the all user test
	 */
	@Test
	@Transactional
	public void getAllUserTest() {
		try {

			List<User> userList=userDao.getAllUsers();
			
		} catch (Exception e) {
			
			Assert.assertTrue(false);
		}
	}
	
	/**
	 * Gets the user details by email test.
	 *
	 * @return the user details by email test
	 */
	@Test
    @Transactional
    public void getUserDetailsByEmailTest() {
        try {
            String emailId ="mayankpith@gmail.com";;
            userDao.getUserDetails(emailId);
        } catch (Exception e) {
            
            Assert.assertTrue(true);
        }
    }

	
    @Test
    public void testUpdateUser() {
        try
        {
          
        userDao.editUser(user1);
        Assert.assertEquals("patidar",userDao.getByUserEmail("jayeshptd@gmail.com").getLastName());
        }catch(Exception e)
        {
            Assert.assertTrue(true);
        }
    }

}







