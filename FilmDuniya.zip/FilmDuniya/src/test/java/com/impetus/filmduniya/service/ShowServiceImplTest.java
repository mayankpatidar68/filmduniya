package com.impetus.filmduniya.service;


import java.util.List;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import com.impetus.filmduniya.dto.City;
import com.impetus.filmduniya.dto.Movie;
import com.impetus.filmduniya.dto.Shows;
import com.impetus.filmduniya.dto.Theatre;



/**
 * The Class ShowServiceImplTest.
 */
@Transactional
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/Dispatcher-servlet.xml" })
public class ShowServiceImplTest {
	
	private static final int FOUR = 4;

    private static final int THREE = 3;

    /** The show service. */
	@Autowired
	ShowService showService;
	
	/** The show. */
	Shows show;
	
	/** The show1. */
	Shows show1;
	
	/** The movie. */
	Movie movie;
	
	/** The city. */
	City city;
	
	/** The theatre. */
	Theatre theatre;

	/**
	 * Sets the up.
	 *
	 * @throws Exception the exception
	 */
	@Before
	public void setUp() throws Exception {
		
		city = new City();
		city.setCityId(111);
		city.setCityName("Coimbatore");
		
		theatre = new Theatre();
		theatre.setCity(city);
		theatre.setNoOfColumns(10);
		theatre.setNoOfRows(10);
		theatre.setStatus("Active");
		
		movie = new Movie();
		movie.setDescription("Rating- 4* Mush Watch");
		movie.setDuration("3Hrs");
		movie.setMovieId(111);
		movie.setMovieName("Ram Leela");
		movie.setReleaseDate("showSearchDate");
		movie.setStatus("Active");
		
		
		show = new Shows();
		show.setAvailableSeats(10);
		show.setDuration("3Hrs");
		show.setEndTime("date");
		show.setFare(200);
		show.setMovie(movie);
		show.setShowDate("showSearchDate");
		show.setShowId(111);
		show.setStartTime("date");
		show.setStatus("Active");
		show.setTheatre(theatre);
		
		show1 = new Shows();
		show1.setShowId(3);

	}

	/**
	 * Test get all shows by criteria.
	 */
	@Test
	public void testGetAllShowsByCriteria() {
		
		try
		{
			List<Shows> shows = showService.getAllShowsByCriteria(1,1,12,2,"2014-04-28");
		Assert.assertNotNull(shows);
		}catch(Exception e)
		{
			Assert.assertTrue(false);
		}
	}

	/**
	 * Test get by show id.
	 */
	@Test
	public void testGetByShowId() {
		try
		{
			Shows show=showService.getByShowId(1);
		Assert.assertNotNull(show);
		}catch(Exception e)
		{
			Assert.assertTrue(false);
		}
	}

	/**
	 * Test update available seats.
	 */
	@Test
	public void testUpdateAvailableSeats() {
		try
		{
			show1.setAvailableSeats(80);
		showService.updateAvailableSeats(show1);
		Assert.assertEquals(80,(int)showService.getByShowId(3).getAvailableSeats());
		}catch(Exception e)
		{
			Assert.assertTrue(false);
		}
	}

	/**
	 * Test get show details.
	 */
	@Test
	public void testGetShowDetails() {
		
		try{
			List<Shows> shows = showService.getAllShowss();
			Assert.assertNotNull(shows);
			}catch(Exception e)
			{
				Assert.assertTrue(false);
			}
	}
	
	/**
	 * Test add show.
	 */
	@Test
	public void testAddShow() {
		try
		{
			showService.addShow(show1);
		}catch(Exception e)
		{
			Assert.assertTrue(false);
		}
	}
	
	
	/**
	 * Test update show.
	 */
	@Test
    public void testUpdateShow() {
        try
        {
            Shows shows = null;
            showService.updateShow(shows);
        }catch(Exception e)
        {
            Assert.assertTrue(true);
        }
    }

	/**
	 * Test delete show.
	 */
	@Test
    public void testDeleteShow() {
        try
        {
            Shows shows = null;
            showService.deleteShow(shows);
        }catch(Exception e)
        {
            Assert.assertTrue(true);
        }
    }
	
	/**
	 * Test add update delete show.
	 */
	@Test
    public void testAddUpdateDeleteShow() {
        try
        {
            String[] time2Array = new String[FOUR] ;
            time2Array[0]="0";
            time2Array[1]="0";
            time2Array[2]="0";
            time2Array[THREE]="0";
            showService.addUpdateDeleteShow(time2Array, 0, null, 0, 0, 0, null);
        }catch(Exception e)
        {
            Assert.assertTrue(false);
        }
    }
	
	/**
	 * Test get list.
	 */
	@Test
    public void testGetList() {
        
        try{
            int movieId = 0;
            int theatreId = 0;
            String date = null;
            List<Shows> getlist = showService.getList(movieId, theatreId, date);
            Assert.assertNotNull(getlist);
            }catch(Exception e)
            {
                Assert.assertTrue(false);
            }
    }
}
