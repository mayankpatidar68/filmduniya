package com.impetus.filmduniya.dto;



import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.web.multipart.MultipartFile;

// TODO: Auto-generated Javadoc
/**
 * The Class FileUploadTest.
 */
public class FileUploadTest {

	/** The Booking. */
	FileUpload fileUpload;
	
	/** The file. */
	MultipartFile file;
	
	 /**
 	 * Sets the up.
 	 */
 	@Before
	    public void setUp() {
	    	
	    	fileUpload = new FileUpload();
	        
	    }
	
	
		/**
		 * Test getter setter.
		 */
		@Test
	    public void testGetterSetter() {
	    	
			fileUpload.setFile(file);
			MultipartFile actual = fileUpload.getFile();
	        Assert.assertEquals(file, actual);
	}

	

}
