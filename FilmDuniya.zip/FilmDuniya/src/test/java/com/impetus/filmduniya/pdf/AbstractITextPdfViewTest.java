package com.impetus.filmduniya.pdf;

import java.io.OutputStream;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.Assert;
import org.junit.Test;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.PdfWriter;

// TODO: Auto-generated Javadoc
/**
 * The Class AbstractITextPdfViewTest.
 */
public class AbstractITextPdfViewTest {
    
    /** The abstract i text pdf view. */
    AbstractITextPdfView abstractITextPdfView = new AbstractITextPdfView() {
        
        @Override
        protected void buildPdfDocument(Map<String, Object> model,
                Document document, PdfWriter writer, HttpServletRequest request,
                HttpServletResponse response) {
            // TODO Auto-generated method stub
            
        }
    };

    /**
     * Test generates download content.
     */
    @Test
    public void testGeneratesDownloadContent() {
        abstractITextPdfView.generatesDownloadContent() ;
    }

   
        
    

    /**
     * Test abstract i text pdf view.
     */
    @Test
    public void testAbstractITextPdfView() {
        abstractITextPdfView.addStaticAttribute(null, abstractITextPdfView);
    }

    /**
     * Test render merged output model map of string object http servlet request http servlet response.
     */
    @Test
    public void testRenderMergedOutputModelMapOfStringObjectHttpServletRequestHttpServletResponse() {
        Map<String, Object> model = null;
        HttpServletRequest request = null;
        HttpServletResponse response = null;
        abstractITextPdfView.renderMergedOutputModel(model, request, response);
    }

    /**
     * Test new document.
     */
    @Test
    public void testNewDocument() {
        abstractITextPdfView.newDocument();
    }

    /**
     * Test new writer.
     *
     * @throws DocumentException the document exception
     */
    @Test
    public void testNewWriter() throws DocumentException {
        try{
        Document document = null;
        OutputStream os = null;
        abstractITextPdfView.newWriter(document, os);
        }catch (Exception e) {
            Assert.assertTrue(true);
        }
    }

  
    

}
