package com.impetus.filmduniya.controller;

import java.util.List;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import com.impetus.filmduniya.controller.UserController;
import com.impetus.filmduniya.dto.User;
import com.impetus.filmduniya.exception.DAOException;
import com.impetus.filmduniya.service.UserService;


/**
 * The Class UserControllerTest.
 */
@Transactional
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/Dispatcher-servlet.xml" })
public class UserControllerTest {
	
	/** The user controller. */
	@Autowired
	UserController userController;
	
	/** The user service. */
	@Autowired
	 UserService userService ;
	
	/** The model. */
	ModelMap model;
	
	/** The model1. */
	Model model1;
	
	/** The detail. */
	User detail;
	
	/** The user. */
	User user;
	
	/** The user2. */
	User user2;
	
	/** The user1. */
	User user1;
	
	/**
	 * Sets the up.
	 *
	 * @throws Exception the exception
	 */
	@Before
    public void setUp() throws Exception {
        user1 = new User();
        user1.setUserId(2);
        user1.setFirstName("jayesh");
        user1.setPassword("9993965444");
        user1.setContactNumber("99939654");
        user1.setLastName("patidar");
        
        user1.setEmailId("jayeshptd@gmail.com");
        
        user2 = new User();
        user2.setUserId(1);
        user2.setFirstName("mayank");
        user2.setPassword("9893989368");
        user2.setContactNumber("98939893");
        user2.setLastName("patidar");
        user2.setConfirmPassword("9893989368");
        user2.setEmailId("mayankpith@gmail.com");
    }

	
	
	/**
	 * Test Add User.
	 */
	@Test
		public void testAddUser() {
			try {
			    user2.setUserId(2);
				userController.addUser(user2);
			} catch (Exception e) {
				Assert.assertTrue(true);
			}
		}
	
	/**
	 * Test faillogin.
	 */
	@Test
	public void testUserRegistration() {
	try {
		String page =userController.addUserPage(model);
		Assert.assertEquals("UserRegistration", page);
	} catch (Exception e) {
		Assert.assertTrue(false);
		}
	}
	
	/**
	 * Test welcome.
	 */
	@Test
    public void testWelcome() {
    try {
        String page =userController.welcomePage(model1);
        Assert.assertEquals("SearchMovie", page);
    } catch (Exception e) {
        Assert.assertTrue(true);
        }
    }

	/**
	 * Test faillogin.
	 */
	@Test
	public void testEditUserDetails() {
	try {
		String page =userController.useredit(model);
		Assert.assertEquals("EditUserDetails", page);
	} catch (Exception e) {
		Assert.assertTrue(false);
		}
	}
	
	
	/**
	 * Test edit user.
	 */
	@Test
    public void testEditUser() {
	    try {
      
                userController.editUser(user2);
                
	    } catch (Exception e) {
            Assert.assertTrue(false);
        }
    }
	
	
	
	
	/**
	 * User details test.
	 */
	@Test
	public void userDetailsTest() {
	    try {
	        List<User> userDetails = userController.userDetails();
	        Assert.assertNotNull(userDetails);
	    } catch (Exception e) {
            Assert.assertTrue(true);
        }
	}
	
	
    
	/**
	 * Test forgot pass word.
	 */
	@Test
    public void testForgotPassWord() {
        try {
            
            
         Object ABC= userController.forgotPassword("mayankpith@gmail.com");
            Assert.assertNotNull(ABC);
        } catch (Exception e) {
            Assert.assertTrue(false);
        }
    }
	
	/**
	 * Handle dao exception test.
	 */
	@Test
	public void handleDaoExceptionTest() {
	    try {
	         DAOException e =null;
			Object exception= userController.handleException(e);
	        Assert.assertNotNull(exception);
	    } catch (Exception e) {
            Assert.assertTrue(false);
        }
	}
	
	/**
	 * Handle exception test.
	 */
	@Test
	public void handleExceptionTest() {
	    try {
	         Exception e =null;
			Object exception= userController.handleException(e);
	        Assert.assertNotNull(exception);
	    } catch (Exception e) {
            Assert.assertTrue(false);
        }
	}
}
