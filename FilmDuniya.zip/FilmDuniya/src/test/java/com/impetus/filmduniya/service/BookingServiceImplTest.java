package com.impetus.filmduniya.service;

import java.util.List;


import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.impetus.filmduniya.dao.BookingDao;
import com.impetus.filmduniya.dto.Booking;




/**
 * The Class BookingServiceImplTest.
 */
@Transactional
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/Dispatcher-servlet.xml" })
public class BookingServiceImplTest {
	
	/** The booking service. */
	@Autowired
	BookingService bookingService ;
	
	/** The booking dao. */
	@Autowired
    BookingDao bookingDao ;
	
	
	/** The Seat no value. */
	Integer[] SeatNoValue = null;
	
	/**
	 * Sets the up.
	 *
	 * @throws Exception the exception
	 */
	@Before
	public void setUp() throws Exception {
		SeatNoValue = new Integer[3];
		
		SeatNoValue[0]=1;
		SeatNoValue[1]=6;
		SeatNoValue[2]=3;
	}

	/**
	 * Test reserve seat and book.
	 */
	@Test
	public void testReserveSeatAndBook() {
		try
		{
			bookingService.reserveSeatAndBook(SeatNoValue, "mayankpith@gmail.com");
		
		}
		catch(Exception e)
		{
			Assert.assertTrue(false);
		}
	}

	/**
	 * Test get pdf detail.
	 */
	@Test
	public void testGetPDFDetail() {
		try
		{
			List<Booking> bookings = bookingService.getPDFDetail("1", "2014-04-04");
			Assert.assertNotNull(bookings);
		}
		catch(Exception e)
		{
			Assert.assertTrue(false);
		}
	}

	/**
	 * Test send booking mail.
	 */
	@Test
	public void testSendBookingMail() {
		try
		{
			bookingService.sendBookingMail(1, "mayankpith@gmail.com");
		}
		catch(Exception e)
		{
			Assert.assertTrue(false);
		}
	}
	/**
     * Test scheduled email.
     */
    @Test
    public void testScheduledEmail() {
        try{
            bookingService.scheduledEmail();

        }
        catch(Exception e)
        {
            Assert.assertTrue(true);
        }

    }
}
