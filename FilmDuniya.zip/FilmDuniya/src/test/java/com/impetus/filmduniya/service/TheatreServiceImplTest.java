package com.impetus.filmduniya.service;

import java.util.List;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import com.impetus.filmduniya.dto.City;
import com.impetus.filmduniya.dto.Theatre;

/**
 * The Class TheatreServiceImplTest.
 */
@Transactional
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/Dispatcher-servlet.xml" })
public class TheatreServiceImplTest {

	/** The theatre service. */
	@Autowired
	TheatreService theatreService ;
	
	/** The theatre. */
	Theatre theatre;
	
	/** The theatre1. */
	Theatre theatre1;
		
	/** The city. */
	City city;
	
		/**
		 * Sets the up.
		 *
		 * @throws Exception the exception
		 */
		@Before
		public void setUp() throws Exception {
			
			theatre = new Theatre();
			theatre.setTheatreId(12);
			
			theatre1 = new Theatre();
			theatre1.setNoOfColumns(15);
			theatre1.setNoOfRows(10);
			theatre1.setTheatreId(111);
			theatre1.setTheatreName("PVR");
			theatre1.setCity(city);
			theatre1.setStatus("Active");
		
		}
	

	/**
	 * Test get all theatres by city id.
	 */
	@Test
	public void testGetAllTheatresByCityId() {
		try
		{
			List<Theatre> theatres=theatreService.getAllTheatresByCityId(1);
		Assert.assertNotNull(theatres);
		}catch(Exception e)
		{
			Assert.assertTrue(false);
		}
	}
	
	/**
	 * Test add theatre.
	 */
	@Test
	public void testAddTheatre() {
		try
		{
			theatreService.addTheatre(theatre1);
		}catch(Exception e)
		{
			Assert.assertTrue(false);
		}
	}

		
	

	/**
	 * Test delete.
	 */
	@Test
	public void testDelete() {
		try
		{
		    theatre.setTheatreId(8);
			theatreService.delete(8);
		}catch(Exception e)
		{
			Assert.assertTrue(true);
		}
	}

	/**
	 * Test get all movies.
	 */
	@Test
	public void testGetAllTheatres() {
		try
		{
			List<Theatre> theatres = theatreService.getAllTheatres();
			Assert.assertNotNull(theatres);
		}catch(Exception e)
		{
			Assert.assertTrue(false);
		}
	}

}
