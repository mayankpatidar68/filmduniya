package com.impetus.filmduniya.dao;


import java.util.Date;
import java.util.List;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import com.impetus.filmduniya.dao.ShowDao;
import com.impetus.filmduniya.dto.City;
import com.impetus.filmduniya.dto.Movie;
import com.impetus.filmduniya.dto.Shows;
import com.impetus.filmduniya.dto.Theatre;






/**
 * The Class ShowDaoTest.
 */
@Transactional
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/Dispatcher-servlet.xml" })
public class ShowDaoTest {


/** The show dao. */
@Autowired
private ShowDao showDao;

/** The show dao impl. */
@Autowired
private ShowDaoImpl showDaoImpl;

/** The show. */
Shows show;

/** The date. */
Date date;

/** The show1. */
Shows show1;

/** The movie. */
Movie movie;

/** The city. */
City city;

/** The theatre. */
Theatre theatre;
/**
 * Sets the up.
 *
 * @throws Exception the exception
 */
@Before
public void setUp() throws Exception {
    
    city = new City();
    city.setCityId(111);
    city.setCityName("Coimbatore");
    
    theatre = new Theatre();
    theatre.setCity(city);
    theatre.setNoOfColumns(10);
    theatre.setNoOfRows(10);
    theatre.setStatus("Active");
    
    movie = new Movie();
    movie.setDescription("Rating- 4* Mush Watch");
    movie.setDuration("3Hrs");
    movie.setMovieId(111);
    movie.setMovieName("Ram Leela");
    movie.setReleaseDate("showSearchDate");
    movie.setStatus("Active");
    
    
    show = new Shows();
    show.setAvailableSeats(10);
    show.setDuration("3Hrs");
    show.setEndTime("date");
    show.setFare(200);
    show.setMovie(movie);
    show.setShowDate("showSearchDate");
    show.setShowId(111);
    show.setStartTime("date");
    show.setStatus("Active");
    show.setTheatre(theatre);
    
    show1 = new Shows();
    show1.setShowId(3);

}

/**
 * View show test.
 */
@Test
public void viewShowTest() {
	try {
		List<Shows> showList = showDao.getAllShowsByCriteria(1, 2, 1, 150, date);
		
		Assert.assertNotNull(showList);
	} catch (Exception e) {
		Assert.assertTrue(false);
	}
}

/**
 * Test add Show.
 */
@Test
@Transactional
public void testAddShow(){

	try{
		showDao.addShow(show);
	}catch(Exception e){
		Assert.assertTrue(false);
	}		
		}

/**
 * Test Get By Id.
 */

@Test
public void viewOfferTest() {
	try {
		show = showDao.getByShowId(1);
		System.out.print(show);
		Assert.assertNotNull(show);
	} catch (Exception e) {
		Assert.assertTrue(false);
	}
}




/**
 * Gets the show by id test.
 *
 * @return the show by id test
 */
@Test
public void getShowByIdTest() {
	try {
		 show = showDao.getByShowId(1);
		Assert.assertNotNull(show);
	} catch (Exception e) {
		Assert.assertTrue(false);
	}
}

/**
 * Update available seats test.
 */
@Test
public void updateAvailableSeatsTest() {
	try {
		showDao.updateAvailableSeats(show);
		Assert.assertNotNull(show);
	} catch (Exception e) {
		Assert.assertTrue(false);
	}
}

/**
 * Gets the all shows test.
 */
@Test
public void GetAllShowsTest() {
    try {
        showDao.getAllShowss();
       
    } catch (Exception e) {
        Assert.assertTrue(false);
    }
}

/**
 * Update show test.
 */
@Test
public void UpdateShowTest() {
    try {
        showDao.updateShow(null);
       
    } catch (Exception e) {
        Assert.assertTrue(true);
    }
}

/**
 * Delete show test.
 */
@Test
public void DeleteShowTest() {
    try {
        showDao.deleteShow(null);
       
    } catch (Exception e) {
        Assert.assertTrue(true);
    }
}

/**
 * Adds the update delete test.
 */
@Test
public void AddUpdateDeleteTest() {
    try {
        String[] time2Array=new String[4];
        time2Array[0]="0";
        time2Array[1]="0";
        time2Array[2]="0";
        time2Array[3]="0";
        
        showDao.addUpdateDeleteShow(time2Array, 0, null, 0, 0, 0, null);
       
    } catch (Exception e) {
        Assert.assertTrue(false);
    }
}

/**
 * Upload schedule test.
 */
@Test
public void uploadScheduleTest() {
    try {
        showDaoImpl.uploadSchedule();
       
    } catch (Exception e) {
        Assert.assertTrue(true);
    }
}

/**
 * Gets the list test.
 */
@Test
public void GetListTest() {
    try {
        List<Shows> getList = showDao.getfromShow(0, 0, null);
        Assert.assertNotNull(getList);
    } catch (Exception e) {
        Assert.assertTrue(false);
    }
}
}
