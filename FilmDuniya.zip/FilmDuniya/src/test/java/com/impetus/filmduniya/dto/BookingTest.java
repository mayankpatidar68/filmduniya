package com.impetus.filmduniya.dto;




import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.impetus.filmduniya.dto.Booking;
import com.opensymphony.xwork2.XWorkTestCase;



// TODO: Auto-generated Javadoc
/**
 * The Class BookingTest.
 */
public class BookingTest extends XWorkTestCase {

    /** The Booking. */
	Booking booking;

	/** The user. */
	User user;
	
	/** The shows. */
	Shows shows;
    /*
     * (non-Javadoc)
     * 
     * @see com.opensymphony.xwork2.XWorkTestCase#setUp()
     */

    
    @Before
    public void setUp() {
    	
    	booking = new Booking();
        
    }

    /**
     * Test getter setter. 
     */
    @Test
    public void testGetterSetter() {
    	Offer offer = null;
    		booking.setBookingId(1);
        int actual = booking.getBookingId();
        Assert.assertEquals(1, actual);
       
        booking.setOffer(offer);
        Object actual8 = booking.getOffer();
        Assert.assertEquals(offer, actual8);
       
        booking.setNoOfTickets(124);
        int actual2=booking.getNoOfTickets();
        Assert.assertEquals(124, actual2);
       
        booking.setActualFare(452);
        int actual3=booking.getActualFare();
        Assert.assertEquals(452, actual3);
        
        booking.setTotalFare(120);
        int actual4=booking.getTotalFare();
        Assert.assertEquals(120, actual4);
        
        
        booking.setShow(shows);
        Shows actual5 = booking.getShow();
        Assert.assertEquals(shows, actual5);
        
        
        booking.setUser(user);
        User actual6 = booking.getUser();
        Assert.assertEquals(user, actual6);
    }


}
