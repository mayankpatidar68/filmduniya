package com.impetus.filmduniya.dao;


import java.util.Date;



import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import com.impetus.filmduniya.dto.Offer;
import com.impetus.filmduniya.dto.Shows;
import com.opensymphony.xwork2.interceptor.annotations.Before;


// TODO: Auto-generated Javadoc
/**
 * The Class OfferDaoTest.
 */
@Transactional
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/Dispatcher-servlet.xml" })
public class OfferDaoTest {


	
	/** The offer dao. */
	@Autowired
	private OfferDao offerDao ;
	
	/** The show. */
	 Shows show;
	
	
	/** The offer. */
	Offer offer;
	
	
	/**
	 * Inits the.
	 */
	@Before
    public void init() {
	 
	  
	  offer.setOfferId(1);
	  offer.setDescription("test case discount");
	Date date= new Date(2014-06-30);
	Date date1= new Date(2014-05-30);
	  offer.setEndDate(date);
	  offer.setStartDate(date1);
	  offer.setOfferCode("1");
	//  offer.setShow(show);
	  offer.setType("Discount");
	  offer.setDiscount(50);
	  
	}

	
	
	/**
	 * Test get By Id.
	 */
	
	@Test
	public void viewOfferTest() {
		try {
			offer = offerDao.getByOfferId(1);
			System.out.print(offer);
			Assert.assertNotNull(offer);
		} catch (Exception e) {
			Assert.assertTrue(false);
		}
	}
	
	/**
	 * Gets the offer by id test.
	 *
	 * @return the offer by id test
	 */
	@Test
	public void getOfferByIdTest() {
		try {
			offer = offerDao.getByOfferId(1);
			Assert.assertNotNull(offer);
		} catch (Exception e) {
			Assert.assertTrue(false);
		}

	}
	
	/**
	 * Gets the offer for show test.
	 *
	 * @return the offer for show test
	 */
	@Test
	public void getOfferForShowTest() {
		try {
	
	List<Offer> offerList=offerDao.getOfferForShow(3);
	Assert.assertNotNull(offerList);
		} catch (Exception e) {
			Assert.assertTrue(false);
		}
	}
	
	/**
	 * Adds the deal test condition1.
	 */
	@Test
	public void addOfferTest(){
		try {
			offerDao.addOffer(offer);
			
		} catch (Exception e) {
			Assert.assertTrue(true);
		}
		
	}
	
	
	@Test
    public void addOffersTest(){
        try {
            offerDao.addOffers(null);
            
        } catch (Exception e) {
            Assert.assertTrue(true);
        }
        
    }

	
	/**
	 * Check Offer test condition1.
	 */
	@Test
	public void checkOfferTestCondition1(){
		
	
        Offer discount = offerDao.checkOffer("1", 1);
		Assert.assertNotNull(discount);
		
	}
	}
