package com.impetus.filmduniya.service;


import java.util.List;
import junit.framework.TestCase;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import com.impetus.filmduniya.dto.City;





/**
 * The Class CityServiceImplTest.
 */
@Transactional
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/Dispatcher-servlet.xml" })
public class CityServiceImplTest extends TestCase {

	/** The city service. */
	@Autowired
	CityService cityService ;

	/** The city. */
	City city;
	
	/** The city1. */
	City city1;
	
	
	/**
	 * Sets the up.
	 *
	 * @throws Exception the exception
	 */
	@Before
	public void setUp() throws Exception {
		
		city = new City();
		city.setCityId(12);
		city.setCityName("Ujjain");
		city1 = new City();
		city1.setCityName("Indore");
		
		city1.setCityId(111);
		
		
		
	}
	
	/**
	 * Test get all cities.
	 */
	@Test
	public void testGetAllCities() {
		try{
			List<City> cities=cityService.getAllCities();
			Assert.assertNotNull(cities);
			}catch(Exception e)
			{
				Assert.assertTrue(false);
			}
	}

	

	/**
	 * Test add movie.
	 */
	@Test
	public void testAddMovie() {
		try
		{
			cityService.addCity(city1);
		}catch(Exception e)
		{
			Assert.assertTrue(true);
		}
	}


	/**
	 * Test update.
	 */
	@Test
	public void testUpdate() {
		try
		{
			city.setCityName("Bhopal");
			cityService.editCity(city);
		}catch(Exception e)
		{
			Assert.assertTrue(true);
		}
	}

	/**
	 * Test delete.
	 */
	@Test
	public void testDelete() {
		try
		{
		    city.setCityId(12);
			cityService.delete(12);
		}catch(Exception e)
		{
			Assert.assertTrue(true);
		}
	}


}
