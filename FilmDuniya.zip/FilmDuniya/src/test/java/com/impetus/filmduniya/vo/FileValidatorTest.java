package com.impetus.filmduniya.vo;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.Errors;


// TODO: Auto-generated Javadoc
/**
 * The Class AdminControllerTest.
 */
@Transactional
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/Dispatcher-servlet.xml" })
public class FileValidatorTest {

	
	/** The admin controller. */
	FileValidator fileValidator;

	/**
	 * Sets the up.
	 *
	 * @throws Exception the exception
	 */
	@Before
	public void setUp() throws Exception {
		fileValidator=new FileValidator();
	}
	/**
	 * Test Add Movie.
	 */
	@Test
		public void testFileValidator() {
		
		Errors errors = null;
        Object uploadedFile = null;
        fileValidator.validate(uploadedFile, errors);
		
	}
}
