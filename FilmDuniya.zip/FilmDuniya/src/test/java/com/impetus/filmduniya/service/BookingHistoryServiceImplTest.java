package com.impetus.filmduniya.service;

import java.util.List;


import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.impetus.filmduniya.dto.Booking;
import com.impetus.filmduniya.dto.Ticket;
import com.impetus.filmduniya.dto.User;



// TODO: Auto-generated Javadoc
/**
 * The Class BookingHistoryServiceImplTest.
 */
@Transactional
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/Dispatcher-servlet.xml" })
public class BookingHistoryServiceImplTest {
	
	/** The booking history service. */
	@Autowired
	BookingHistoryService bookingHistoryService ;
	
	/** The user2. */
	User user;
	
	/**
	 * Sets the up.
	 *
	 * @throws Exception the exception
	 */
	@Before
	public void setUp() throws Exception {
		
		user = new User();
		user.setUserId(2);
	}

	/**
	 * Test get booking history.
	 */
	@Test
	public void testGetBookingHistory() {
		
			List<Booking> bookings = bookingHistoryService.getBookingHistory(user);
			Assert.assertNotNull(bookings);
		
	}

	/**
	 * Test get ticket details.
	 */
	@Test
	public void testGetTicketDetails() {
		
			List<Ticket> tickets = bookingHistoryService.getTicketDetails(2);
			Assert.assertNotNull(tickets);
		
	}

	/**
	 * Test cancel ticket.
	 */
	@Test
	public void testCancelTicket() {
		
			int i = bookingHistoryService.cancelTicket(651);
			Assert.assertNotNull(i);
		}
		

}
