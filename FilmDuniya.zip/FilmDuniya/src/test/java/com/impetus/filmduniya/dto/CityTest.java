package com.impetus.filmduniya.dto;


import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import com.impetus.filmduniya.dto.City;
import com.opensymphony.xwork2.XWorkTestCase;



// TODO: Auto-generated Javadoc
/**
 * The Class CityTest.
 */
public class CityTest extends XWorkTestCase {

    /** The City. */
	City city;

    /*
     * (non-Javadoc)
     * 
     * @see com.opensymphony.xwork2.XWorkTestCase#setUp()
     */

    
    @Before
    public void setUp() {
    	
    	city = new City();
        
    }

    /**
     * Test getter setter. 
     */
    @Test
    public void testGetterSetter() {
    	
    	city.setCityId(1);
        int actual = city.getCityId();
        Assert.assertEquals(1, actual);
       
       
        city.setCityName("Indore");
        String actual2=city.getCityName();
        Assert.assertEquals("Indore", actual2);
       
        
    }



}
