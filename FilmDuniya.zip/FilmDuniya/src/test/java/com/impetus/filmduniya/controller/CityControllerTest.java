package com.impetus.filmduniya.controller;

import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import com.impetus.filmduniya.dao.CityDaoImpl;
import com.impetus.filmduniya.dto.City;
import com.impetus.filmduniya.exception.DAOException;
import com.impetus.filmduniya.service.CityService;



/**
 * The Class CityControllerTest.
 */
@Transactional
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/Dispatcher-servlet.xml" })
public class CityControllerTest {

    /** The city controller. */
    @Autowired
    CityController cityController;
    
    /** The city service. */
    @Autowired
    private CityService cityService;
    
    /** The city dao impl. */
    CityDaoImpl cityDaoImpl;
    
    /** The city. */
    private City city;
    
    /** The model. */
    private ModelMap model;
    
    /** The model. */
    private Model model1;
    /**
     * Sets the up.
     *
     * @throws Exception the exception
     */
    @Before
    public void setUp() throws Exception {
        city = new City();
        city.setCityId(1);
        city.setCityName("Indore");
        
       
    }
    
    /**
     * Test city adder.
     */
    @Test
    public void testCityAdder() {

        
            String page = cityController.cityAdder(model);
            Assert.assertEquals("CityAdder", page);
            
        
    }


    /**
     * Test addcity.
     */
    @Test
        public void testAddcity() {
            city.setCityId(3);
            cityController.addCity(city);
                 
        }

    /**
     * Manage city test.
     */
    @Test
    public void manageCityTest() {
        
            List<City> cityList = cityController.manageCity();
            Assert.assertNotNull(cityList);
        
    }


    /**
     * Test edit city.
     */
    @Test
    public void testEditCity() {
        city.setCityId(3);
        cityController.editCity(city);

    }


    /**
     * Test delete city.
     */
    @Test
    public void testDeleteCity() {try{

        city.setCityId(59);
        cityController.destroyCity(59);
    } catch (Exception e) {
        Assert.assertTrue(true);
    }

    }
    /**
     * Test get all cities.
     */
    @Test
    public void testGetAllCities() {
        try {
            
            List<City> cities = cityController.getAllCities(model1);
            Assert.assertNotNull(cities);
        } catch (Exception e) {
            Assert.assertTrue(false);
        }
    }

    /**
     * Handle dao exception test.
     */
    @Test
    public void handleDaoExceptionTest() {
        try {
             DAOException e =null;
            Object exception= cityController.handleException(e);
            Assert.assertNotNull(exception);
        } catch (Exception e) {
            Assert.assertTrue(false);
        }
    }

    /**
     * Handle exception test.
     */
    @Test
    public void handleExceptionTest() {
        try {
             Exception e =null;
            Object exception= cityController.handleException(e);
            Assert.assertNotNull(exception);
        } catch (Exception e) {
            Assert.assertTrue(false);
        }
    }
}
