package com.impetus.filmduniya.dao;

import java.util.List;









import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;



import com.impetus.filmduniya.dto.City;




// TODO: Auto-generated Javadoc
/**
 * The Class CityDaoTest.
 */
@Transactional
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/Dispatcher-servlet.xml" })
public class CityDaoTest {
	
	/** The city dao. */
	@Autowired
	private CityDao cityDao;
	
	
	/** The city. */
	City city;
	
	/**
	 * Inits the.
	 */
	@Before
    public void init() {
		city = new City();
		city.setCityId(6);
		city.setCityName("Punji");
		
	}
	
	/**
	 * View city test.
	 */
	@Test
	public void viewCityTest() {
		
			List<City> cityList = cityDao.getAllCities();
			System.out.print(cityList);
			Assert.assertNotNull(cityList);
		
	}
	
	/**
	 * Test add City.
	 */
	@Test
	@Transactional
	public void testAddCity(){

		
			cityDao.addCity(city);
		
			
			}
	
	
   
	
	/**
	 * Test delete city.
	 */
	@Test
	@Transactional
    public void testDeleteCity(){
		try{
		city.setCityId(6);
			 cityDao.delete(6);
		}catch(Exception e)
        {
            Assert.assertTrue(true);
        }
	}
	
	/**
 * Test edit city.
 */
@Test
	@Transactional
    public void testEditCity(){
		
			city.setCityId(2);
			 cityDao.editCity(city);
		
	}
}
