package com.impetus.filmduniya.dao;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import com.impetus.filmduniya.dto.Movie;
import com.opensymphony.xwork2.interceptor.annotations.Before;





/**
 * The Class MovieDaoTest.
 */
@Transactional
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/Dispatcher-servlet.xml" })
public class MovieDaoTest {
	
	/** The movie dao. */
	@Autowired
	private MovieDao movieDao;
	
	/** The movie. */
	Movie movie;

	
	
	
	/**
	 * Inits the.
	 */
	@Before
    public void init() {
		movie = new Movie();
		movie.setMovieId(1);
		movie.setMovieName("X-Man");
		movie.setDescription("Super Hit");
		movie.setReleaseDate("2014-04-15");
		movie.setDuration("2:30");
		movie.setStatus("RUNNING");
		
	}

	
	/**
	 * View movie test.
	 */
	@Test
	public void viewMovieTest() {
		
			List<Movie> movieList = movieDao.getAllMovieByTheatreId(4);
			System.out.print(movieList);
			Assert.assertNotNull(movieList);
		
	}
	
	/**
	 * Test add Movie.
	 */
	@Test
	@Transactional
	public void testAddMovie(){
try{
			movieDao.addMovie(movie);
		
	}
    catch(Exception e){
        Assert.assertTrue(true);
        
    }
			}
	
	
	/**
	 * Gets the all movies test.
	 *
	 * @return the all movies test
	 */
	@Test
	public void getAllMoviesTest() {
		
			List<Movie> movieList = movieDao.getAllMovies();
			List<Movie> Movie = movieDao.getAllMovies();
			Assert.assertEquals(Movie, movieList);
		
		
	}
	
	/**
	 * Gets the all movie by theatre id test.
	 *
	 * @return the all movie by theatre id test
	 */
	@Test
	public void getAllMovieByTheatreIdTest() {
		
	
	List<Movie> movieList=movieDao.getAllMovieByTheatreId(1);
	Assert.assertNotNull(movieList);
		
	}
	/**
 * Gets the movie by id test.
 *
 * @return the movie by id test
 */
@Test
	public void getMovieByIdTest() {
		try {
			 movie = movieDao.getMovieById(2);
			Assert.assertNotNull(movie);
		} catch (Exception e) {
			Assert.assertTrue(false);
		}
	}

@Test
public void getByIdTest() {
    try {
         int movieId = 1;
        movie = movieDao.getById(movieId);
        Assert.assertNotNull(movie);
    } catch (Exception e) {
        Assert.assertTrue(false);
    }
}
	/**
	 * Gets the by name test.
	 *
	 * @return the by name test
	 */
	@Test
	public void getByNameTest(){
	
		try{
			movie = movieDao.getByName("X-Man");
		    Assert.assertNotNull(movie);
		}catch(Exception e){
			Assert.assertTrue(false);
		}
	}
	

}
