package com.impetus.filmduniya.dto;





import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.impetus.filmduniya.dto.Movie;
import com.opensymphony.xwork2.XWorkTestCase;



// TODO: Auto-generated Javadoc
/**
 * The Class MovieTest.
 */
public class MovieTest extends XWorkTestCase {

    /** The Movie. */
	Movie movie;

    /*
     * (non-Javadoc)
     * 
     * @see com.opensymphony.xwork2.XWorkTestCase#setUp()
     */

    
    @Before
    public void setUp() {
    	
    	movie = new Movie();
        
    }

    /**
     * Test getter setter. 
     */
    @Test
    public void testGetterSetter() {
    	
    	movie.setMovieId(1);
        int actual = movie.getMovieId();
        Assert.assertEquals(1, actual);
       
       
        movie.setMovieName("O TERI");
       String actual2=movie.getMovieName();
        Assert.assertEquals("O TERI", actual2);
       
        movie.setDescription("bkajfbkj");
        String actual3=movie.getDescription();
         Assert.assertEquals("bkajfbkj", actual3);
        
         movie.setReleaseDate("2014-10-10");
         String actual4=movie.getReleaseDate();
          Assert.assertEquals("2014-10-10", actual4);
          
          
        movie.setDuration("3:15");
        String actual5=movie.getDuration();
        Assert.assertEquals("3:15", actual5);
        
        movie.setStatus("Running");
        String actual6=movie.getStatus();
        Assert.assertEquals("Running", actual6);
        
       
    }

}
