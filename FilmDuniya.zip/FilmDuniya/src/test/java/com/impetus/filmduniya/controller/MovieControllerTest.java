package com.impetus.filmduniya.controller;

import java.io.IOException;
import java.util.List;
import javax.servlet.http.HttpSession;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import com.impetus.filmduniya.dao.BookingHistoryDao;
import com.impetus.filmduniya.dao.OfferDaoImpl;
import com.impetus.filmduniya.dao.TicketDaoImpl;
import com.impetus.filmduniya.dto.Movie;
import com.impetus.filmduniya.dto.Offer;
import com.impetus.filmduniya.dto.Ticket;
import com.impetus.filmduniya.dto.User;
import com.impetus.filmduniya.exception.DAOException;
import com.impetus.filmduniya.vo.FileUploadForm;


/**
 * The Class MovieControllerTest.
 */
@Transactional
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/Dispatcher-servlet.xml" })
public class MovieControllerTest {

	/** The movie controller. */
	@Autowired
	MovieController movieController ;

	/** The model. */
	Model model;
	
	/** The model1. */
	ModelMap model1;
	
	/** The user. */
	User user;
	
	/** The ticket dao. */
	TicketDaoImpl ticketDao ;
	
	/** The offer dao. */
	OfferDaoImpl offerDao;

	/** The ticket. */
	Ticket ticket;
	
	/** The offer. */
	Offer offer;
	
	/** The booking history dao. */
	BookingHistoryDao bookingHistoryDao;
	
	/** The session. */
	HttpSession session;

	/** The upload offer. */
    FileUploadForm uploadOffer;

    /** The upload form. */
    FileUploadForm uploadForm;

    /** The result. */
    BindingResult result;


	/** The movie. */
	private Movie movie;

	/**
	 * Sets the up.
	 *
	 * @throws Exception the exception
	 */
	@Before
	public void setUp() throws Exception {

		movie = new Movie();
		movie.setMovieId(12);
		
		user = new User();
		user.setUserId(2);
	}

	

	

	/**
	 * Test get all movies int.
	 */
	@Test
	public void testGetAllMoviesInt() {
		try {
			List<Movie> movies = movieController.getAllMovies(1);
			Assert.assertNotNull(movies);
		} catch (Exception e) {
			Assert.assertTrue(false);
		}
	}

	/**
	 * Test get all movies.
	 *
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	@Test
	public void testGetAllMovies() throws IOException {
		
			List<Movie> movies = movieController.getAllMovies(model);
			Assert.assertNotNull(movies);
		
	}

	
	/**
     * Test movie adder.
     */
    @Test
    public void testMovieAdder() {
        movie.setMovieId(2);
            String page = movieController.movieAdder(model1);
            Assert.assertEquals("MovieAdder", page);
            
        
    }
    
    /**
     * Test Add Movie.
     */
    @Test
        public void testAddMovie() {
            movie.setMovieId(115);
            movie.setMovieName("Test");
            movie.setReleaseDate("2014-05-28");
            movie.setDuration("2:50");
            movie.setStatus("Running");
            movie.setDescription("Good");

            movieController.addMovie(movie);
                 
                
        }
    
    /**
     * Manage movie test.
     */
    @Test
    public void manageMovieTest() {
        
            List<Movie> movieList = movieController.manageMovie();
            Assert.assertNotNull(movieList);
        
    }
    
    /**
 * Test update movie movie.
 */
@Test
    public void testEditMovie() {
    movie.setMovieId(2);
    movieController.editMovie(movie);
    }

/**
 * Test delete movie.
 */
@Test
public void testDeleteMovie() {try{

    movieController.destroyMovie(3);
} catch (Exception e) {
    Assert.assertTrue(true);
}
    
}

    
	/**
	 * Handle dao exception test.
	 */
	@Test
	public void handleDaoExceptionTest() {
	    try {
	         DAOException e =null;
			Object exception= movieController.handleException(e);
	        Assert.assertNotNull(exception);
	    } catch (Exception e) {
            Assert.assertTrue(false);
        }
	}
	
	/**
	 * Handle exception test.
	 */
	@Test
	public void handleExceptionTest() {
	    try {
	         Exception e =null;
			Object exception= movieController.handleException(e);
	        Assert.assertNotNull(exception);
	    } catch (Exception e) {
            Assert.assertTrue(false);
        }
}
	
	
	}
