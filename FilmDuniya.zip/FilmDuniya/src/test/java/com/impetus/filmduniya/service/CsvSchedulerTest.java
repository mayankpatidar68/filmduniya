package com.impetus.filmduniya.service;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;





/**
 * The Class CsvSchedulerTest.
 */
@Transactional
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/Dispatcher-servlet.xml" })
public class CsvSchedulerTest {
    
    /** The Constant THREE. */
    private static final int THREE = 3;
    
    /** The Constant FOUR. */
    private static final int FOUR = 4;
    
    /** The job scheduler for csv. */
    @Autowired
    CsvScheduler jobSchedulerForCsv ;

    /**
     * Testscheduler operation.
     */
    @Test
    public void testschedulerOperation() {
        try
        {
           String[] time1Array = new String[FOUR] ;
           time1Array[0]="0";
           time1Array[1]="0";
           time1Array[2]="0";
           time1Array[THREE]="0";
        jobSchedulerForCsv.schedulerOperation(time1Array, 0, null, null, 0, null, null);
      
        }catch(Exception e)
        {
            Assert.assertTrue(true);
        }
    }

    /**
     * Test get offer for show.
     */
    @Test
    public void testdemoServiceMethod() {
        try
        {
            jobSchedulerForCsv.demoServiceMethod();
       
        }catch(Exception e)
        {
            Assert.assertTrue(false);
        }
    }

}
