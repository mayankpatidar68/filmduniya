package com.impetus.filmduniya.controller;

import java.util.List;


import javax.persistence.EntityExistsException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import com.impetus.filmduniya.dao.BookingHistoryDao;
import com.impetus.filmduniya.dao.MovieDaoImpl;
import com.impetus.filmduniya.dao.TheatreDaoImpl;
import com.impetus.filmduniya.dto.Booking;
import com.impetus.filmduniya.dto.City;
import com.impetus.filmduniya.dto.FileUpload;
import com.impetus.filmduniya.dto.Movie;
import com.impetus.filmduniya.dto.Seat;
import com.impetus.filmduniya.dto.Shows;
import com.impetus.filmduniya.dto.Theatre;
import com.impetus.filmduniya.dto.Ticket;
import com.impetus.filmduniya.dto.User;
import com.impetus.filmduniya.exception.DAOException;
import com.impetus.filmduniya.vo.BookingShowId;
import com.impetus.filmduniya.vo.TheatreVO;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;



/**
 * The Class AdminControllerTest.
 */
@Transactional
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/Dispatcher-servlet.xml" })
public class BookingControllerTest {

	
	/** The admin controller. */
	@Autowired
	BookingController bookingController;

	/** The model. */
	private ModelMap model;
	
	/** The theatre  vo. */
	private TheatreVO theatreVo;
	
	

	
	/** The movie dao impl. */
	MovieDaoImpl movieDaoImpl;
	
	

    /** The booking history dao. */
    BookingHistoryDao bookingHistoryDao;

	/** The theatre dao impl. */
	TheatreDaoImpl theatreDaoImpl;
	
	/** The model. */
    private Model model1;
	
    /** The user. */
    User user;

	
	/** The file upload. */
	FileUpload fileUpload;
	
	/** The movie. */
	private Movie movie;
	
	/** The city. */
	private City city;
	
	
	/** The theatre. */
	private Theatre theatre;
	
	/** The show. */
	private Shows show;
	
	/** The session. */
    HttpSession session;
	
   

  
    
   
    
	/**
	 * Sets the up.
	 *
	 * @throws Exception the exception
	 */
	@Before
	public void setUp() throws Exception {
		
		movie = new Movie();
		movie.setMovieId(3);
		theatre= new Theatre();
		theatre.setTheatreId(4);
		city = new City();
		city.setCityId(1);
		city.setCityName("Indore");
		theatre.setCity(city);
		theatreVo= new TheatreVO();
		theatreVo.setTheatreName("abc");
		theatreVo.setCityId("2");
		show = new Shows();
		show.setShowId(1);
	}
	
	
	



/**
 * Test get search input.
 *//*
@Test
public void testGetSearchInput() {
    
       
        List<Shows> shows = bookingController.getSearchInput(1, 1, 1, null, 2, "2014-06-20", session);
        Assert.assertNotNull(shows);
    
}
*/

    /**
     * Test book page.
     */
    @Test
    public void testBookPage() {
        try{
            String page = bookingController.bookPage(null);
            Assert.assertEquals("SearchMovie", page);
        } catch (Exception e) {
            Assert.assertTrue(true);
        }
        
    }

    /**
     * Test search movie.
     */
    @Test
    public void testSearchMovie() {
        try{
            String page = bookingController.searchMovie(model);
            Assert.assertEquals("SearchMovie", page);
        } catch (Exception e) {
            Assert.assertTrue(true);
        }
        
    }
    
    /**
     * Test book.
     */
    @Test
public void testBook(){
        try {
    
    BookingShowId bookingShowId = null ;
  
    String book = bookingController.bookRequest(bookingShowId , model1, session);
    Assert.assertNotNull(book);
} catch (Exception e) {
    Assert.assertTrue(true);
}

}
    
    /**
     * Test reservation.
     */
    @Test
    public void testReservation() {
        try{
            Integer[] seatNoValue= null;
            bookingController.seatBooking(seatNoValue, session);
        }catch(Exception e) {
            Assert.assertTrue(true);}
    }
 



/**
 * Test generate report.
 */
@Test
public void testGeneratePDF() {
    try {
        String page = bookingController.pdfReport(model);
        Assert.assertEquals("GeneratePdfReport", page);
    } catch (Exception e) {
        Assert.assertTrue(false);
    }
}

/**
 * Testdownloadpdf.
 */
@Test
public void testdownloadpdf() {
    try {
        HttpServletRequest request = null;
        bookingController.downloadPdf(request);
    } catch (Exception e) {
        Assert.assertTrue(true);
    }
}
/**
 * Test check offer.
 */




/**
 * Test get reserved seats.
 */
@Test
public void testGetBookedSeats() {
    
        List<Seat> seats = bookingController.getReservedSeats(1);
        Assert.assertNotNull(seats);
    
}

    /**
     * Test payment success page1.
     */
    @Test
    public void testPaymentSuccessPage1() {
        try{
            String page = bookingController.paymentSuccessPage(model, session);
            Assert.assertEquals("paymentSuccess", page);
    } catch (Exception e) {
        Assert.assertTrue(true);
    }
    }

    
    /**
     * Test payment gateway.
     */
    @Test
    public void testPaymentGateway() {
        try{
            String page = bookingController.paymentGateway(model1, session);
            Assert.assertEquals("PaymentGateway", page);
    } catch (Exception e) {
        Assert.assertTrue(false);
    }
    }

/**
 * Test booking history detail.
 */
@Test
public void testBookingHistoryDetail() {
    try{
        
     List<Booking> bookinglist = bookingController.history();
     Object excepted = bookingHistoryDao.getBookingHistory(user);
        Assert.assertEquals(excepted, bookinglist);
    } catch (Exception e) {
        Assert.assertTrue(true);
    }
    
}



/**
 * Test ticket history detail.
 */
@Test
public void testTicketHistoryDetail() {

        List<Ticket> tickets = bookingController.ticketHistoryDetail(40);
    
        Assert.assertNotNull(tickets);
    
}


/**
 * Test cancel ticket.
 */
@Test
public void testCancelTicket() {
    try{
     bookingController.cancelTicket(378);
    
    } catch (Exception e) {
        Assert.assertTrue(true);
    }
}








/**
 * Handle dao exception test.
 */
@Test
public void handleDaoExceptionTest() {
    try {
         DAOException e =null;
		Object exception= bookingController.handleException(e);
        Assert.assertNotNull(exception);
    } catch (Exception e) {
        Assert.assertTrue(false);
    }
}

/**
 * Handle exception test.
 */
@Test
public void handleExceptionTest() {
    try {
         Exception e =null;
		Object exception= bookingController.handleException(e);
        Assert.assertNotNull(exception);
    } catch (Exception e) {
        Assert.assertTrue(false);
    }
}

/**
 * Handle exception test.
 */
@Test
public void handleEntityExistsExceptionTest() {
    try {
          EntityExistsException e = null;
        Object exception= bookingController.handleEntityException(e);
        Assert.assertNotNull(exception);
    } catch (Exception e) {
        Assert.assertTrue(false);
    }
}


    
//@After
//public void tearDown() throws Exception {
//	movie.setMovieId(3);
//	movie.setMovieName("Mast");
//	movie.setReleaseDate("2014-15-28");
//	movie.setDescription("Very Good");
//	movie.setDuration("3:00");
//	movie.setStatus("Running");
//	movieDaoImpl.addMovie(movie);
//	
//	movieDaoImpl.delete(115);
//}

}
