package com.impetus.filmduniya.service;


import java.util.List;


import org.junit.Assert;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.impetus.filmduniya.dto.User;


/**
 * The Class UserServiceImplTest.
 */
@Transactional
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/Dispatcher-servlet.xml" })
public class UserServiceImplTest {
	
	/** The user service. */
	@Autowired
	UserService userService;

	/** The user. */
	User user;
	
	/** The user1. */
	User user1;
	
	/** The user2. */
	User user2;
	
	
	/**
	 * Sets the up.
	 *
	 * @throws Exception the exception
	 */
	@Before
	public void setUp() throws Exception {
		user1 = new User();
		user1.setUserId(2);
		user1.setFirstName("jayesh");
		user1.setPassword("9993965444");
		user1.setContactNumber("9993965444");
		user1.setLastName("patidar");
		
		user1.setEmailId("jayeshptd@gmail.com");
		
		user2 = new User();
		user2.setUserId(1);
		user2.setFirstName("mayank");
		user2.setPassword("9893989368");
		user2.setContactNumber("9893989368");
		user2.setConfirmPassword("9893989368");
		user2.setLastName("patidar");
	
		user2.setEmailId("mayankpith@gmail.com");
	}

	/**
	 * Test add user.
	 */
	@Test
	public void testAddUser() {
		try
		{
			userService.addUser(user2);
		}catch(Exception e)
		{
			Assert.assertTrue(true);
		}
	}

	/**
	 * Test get by user email.
	 */
	@Test
	public void testGetByUserEmail() {
		try
		{
			User getuser=userService.getByUserEmail("mayankpith@gmail.com");
		Assert.assertNotNull(getuser);
		}catch(Exception e)
		{
			Assert.assertTrue(false);
		}
	}

	/**
	 * Test update user.
	 */
	@Test
	public void testUpdateUser() {
		try
		{
			user1.setLastName("patidar");
		userService.editUser(user1);
		Assert.assertEquals("patidar",userService.getByUserEmail("jayeshptd@gmail.com").getLastName());
		}catch(Exception e)
		{
			Assert.assertTrue(false);
		}
	}

	/**
	 * Test get users.
	 */
	@Test
	public void testGetUsers() {
		try
		{
			List<User> users = userService.getAllUsers();
			Assert.assertEquals(null, users);
		}catch(Exception e)
		{
			Assert.assertTrue(false);
		}
	}

	
	/**
	 * Test get user by id.
	 */
	@Test
	public void testGetUserById() {
		try
		{
			User getuser=userService.getUserById(1);
		Assert.assertEquals(null, getuser);
		}catch(Exception e)
		{
			Assert.assertTrue(false);
		}
	}
	
	
	
	/**
	 * Test get user details.
	 */
	@Test
	public void testGetUserDetails() {
		try
		{
			User getuser=userService.getUserDetails(user2);
		Assert.assertNotNull(getuser);
		}catch(Exception e)
		{
			Assert.assertTrue(false);
		}
	}
	
	
	/**
	 * Test send mail.
	 */
	@Test
    public void testSendMail() {
        try
        {
           
            String emailId="mayankpith@gmail.com";
            userService.sendUserMail(emailId);
    
        }catch(Exception e)
        {
            Assert.assertTrue(false);
        }
    }
}
