package com.impetus.filmduniya.controller;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import com.impetus.filmduniya.controller.LoginController;




/**
 * The Class LoginControllerTest.
 */
@Transactional
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/Dispatcher-servlet.xml" })
public class LoginControllerTest {
	
	/** The login controller. */
	@Autowired
	LoginController loginController ;

	/** The model. */
	ModelMap model;
	
	/** The model1. */
	Model model1;
	
	
	/**
	 * Sets the up.
	 *
	 * @throws Exception the exception
	 */
	@Before
	public void setUp() throws Exception {
		
	}

	
	
	/**
	 * Test sign up.
	 */
	@Test
	public void testSignUp() {
		try {
			String page = loginController.signUp(null);
			Assert.assertEquals("UserRegistration", page);
		} catch (Exception e) {
			Assert.assertTrue(false);
		}
	}
	
	/**
	 * Test login page.
	 */
	@Test
	public void testLoginPage() {
		try {
			String page = loginController.loginUser(model);
			Assert.assertEquals("LoginPage", page);
		} catch (Exception e) {
			Assert.assertTrue(false);
		}
	}

	/**
	 * Test login.
	 */
	@Test
	public void testLogin() {
				try {
			String page = loginController.login(null);
			Assert.assertEquals("LoginPage", page);
		} catch (Exception e) {
			Assert.assertTrue(false);
			}
	}

	/**
	 * Test faillogin.
	 */
	@Test
	public void testFaillogin() {
	try {
		String page = loginController.faillogin(null);
		Assert.assertEquals("LoginFailed", page);
	} catch (Exception e) {
		Assert.assertTrue(false);
		}
	}
	
	
	
	
	/**
	 * Testlog off.
	 */
	@Test
	public void testlogOff() {
		try {
			;
			String page = loginController.logoff(model);
			Assert.assertEquals("SearchMovie", page);
		} catch (Exception e) {
			Assert.assertTrue(true);
		}
	}

	

	/**
	 * Testuser booking history.
	 */
	@Test
	public void testuserBookingHistory() {
		try {
			//model1.addAttribute("cancelTicketFormAttribute", new CancelTicketId());
			String page = loginController.bookingHistory(model1);
			Assert.assertEquals("SearchMovie", page);
		} catch (Exception e) {
			Assert.assertTrue(true);
		}
	}
}
