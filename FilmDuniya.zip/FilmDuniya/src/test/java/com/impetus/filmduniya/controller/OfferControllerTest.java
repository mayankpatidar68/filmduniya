package com.impetus.filmduniya.controller;

import java.util.List;

import javax.persistence.EntityExistsException;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;

import com.impetus.filmduniya.dao.OfferDaoImpl;
import com.impetus.filmduniya.dto.Offer;
import com.impetus.filmduniya.exception.DAOException;
import com.impetus.filmduniya.vo.FileUploadForm;



/**
 * The Class OfferControllerTest.
 */
@Transactional
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/Dispatcher-servlet.xml" })
public class OfferControllerTest {

    /** The admin controller. */
    @Autowired
    OfferController offerController;
    
    /** The offer dao. */
    OfferDaoImpl offerDao;
    
    /** The model. */
    private Model map;
    

    /** The result. */
    BindingResult result;
    
    /** The upload offer. */
    FileUploadForm uploadOffer;
   
        /**
         * Test get offer.
         */
        @Test
        public void testGetOffer() {

            
                List<Offer> offer = offerController.getOffer(1);
                Assert.assertNotNull(offer);
                
            
        }
    
    
    /**
     * Test check offer.
     */
    @Test
    public void testCheckOffer(){   
        try{
        
        Object offer = offerController.checkOffer("1",1);
        Object expected= offerDao.checkOffer("1", 1);
            Assert.assertEquals(expected,offer);
            
    } catch (Exception e) {
        Assert.assertTrue(true);
    }
    }
    
    
    /**
     * Testofferadder page.
     */
    @Test
    public void testofferadderPage() {

        String page = offerController.displayOfferForm();
        Assert.assertEquals("offers", page);

    }






    /**
     * Testmanage offer.
     */
    @Test
    public void testmanageOffer() {

        try {
            String page = offerController.addingOffer();
            Assert.assertEquals("uploadOffer", page);
            
        } catch (Exception e) {
            Assert.assertTrue(false);
        }
    }

    
    /**
     * Testupload xmlfile.
     */
    @Test
    public void testuploadXMLfile() {
        try {
            
           
            offerController.uploadXMLfile(uploadOffer, result, map);
        } catch (Exception e) {
            Assert.assertTrue(true);
        }
    }
    /**
     * Handle dao exception test.
     */
    @Test
    public void handleDaoExceptionTest() {
        try {
             DAOException e =null;
            Object exception= offerController.handleException(e);
            Assert.assertNotNull(exception);
        } catch (Exception e) {
            Assert.assertTrue(false);
        }
    }

    /**
     * Handle exception test.
     */
    @Test
    public void handleExceptionTest() {
        try {
             Exception e =null;
            Object exception= offerController.handleException(e);
            Assert.assertNotNull(exception);
        } catch (Exception e) {
            Assert.assertTrue(false);
        }
    }

    /**
     * Handle exception test.
     */
    @Test
    public void handleEntityExistsExceptionTest() {
        try {
              EntityExistsException e = null;
            Object exception= offerController.handleEntityException(e);
            Assert.assertNotNull(exception);
        } catch (Exception e) {
            Assert.assertTrue(false);
        }
    }
    }

