package com.impetus.filmduniya.controller;

import java.io.IOException;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;

import com.impetus.filmduniya.dao.TheatreDaoImpl;
import com.impetus.filmduniya.dto.City;
import com.impetus.filmduniya.dto.Movie;
import com.impetus.filmduniya.dto.Shows;
import com.impetus.filmduniya.dto.Theatre;
import com.impetus.filmduniya.exception.DAOException;
import com.impetus.filmduniya.vo.TheatreVO;


/**
 * The Class TheatreControllerTest.
 */
@Transactional
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/Dispatcher-servlet.xml" })
public class TheatreControllerTest {

 
    /** The theatre controller. */
    @Autowired
    TheatreController theatreController;
    
    
  
    /** The theatre dao impl. */
    TheatreDaoImpl theatreDaoImpl;
    
   
    /** The theatre vo. */
    private TheatreVO theatreVo;
    
    
    /** The movie. */
    private Movie movie;
    
    /** The city. */
    private City city;
    
    
    /** The theater. */
    private Theatre theatre;
    
    /** The show. */
    private Shows show;
    
    /** The model. */
    private Model model1;
    
    /** The model. */
    private ModelMap model;
    /**
     * Sets the up.
     *
     * @throws Exception the exception
     */
    @Before
    public void setUp() throws Exception {
        
        movie = new Movie();
        movie.setMovieId(3);
        theatre= new Theatre();
        theatre.setTheatreId(4);
        city = new City();
        city.setCityId(1);
        city.setCityName("Indore");
        theatre.setCity(city);
        theatreVo= new TheatreVO();
        theatreVo.setTheatreName("abc");
        theatreVo.setCityId("2");
        show = new Shows();
        show.setShowId(1);
    }
    
    
        /**
         * Test theatre adder.
         */
        @Test
        public void testTheatreAdder() {

            
                String page = theatreController.theatreAdder(model);
                Assert.assertEquals("TheatreAdder", page);
            
        }


        /**
         * Test addtheatre.
         */
        @Test
            public void testAddtheatre() {
                theatre.setTheatreId(2);
                theatreController.addTheatre(theatreVo);
                     
                    
                
            }

        /**
         * Manage theatrte test.
         */
        @Test
        public void manageTheatrteTest() {
            
                List<Theatre> theatreList = theatreController.manageTheatre();
                Assert.assertNotNull(theatreList);
            
        }
         


        /**
         * Test delete theatre.
         */
        @Test
        public void testDeleteTheatre() {try{
            theatreController.destroytheatre(4);
        } catch (Exception e) {
            Assert.assertTrue(true);
        }
        }
        
        /**
         * Test get all movies.
         *
         * @throws IOException Signals that an I/O exception has occurred.
         */
        @Test
        public void testGetAllTheatres() throws IOException {
            
                List<Theatre> theatres = theatreController.getAllTheatres(model1);
                Assert.assertNotNull(theatres);
            
            
        }
        /**
         * Test get all theatres.
         */

        @Test
        public void testGetAllTheatresInt() {

            List<Theatre> theatres = theatreController.getAllTheatres(1);
            Assert.assertNotNull(theatres);

        }

        /**
         * Handle dao exception test.
         */
        @Test
        public void handleDaoExceptionTest() {
            try {
                 DAOException e =null;
                Object exception= theatreController.handleException(e);
                Assert.assertNotNull(exception);
            } catch (Exception e) {
                Assert.assertTrue(false);
            }
        }
        
        /**
         * Handle exception test.
         */
        @Test
        public void handleExceptionTest() {
            try {
                 Exception e =null;
                Object exception= theatreController.handleException(e);
                Assert.assertNotNull(exception);
            } catch (Exception e) {
                Assert.assertTrue(false);
            }
    }

    }


