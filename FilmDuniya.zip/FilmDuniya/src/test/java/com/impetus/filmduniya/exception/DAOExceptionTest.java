package com.impetus.filmduniya.exception;
import org.junit.Assert;

import org.junit.Test;


import com.opensymphony.xwork2.XWorkTestCase;



// TODO: Auto-generated Javadoc
/**
 * The Class DAOExceptionTest.
 */
public class DAOExceptionTest extends XWorkTestCase {
    
    /** The Constant message. */
    private static final String message = null;
    /** The Booking. */
    DAOException dAOException= new DAOException(message);
   
    
    
    
    /**
     * Test getter setter message.
     */
    @Test
    public void testGetterSetterMessage() {
        dAOException.setMessage("dgdfgfg");
        String actual = dAOException.getMessage();
        Assert.assertEquals("dgdfgfg", actual);
    } 
   

    /**
     * Test getter setter cause.
     */
    @Test
    public void testGetterSetterCause() {
        dAOException.setCause(null);
        Throwable actual = dAOException.getCause();
        Assert.assertEquals(null, actual);
    }

   

    
   

   
    

   


  
}
