package com.impetus.filmduniya.service;

import java.util.List;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import com.impetus.filmduniya.dto.Offer;


// TODO: Auto-generated Javadoc
/**
 * The Class OfferServiceImplTest.
 */
@Transactional
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/Dispatcher-servlet.xml" })
public class OfferServiceImplTest {
	
	/** The offer service. */
	@Autowired
	OfferService offerService;

	/** The offer1. */
	Offer offer1;
	
	/**
	 * Sets the up.
	 *
	 * @throws Exception the exception
	 */
	@Before
	public void setUp() throws Exception {
		offer1 = new Offer();
		offer1.setOfferId(1);
	}

	/**
	 * Test get by offer id.
	 */
	@Test
	public void testGetByOfferId() {
		try
		{
			Offer offer=offerService.getByOfferId(1);
		Assert.assertNotNull(offer);
		}catch(Exception e)
		{
			Assert.assertTrue(false);
		}
	}

	/**
	 * Test get offer for show.
	 */
	@Test
	public void testGetOfferForShow() {
		try
		{
			List<Offer> offer=offerService.getOfferForShow(1);
		Assert.assertNotNull(offer);
		}catch(Exception e)
		{
			Assert.assertTrue(false);
		}
	}

	/**
	 * Test check offer.
	 */
	@Test
	public void testCheckOffer() {
		try
		{
			Offer offer=offerService.checkOffer("1", 1);
		Assert.assertNotNull(offer);
		}catch(Exception e)
		{
			Assert.assertTrue(false);
		}
	}

	/**
	 * Test Add.
	 */
	@Test
	public void testAdd() {
		try
		{
		offerService.addOffer(null);
		}catch(Exception e)
		{
			Assert.assertTrue(true);
		}
	}

	

}
