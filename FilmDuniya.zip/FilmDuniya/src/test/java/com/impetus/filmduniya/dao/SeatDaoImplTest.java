package com.impetus.filmduniya.dao;

import java.util.List;




import com.impetus.filmduniya.dto.Seat;
import com.impetus.filmduniya.dto.Shows;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;




/**
 * The Class SeatDaoImplTest.
 */
@Transactional
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/Dispatcher-servlet.xml" })
public class SeatDaoImplTest {
	
	
	/** The seat dao. */
	@Autowired
	private SeatDao seatDao;
	
	
	/** The seat. */
	Seat seat;
	
	
	/** The show. */
	Shows show;

	/**
     * Sets the up.
     *
     * @throws Exception the exception
     */
    @Before
    public void setUp() throws Exception {
        show = new Shows();
        show.setShowId(1);
        
        seat = new Seat();
        seat.setSeatId(20);
        
    }

	/**
	 * Test get seat.
	 */
	@Test
	public void testGetSeat() {
		
			try {
				 seat = seatDao.getSeat(show, 1);
				Assert.assertNotNull(seat);
			} catch (Exception e) {
				Assert.assertTrue(false);
			}
		}
	

	/**
	 * Test update status.
	 */
	@Test
	public void testUpdateStatus() {
		try{
		 seatDao.updateStatus(seat);
		Assert.assertNotNull(seat);
	} catch (Exception e) {
		Assert.assertTrue(false);
		}
	}

	/**
 * Test get reserved seats.
 */
@Test
	public void testGetReservedSeats() {
		try {
		List<Seat> Seats=seatDao.getReservedSeats(show);
		Assert.assertNotNull(Seats);
		} catch (Exception e) {
			Assert.assertTrue(false);
		}
	}

	/**
	 * Test get seat by id.
	 */
	@Test
	public void testGetSeatById() {
	
			try {
				 seat = seatDao.getSeatById(12);
				Assert.assertNotNull(seat);
			} catch (Exception e) {
				Assert.assertTrue(false);
			}
		}
	}



