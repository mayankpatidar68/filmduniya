package com.impetus.filmduniya.dao;

import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import com.impetus.filmduniya.dto.Booking;
import com.impetus.filmduniya.dto.Ticket;
import com.impetus.filmduniya.dto.User;
import com.opensymphony.xwork2.interceptor.annotations.Before;



/**
 * The Class BookingHistoryDaoTest.
 */
@Transactional
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/Dispatcher-servlet.xml" })
public class BookingHistoryDaoTest {

	/** The booking history dao. */
	@Autowired
	private BookingHistoryDao bookingHistoryDao ;
	
	/** The booking history dao impl. */
	@Autowired
    private BookingHistoryDao bookingHistoryDaoImpl ;
	
    /** The user. */
    User user;
	
    /**
     * Sets the up.
     *
     * @throws Exception the exception
     */
    @Before
	public void setUp() throws Exception {
		
	}
    
	/**
	 * Test get booking history.
	 */
	@Test
	public void testGetBookingHistory() {
		try {
			List<Booking> bookingList = bookingHistoryDao.getBookingHistory(user);
		Object expected= bookingHistoryDaoImpl.getBookingHistory(user);
		Assert.assertEquals(expected, bookingList);
			
		} catch (Exception e) {
			Assert.assertTrue(true);
		}
	}

	/**
	 * Test get ticket details.
	 */
	@Test
	public void testGetTicketDetails() {
		try {
			List<Ticket> ticketList = bookingHistoryDao.getTicketDetails(11);
			Assert.assertNotNull(ticketList);
		} catch (Exception e) {
			Assert.assertTrue(false);
		}
	}

}


