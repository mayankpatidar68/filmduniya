package com.impetus.filmduniya.vo;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;


// TODO: Auto-generated Javadoc
/**
 * The Class AdminControllerTest.
 */
@Transactional
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/Dispatcher-servlet.xml" })
public class TheatreVOTest {

	
	/** The admin controller. */
	TheatreVO theatreVO;

	/**
	 * Sets the up.
	 *
	 * @throws Exception the exception
	 */
	@Before
	public void setUp() throws Exception {
		theatreVO=new TheatreVO();
	}

	/**
	 * Test Add Movie.
	 */
	@Test
		public void testCancelMovie() {
		
			theatreVO.setCityId("1");
			theatreVO.setNoOfColumns(1);
			theatreVO.setNoOfRows(1);
			theatreVO.setStatus("kuch b");
			theatreVO.setTheatreName("PVR");
			theatreVO.getCityId();
			theatreVO.getNoOfColumns();
			theatreVO.getNoOfRows();
			theatreVO.getStatus();
			theatreVO.getTheatreName();
	}
}
