package com.impetus.filmduniya.exception;

import org.junit.Assert;
import org.junit.Test;

public class TicketNotAvailableExceptionTest {

     /** The entity already exist exception. */
    TicketNotAvailableException ticketNotAvailableException= new TicketNotAvailableException();
    
    /**
     * Test getter setter message.
     */
    @Test
    public void testGetterSetterMessage() {
        ticketNotAvailableException.setMessage("dgdfgfg");
        String actual = ticketNotAvailableException.getMessage();
        Assert.assertEquals("dgdfgfg", actual);
    } 
   

    /**
     * Test getter setter cause.
     */
    @Test
    public void testGetterSetterCause() {
        ticketNotAvailableException.setCause(null);
        Throwable actual = ticketNotAvailableException.getCause();
        Assert.assertEquals(null, actual);
    }



}
