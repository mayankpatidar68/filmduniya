package com.impetus.filmduniya.dto;



import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.impetus.filmduniya.dto.Seat;
import com.opensymphony.xwork2.XWorkTestCase;



// TODO: Auto-generated Javadoc
/**
 * The Class SeatTest.
 */
public class SeatTest extends XWorkTestCase {

    /** The Seat. */
	Seat seat;

	/** The shows. */
	Shows shows;
	
    /*
     * (non-Javadoc)
     * 
     * @see com.opensymphony.xwork2.XWorkTestCase#setUp()
     */

    
    @Before
    public void setUp() {
    	
    	seat = new Seat();
        
    }

    /**
     * Test getter setter. 
     */
    @Test
    public void testGetterSetter() {
    	
    	seat.setSeatId(1);
        int actual = seat.getSeatId();
        Assert.assertEquals(1, actual);
       
       
        seat.setSeatNo("A15");
        String actual2=seat.getSeatNo();
        Assert.assertEquals("A15", actual2);
       
        seat.setShows(shows);
        Shows actual3=seat.getShows();
        Assert.assertEquals(shows, actual3);
        
        seat.setStatus("Available");
        String actual4=seat.getStatus();
        Assert.assertEquals("Available", actual4);
    
    }
}
