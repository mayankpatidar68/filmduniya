package com.impetus.filmduniya.dto;




import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.impetus.filmduniya.dto.Theatre;
import com.opensymphony.xwork2.XWorkTestCase;



// TODO: Auto-generated Javadoc
/**
 * The Class TheatreTest.
 */
public class TheatreTest extends XWorkTestCase {

    /** The Theatre. */
	Theatre theatre;

    /*
     * (non-Javadoc)
     * 
     * @see com.opensymphony.xwork2.XWorkTestCase#setUp()
     */

    
    @Before
    public void setUp() {
    	
    	theatre = new Theatre();
        
    }

    /**
     * Test getter setter. 
     */
    @Test
    public void testGetterSetter() {
    	City city=null;
    	
    	theatre.setTheatreId(1);
        int actual = theatre.getTheatreId();
        Assert.assertEquals(1, actual);
       
       
        theatre.setNoOfRows(124);
        int actual2=theatre.getNoOfRows();
        Assert.assertEquals(124, actual2);
       
        theatre.setNoOfColumns(452);
        int actual3=theatre.getNoOfColumns();
        Assert.assertEquals(452, actual3);
        
        theatre.setTheatreName("Mangal");
        String actual4=theatre.getTheatreName();
        Assert.assertEquals("Mangal", actual4);
    

        theatre.setStatus("Running");
        String actual5=theatre.getStatus();
        Assert.assertEquals("Running", actual5);
        
        theatre.setCity(city);
        City actual6=theatre.getCity();
        Assert.assertEquals(null, actual6);
    }

}
