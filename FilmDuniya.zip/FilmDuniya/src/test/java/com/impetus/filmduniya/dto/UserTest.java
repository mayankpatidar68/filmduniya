package com.impetus.filmduniya.dto;



import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.impetus.filmduniya.dto.User;
import com.opensymphony.xwork2.XWorkTestCase;


// TODO: Auto-generated Javadoc
/**
 * The Class UserTest.
 */
public class UserTest extends XWorkTestCase {

    /** The User. */
	User user;

    /*
     * (non-Javadoc)
     * 
     * @see com.opensymphony.xwork2.XWorkTestCase#setUp()
     */

    
    @Before
    public void setUp() {
    	
    	user = new User();
        
    }

    /**
     * Test getter setter. 
     */
    @Test
    public void testGetterSetter() {
    	
    	user.setUserId(1);
        int actual = user.getUserId();
        Assert.assertEquals(1, actual);
       
       
        user.setEmailId("mayankpith@gmail.com");
        String actual2=user.getEmailId();
        Assert.assertEquals("mayankpith@gmail.com", actual2);
       
        user.setFirstName("Mayank");
        String actual3=user.getFirstName();
        Assert.assertEquals("Mayank", actual3);
        
        user.setLastName("Patidar");
        String actual4=user.getLastName();
        Assert.assertEquals("Patidar", actual4);
    
        user.setContactNumber("9893989");
        String actual5=user.getContactNumber();
        Assert.assertEquals("9893989", actual5);
        
        user.setPassword("maddy9893989368");
        String actual6=user.getPassword();
        Assert.assertEquals("maddy9893989368", actual6);
        
        user.setConfirmPassword("maddy9893989368");
        String actual7=user.getConfirmPassword();
        Assert.assertEquals("maddy9893989368", actual7);
       
       
        
       
    }


}
